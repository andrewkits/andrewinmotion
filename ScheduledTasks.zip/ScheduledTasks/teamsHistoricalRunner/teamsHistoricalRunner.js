/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@nestjs/common/utils sync recursive":
/*!*************************************************!*\
  !*** ./node_modules/@nestjs/common/utils/ sync ***!
  \*************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "./node_modules/@nestjs/common/utils sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "./node_modules/@nestjs/core/helpers sync recursive":
/*!*************************************************!*\
  !*** ./node_modules/@nestjs/core/helpers/ sync ***!
  \*************************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "./node_modules/@nestjs/core/helpers sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "./node_modules/express/lib sync recursive":
/*!****************************************!*\
  !*** ./node_modules/express/lib/ sync ***!
  \****************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "./node_modules/express/lib sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "./node_modules/file-stream-rotator/node_modules/moment/locale sync recursive ^\\.\\/.*$":
/*!************************************************************************************!*\
  !*** ./node_modules/file-stream-rotator/node_modules/moment/locale/ sync ^\.\/.*$ ***!
  \************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

var map = {
	"./af": "./node_modules/file-stream-rotator/node_modules/moment/locale/af.js",
	"./af.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/af.js",
	"./ar": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar.js",
	"./ar-dz": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-dz.js",
	"./ar-dz.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-dz.js",
	"./ar-kw": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-kw.js",
	"./ar-kw.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-kw.js",
	"./ar-ly": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-ly.js",
	"./ar-ly.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-ly.js",
	"./ar-ma": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-ma.js",
	"./ar-ma.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-ma.js",
	"./ar-ps": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-ps.js",
	"./ar-ps.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-ps.js",
	"./ar-sa": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-sa.js",
	"./ar-sa.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-sa.js",
	"./ar-tn": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-tn.js",
	"./ar-tn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar-tn.js",
	"./ar.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ar.js",
	"./az": "./node_modules/file-stream-rotator/node_modules/moment/locale/az.js",
	"./az.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/az.js",
	"./be": "./node_modules/file-stream-rotator/node_modules/moment/locale/be.js",
	"./be.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/be.js",
	"./bg": "./node_modules/file-stream-rotator/node_modules/moment/locale/bg.js",
	"./bg.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/bg.js",
	"./bm": "./node_modules/file-stream-rotator/node_modules/moment/locale/bm.js",
	"./bm.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/bm.js",
	"./bn": "./node_modules/file-stream-rotator/node_modules/moment/locale/bn.js",
	"./bn-bd": "./node_modules/file-stream-rotator/node_modules/moment/locale/bn-bd.js",
	"./bn-bd.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/bn-bd.js",
	"./bn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/bn.js",
	"./bo": "./node_modules/file-stream-rotator/node_modules/moment/locale/bo.js",
	"./bo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/bo.js",
	"./br": "./node_modules/file-stream-rotator/node_modules/moment/locale/br.js",
	"./br.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/br.js",
	"./bs": "./node_modules/file-stream-rotator/node_modules/moment/locale/bs.js",
	"./bs.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/bs.js",
	"./ca": "./node_modules/file-stream-rotator/node_modules/moment/locale/ca.js",
	"./ca.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ca.js",
	"./cs": "./node_modules/file-stream-rotator/node_modules/moment/locale/cs.js",
	"./cs.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/cs.js",
	"./cv": "./node_modules/file-stream-rotator/node_modules/moment/locale/cv.js",
	"./cv.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/cv.js",
	"./cy": "./node_modules/file-stream-rotator/node_modules/moment/locale/cy.js",
	"./cy.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/cy.js",
	"./da": "./node_modules/file-stream-rotator/node_modules/moment/locale/da.js",
	"./da.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/da.js",
	"./de": "./node_modules/file-stream-rotator/node_modules/moment/locale/de.js",
	"./de-at": "./node_modules/file-stream-rotator/node_modules/moment/locale/de-at.js",
	"./de-at.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/de-at.js",
	"./de-ch": "./node_modules/file-stream-rotator/node_modules/moment/locale/de-ch.js",
	"./de-ch.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/de-ch.js",
	"./de.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/de.js",
	"./dv": "./node_modules/file-stream-rotator/node_modules/moment/locale/dv.js",
	"./dv.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/dv.js",
	"./el": "./node_modules/file-stream-rotator/node_modules/moment/locale/el.js",
	"./el.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/el.js",
	"./en-au": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-au.js",
	"./en-au.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-au.js",
	"./en-ca": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-ca.js",
	"./en-ca.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-ca.js",
	"./en-gb": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-gb.js",
	"./en-gb.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-gb.js",
	"./en-ie": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-ie.js",
	"./en-ie.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-ie.js",
	"./en-il": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-il.js",
	"./en-il.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-il.js",
	"./en-in": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-in.js",
	"./en-in.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-in.js",
	"./en-nz": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-nz.js",
	"./en-nz.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-nz.js",
	"./en-sg": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-sg.js",
	"./en-sg.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/en-sg.js",
	"./eo": "./node_modules/file-stream-rotator/node_modules/moment/locale/eo.js",
	"./eo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/eo.js",
	"./es": "./node_modules/file-stream-rotator/node_modules/moment/locale/es.js",
	"./es-do": "./node_modules/file-stream-rotator/node_modules/moment/locale/es-do.js",
	"./es-do.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/es-do.js",
	"./es-mx": "./node_modules/file-stream-rotator/node_modules/moment/locale/es-mx.js",
	"./es-mx.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/es-mx.js",
	"./es-us": "./node_modules/file-stream-rotator/node_modules/moment/locale/es-us.js",
	"./es-us.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/es-us.js",
	"./es.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/es.js",
	"./et": "./node_modules/file-stream-rotator/node_modules/moment/locale/et.js",
	"./et.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/et.js",
	"./eu": "./node_modules/file-stream-rotator/node_modules/moment/locale/eu.js",
	"./eu.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/eu.js",
	"./fa": "./node_modules/file-stream-rotator/node_modules/moment/locale/fa.js",
	"./fa.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fa.js",
	"./fi": "./node_modules/file-stream-rotator/node_modules/moment/locale/fi.js",
	"./fi.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fi.js",
	"./fil": "./node_modules/file-stream-rotator/node_modules/moment/locale/fil.js",
	"./fil.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fil.js",
	"./fo": "./node_modules/file-stream-rotator/node_modules/moment/locale/fo.js",
	"./fo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fo.js",
	"./fr": "./node_modules/file-stream-rotator/node_modules/moment/locale/fr.js",
	"./fr-ca": "./node_modules/file-stream-rotator/node_modules/moment/locale/fr-ca.js",
	"./fr-ca.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fr-ca.js",
	"./fr-ch": "./node_modules/file-stream-rotator/node_modules/moment/locale/fr-ch.js",
	"./fr-ch.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fr-ch.js",
	"./fr.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fr.js",
	"./fy": "./node_modules/file-stream-rotator/node_modules/moment/locale/fy.js",
	"./fy.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/fy.js",
	"./ga": "./node_modules/file-stream-rotator/node_modules/moment/locale/ga.js",
	"./ga.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ga.js",
	"./gd": "./node_modules/file-stream-rotator/node_modules/moment/locale/gd.js",
	"./gd.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/gd.js",
	"./gl": "./node_modules/file-stream-rotator/node_modules/moment/locale/gl.js",
	"./gl.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/gl.js",
	"./gom-deva": "./node_modules/file-stream-rotator/node_modules/moment/locale/gom-deva.js",
	"./gom-deva.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/gom-deva.js",
	"./gom-latn": "./node_modules/file-stream-rotator/node_modules/moment/locale/gom-latn.js",
	"./gom-latn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/gom-latn.js",
	"./gu": "./node_modules/file-stream-rotator/node_modules/moment/locale/gu.js",
	"./gu.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/gu.js",
	"./he": "./node_modules/file-stream-rotator/node_modules/moment/locale/he.js",
	"./he.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/he.js",
	"./hi": "./node_modules/file-stream-rotator/node_modules/moment/locale/hi.js",
	"./hi.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/hi.js",
	"./hr": "./node_modules/file-stream-rotator/node_modules/moment/locale/hr.js",
	"./hr.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/hr.js",
	"./hu": "./node_modules/file-stream-rotator/node_modules/moment/locale/hu.js",
	"./hu.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/hu.js",
	"./hy-am": "./node_modules/file-stream-rotator/node_modules/moment/locale/hy-am.js",
	"./hy-am.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/hy-am.js",
	"./id": "./node_modules/file-stream-rotator/node_modules/moment/locale/id.js",
	"./id.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/id.js",
	"./is": "./node_modules/file-stream-rotator/node_modules/moment/locale/is.js",
	"./is.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/is.js",
	"./it": "./node_modules/file-stream-rotator/node_modules/moment/locale/it.js",
	"./it-ch": "./node_modules/file-stream-rotator/node_modules/moment/locale/it-ch.js",
	"./it-ch.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/it-ch.js",
	"./it.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/it.js",
	"./ja": "./node_modules/file-stream-rotator/node_modules/moment/locale/ja.js",
	"./ja.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ja.js",
	"./jv": "./node_modules/file-stream-rotator/node_modules/moment/locale/jv.js",
	"./jv.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/jv.js",
	"./ka": "./node_modules/file-stream-rotator/node_modules/moment/locale/ka.js",
	"./ka.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ka.js",
	"./kk": "./node_modules/file-stream-rotator/node_modules/moment/locale/kk.js",
	"./kk.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/kk.js",
	"./km": "./node_modules/file-stream-rotator/node_modules/moment/locale/km.js",
	"./km.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/km.js",
	"./kn": "./node_modules/file-stream-rotator/node_modules/moment/locale/kn.js",
	"./kn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/kn.js",
	"./ko": "./node_modules/file-stream-rotator/node_modules/moment/locale/ko.js",
	"./ko.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ko.js",
	"./ku": "./node_modules/file-stream-rotator/node_modules/moment/locale/ku.js",
	"./ku-kmr": "./node_modules/file-stream-rotator/node_modules/moment/locale/ku-kmr.js",
	"./ku-kmr.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ku-kmr.js",
	"./ku.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ku.js",
	"./ky": "./node_modules/file-stream-rotator/node_modules/moment/locale/ky.js",
	"./ky.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ky.js",
	"./lb": "./node_modules/file-stream-rotator/node_modules/moment/locale/lb.js",
	"./lb.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/lb.js",
	"./lo": "./node_modules/file-stream-rotator/node_modules/moment/locale/lo.js",
	"./lo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/lo.js",
	"./lt": "./node_modules/file-stream-rotator/node_modules/moment/locale/lt.js",
	"./lt.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/lt.js",
	"./lv": "./node_modules/file-stream-rotator/node_modules/moment/locale/lv.js",
	"./lv.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/lv.js",
	"./me": "./node_modules/file-stream-rotator/node_modules/moment/locale/me.js",
	"./me.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/me.js",
	"./mi": "./node_modules/file-stream-rotator/node_modules/moment/locale/mi.js",
	"./mi.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/mi.js",
	"./mk": "./node_modules/file-stream-rotator/node_modules/moment/locale/mk.js",
	"./mk.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/mk.js",
	"./ml": "./node_modules/file-stream-rotator/node_modules/moment/locale/ml.js",
	"./ml.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ml.js",
	"./mn": "./node_modules/file-stream-rotator/node_modules/moment/locale/mn.js",
	"./mn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/mn.js",
	"./mr": "./node_modules/file-stream-rotator/node_modules/moment/locale/mr.js",
	"./mr.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/mr.js",
	"./ms": "./node_modules/file-stream-rotator/node_modules/moment/locale/ms.js",
	"./ms-my": "./node_modules/file-stream-rotator/node_modules/moment/locale/ms-my.js",
	"./ms-my.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ms-my.js",
	"./ms.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ms.js",
	"./mt": "./node_modules/file-stream-rotator/node_modules/moment/locale/mt.js",
	"./mt.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/mt.js",
	"./my": "./node_modules/file-stream-rotator/node_modules/moment/locale/my.js",
	"./my.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/my.js",
	"./nb": "./node_modules/file-stream-rotator/node_modules/moment/locale/nb.js",
	"./nb.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/nb.js",
	"./ne": "./node_modules/file-stream-rotator/node_modules/moment/locale/ne.js",
	"./ne.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ne.js",
	"./nl": "./node_modules/file-stream-rotator/node_modules/moment/locale/nl.js",
	"./nl-be": "./node_modules/file-stream-rotator/node_modules/moment/locale/nl-be.js",
	"./nl-be.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/nl-be.js",
	"./nl.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/nl.js",
	"./nn": "./node_modules/file-stream-rotator/node_modules/moment/locale/nn.js",
	"./nn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/nn.js",
	"./oc-lnc": "./node_modules/file-stream-rotator/node_modules/moment/locale/oc-lnc.js",
	"./oc-lnc.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/oc-lnc.js",
	"./pa-in": "./node_modules/file-stream-rotator/node_modules/moment/locale/pa-in.js",
	"./pa-in.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/pa-in.js",
	"./pl": "./node_modules/file-stream-rotator/node_modules/moment/locale/pl.js",
	"./pl.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/pl.js",
	"./pt": "./node_modules/file-stream-rotator/node_modules/moment/locale/pt.js",
	"./pt-br": "./node_modules/file-stream-rotator/node_modules/moment/locale/pt-br.js",
	"./pt-br.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/pt-br.js",
	"./pt.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/pt.js",
	"./ro": "./node_modules/file-stream-rotator/node_modules/moment/locale/ro.js",
	"./ro.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ro.js",
	"./ru": "./node_modules/file-stream-rotator/node_modules/moment/locale/ru.js",
	"./ru.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ru.js",
	"./sd": "./node_modules/file-stream-rotator/node_modules/moment/locale/sd.js",
	"./sd.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sd.js",
	"./se": "./node_modules/file-stream-rotator/node_modules/moment/locale/se.js",
	"./se.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/se.js",
	"./si": "./node_modules/file-stream-rotator/node_modules/moment/locale/si.js",
	"./si.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/si.js",
	"./sk": "./node_modules/file-stream-rotator/node_modules/moment/locale/sk.js",
	"./sk.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sk.js",
	"./sl": "./node_modules/file-stream-rotator/node_modules/moment/locale/sl.js",
	"./sl.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sl.js",
	"./sq": "./node_modules/file-stream-rotator/node_modules/moment/locale/sq.js",
	"./sq.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sq.js",
	"./sr": "./node_modules/file-stream-rotator/node_modules/moment/locale/sr.js",
	"./sr-cyrl": "./node_modules/file-stream-rotator/node_modules/moment/locale/sr-cyrl.js",
	"./sr-cyrl.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sr-cyrl.js",
	"./sr.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sr.js",
	"./ss": "./node_modules/file-stream-rotator/node_modules/moment/locale/ss.js",
	"./ss.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ss.js",
	"./sv": "./node_modules/file-stream-rotator/node_modules/moment/locale/sv.js",
	"./sv.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sv.js",
	"./sw": "./node_modules/file-stream-rotator/node_modules/moment/locale/sw.js",
	"./sw.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/sw.js",
	"./ta": "./node_modules/file-stream-rotator/node_modules/moment/locale/ta.js",
	"./ta.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ta.js",
	"./te": "./node_modules/file-stream-rotator/node_modules/moment/locale/te.js",
	"./te.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/te.js",
	"./tet": "./node_modules/file-stream-rotator/node_modules/moment/locale/tet.js",
	"./tet.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tet.js",
	"./tg": "./node_modules/file-stream-rotator/node_modules/moment/locale/tg.js",
	"./tg.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tg.js",
	"./th": "./node_modules/file-stream-rotator/node_modules/moment/locale/th.js",
	"./th.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/th.js",
	"./tk": "./node_modules/file-stream-rotator/node_modules/moment/locale/tk.js",
	"./tk.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tk.js",
	"./tl-ph": "./node_modules/file-stream-rotator/node_modules/moment/locale/tl-ph.js",
	"./tl-ph.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tl-ph.js",
	"./tlh": "./node_modules/file-stream-rotator/node_modules/moment/locale/tlh.js",
	"./tlh.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tlh.js",
	"./tr": "./node_modules/file-stream-rotator/node_modules/moment/locale/tr.js",
	"./tr.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tr.js",
	"./tzl": "./node_modules/file-stream-rotator/node_modules/moment/locale/tzl.js",
	"./tzl.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tzl.js",
	"./tzm": "./node_modules/file-stream-rotator/node_modules/moment/locale/tzm.js",
	"./tzm-latn": "./node_modules/file-stream-rotator/node_modules/moment/locale/tzm-latn.js",
	"./tzm-latn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tzm-latn.js",
	"./tzm.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/tzm.js",
	"./ug-cn": "./node_modules/file-stream-rotator/node_modules/moment/locale/ug-cn.js",
	"./ug-cn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ug-cn.js",
	"./uk": "./node_modules/file-stream-rotator/node_modules/moment/locale/uk.js",
	"./uk.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/uk.js",
	"./ur": "./node_modules/file-stream-rotator/node_modules/moment/locale/ur.js",
	"./ur.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/ur.js",
	"./uz": "./node_modules/file-stream-rotator/node_modules/moment/locale/uz.js",
	"./uz-latn": "./node_modules/file-stream-rotator/node_modules/moment/locale/uz-latn.js",
	"./uz-latn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/uz-latn.js",
	"./uz.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/uz.js",
	"./vi": "./node_modules/file-stream-rotator/node_modules/moment/locale/vi.js",
	"./vi.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/vi.js",
	"./x-pseudo": "./node_modules/file-stream-rotator/node_modules/moment/locale/x-pseudo.js",
	"./x-pseudo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/x-pseudo.js",
	"./yo": "./node_modules/file-stream-rotator/node_modules/moment/locale/yo.js",
	"./yo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/yo.js",
	"./zh-cn": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-cn.js",
	"./zh-cn.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-cn.js",
	"./zh-hk": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-hk.js",
	"./zh-hk.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-hk.js",
	"./zh-mo": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-mo.js",
	"./zh-mo.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-mo.js",
	"./zh-tw": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-tw.js",
	"./zh-tw.js": "./node_modules/file-stream-rotator/node_modules/moment/locale/zh-tw.js"
};


function webpackContext(req) {
	var id = webpackContextResolve(req);
	return __webpack_require__(id);
}
function webpackContextResolve(req) {
	if(!__webpack_require__.o(map, req)) {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	}
	return map[req];
}
webpackContext.keys = function webpackContextKeys() {
	return Object.keys(map);
};
webpackContext.resolve = webpackContextResolve;
module.exports = webpackContext;
webpackContext.id = "./node_modules/file-stream-rotator/node_modules/moment/locale sync recursive ^\\.\\/.*$";

/***/ }),

/***/ "./node_modules/mongodb/lib sync recursive":
/*!****************************************!*\
  !*** ./node_modules/mongodb/lib/ sync ***!
  \****************************************/
/***/ ((module) => {

function webpackEmptyContext(req) {
	var e = new Error("Cannot find module '" + req + "'");
	e.code = 'MODULE_NOT_FOUND';
	throw e;
}
webpackEmptyContext.keys = () => ([]);
webpackEmptyContext.resolve = webpackEmptyContext;
webpackEmptyContext.id = "./node_modules/mongodb/lib sync recursive";
module.exports = webpackEmptyContext;

/***/ }),

/***/ "./src/common/errorProcessing.ts":
/*!***************************************!*\
  !*** ./src/common/errorProcessing.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.normalizePotentialWebRequestError = exports.getEnrichedZodError = exports.enrichedZodErrorType = exports.webRequestErrorType = void 0;
const zod_1 = __webpack_require__(/*! zod */ "./node_modules/zod/lib/index.js");
const axios_1 = __webpack_require__(/*! axios */ "./node_modules/axios/dist/node/axios.cjs");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const axiosErrorValidator = zod_1.z.object({
    message: zod_1.z.string().optional(),
    code: zod_1.z.string().optional(),
    response: zod_1.z.any().optional(),
});
const doesAxiosErrorContainsNoInformation = (error) => error.code === undefined &&
    error.message === undefined &&
    error.response === undefined;
exports.webRequestErrorType = 'webRequestError';
exports.enrichedZodErrorType = 'enrichedZodErrorType';
const getEnrichedZodError = (error, maybeRelatedContent) => {
    const unknownError = (0, pure_utils_1.transformExceptionToUnknownError)(error);
    const maybeSerializedContent = maybeRelatedContent === undefined
        ? undefined
        : JSON.stringify(maybeRelatedContent);
    return {
        ...unknownError,
        message: maybeSerializedContent
            ? `${error.message} happens inside ${maybeSerializedContent}`
            : error.message,
        type: exports.enrichedZodErrorType,
    };
};
exports.getEnrichedZodError = getEnrichedZodError;
const getNormalizedAxiosError = (error) => {
    const unknownError = (0, pure_utils_1.transformExceptionToUnknownError)(error);
    const parsedAxiosError = axiosErrorValidator.safeParse(error);
    if (!parsedAxiosError.success) {
        return unknownError;
    }
    if (doesAxiosErrorContainsNoInformation(error)) {
        return unknownError;
    }
    return {
        ...unknownError,
        ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('url', error.config?.url),
        ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('code', error?.code),
        ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('details', error.response?.data),
        type: exports.webRequestErrorType,
    };
};
const normalizePotentialWebRequestError = (incomingError) => {
    try {
        if ((0, axios_1.isAxiosError)(incomingError)) {
            return getNormalizedAxiosError(incomingError);
        }
        return (0, pure_utils_1.transformExceptionToUnknownError)(incomingError);
    }
    catch (error) {
        return (0, pure_utils_1.transformExceptionToUnknownError)(error);
    }
};
exports.normalizePotentialWebRequestError = normalizePotentialWebRequestError;


/***/ }),

/***/ "./src/core/logger.ts":
/*!****************************!*\
  !*** ./src/core/logger.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getLogger = exports.withLoggingAsync = exports.withLogging = exports.changeMessageLevel = void 0;
const winston_1 = __webpack_require__(/*! winston */ "./node_modules/winston/lib/winston.js");
const time_1 = __webpack_require__(/*! ./time */ "./src/core/time.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const environment = "development" || 0;
__webpack_require__(/*! winston-daily-rotate-file */ "./node_modules/winston-daily-rotate-file/index.js");
const logTransformFunction = (info) => {
    if (info.level !== 'error') {
        return info;
    }
    const source = info.source;
    if (!(0, pure_utils_1.isPlainObject)(source) || source.parser !== 'email_eml') {
        return info;
    }
    const error = info.error;
    if (typeof error !== 'string' || !error.startsWith('MongoError: E11000')) {
        return info;
    }
    return {
        ...info,
        level: 'warning',
    };
};
exports.changeMessageLevel = (0, winston_1.format)(logTransformFunction);
const defaultLoggingOptions = {
    isMustLogArguments: false,
    isMustLogFunctionCallResults: false,
};
const addDefaultOptions = (0, pure_utils_1.addDefaults)(defaultLoggingOptions);
const logFunctionStart = (functionName, logFn, args, isMustLogArguments) => {
    const loggedObject = { step: 'start' };
    if (isMustLogArguments) {
        loggedObject.arguments = args;
    }
    logFn(functionName, loggedObject);
};
const logFunctionEnd = (functionName, logFn, result, executionStartedAt, isMustLogFunctionCallResults) => {
    const loggedObject = {
        step: 'end',
        executionTimeSeconds: (0, time_1.getSecondsPassedFrom)(executionStartedAt),
    };
    if (isMustLogFunctionCallResults) {
        loggedObject.result = result;
    }
    logFn(functionName, loggedObject);
};
const withLogging = (originalFn, functionName, logFn, additionalLoggingOptions = defaultLoggingOptions) => {
    const loggingOptions = addDefaultOptions(additionalLoggingOptions);
    const wrapped = (...args) => {
        const { isMustLogArguments, isMustLogFunctionCallResults } = loggingOptions;
        logFunctionStart(functionName, logFn, args, isMustLogArguments);
        const timeStart = Date.now();
        const result = originalFn(...args);
        logFunctionEnd(functionName, logFn, result, timeStart, isMustLogFunctionCallResults);
        return result;
    };
    return wrapped;
};
exports.withLogging = withLogging;
const withLoggingAsync = (originalFn, functionName, logFn, additionalLoggingOptions = defaultLoggingOptions) => {
    const loggingOptions = addDefaultOptions(additionalLoggingOptions);
    const wrapped = async (...args) => {
        const { isMustLogArguments, isMustLogFunctionCallResults } = loggingOptions;
        logFunctionStart(functionName, logFn, args, isMustLogArguments);
        const timeStart = Date.now();
        const result = await originalFn(...args);
        logFunctionEnd(functionName, logFn, result, timeStart, isMustLogFunctionCallResults);
        return result;
    };
    return wrapped;
};
exports.withLoggingAsync = withLoggingAsync;
const getLogger = (filename) => {
    const script = filename
        ? filename.split('/').slice(-2).join('/').split('.').slice(0, -1).join('.')
        : '';
    const format1 = environment === 'dev'
        ? winston_1.format.combine(winston_1.format.colorize(), winston_1.format.timestamp(), winston_1.format.printf((info) => {
            const { timestamp, level, message, ...extra } = info;
            return `${timestamp} [${level}]: ${script}|${message} ${JSON.stringify(extra)}`;
        }), winston_1.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }))
        : winston_1.format.combine((0, exports.changeMessageLevel)(), winston_1.format.printf((info) => {
            const { level, message, ...extra } = info;
            const result = {
                level,
                script,
                message: message,
                component: 'ETL',
                ...extra,
            };
            return JSON.stringify(result);
        }));
    const transports1 = [
        new winston_1.transports.Console(),
    ];
    return (0, winston_1.createLogger)({
        levels: winston_1.config.syslog.levels,
        level: process.env.LOG_LEVEL || 'info',
        format: format1,
        transports: transports1,
    });
};
exports.getLogger = getLogger;


/***/ }),

/***/ "./src/core/time.ts":
/*!**************************!*\
  !*** ./src/core/time.ts ***!
  \**************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getSecondsPassedFrom = exports.msInSecond = void 0;
exports.msInSecond = 1000;
const getSecondsPassedFrom = (sinceUnixTimestampMs) => (Date.now() - sinceUnixTimestampMs) / exports.msInSecond;
exports.getSecondsPassedFrom = getSecondsPassedFrom;


/***/ }),

/***/ "./src/services/notifications/types.ts":
/*!*********************************************!*\
  !*** ./src/services/notifications/types.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.notificationSendingErrorCode = exports.dbNotificationSaverErrorCode = exports.notificationParsingErrorCode = exports.lambdaErrorResponseParseAndTransformToLogMessage = exports.opsGenieForEverything = exports.OPS_GENIE_LEVELS = exports.providerByServiceAndThenByInstrumentationType = exports.opsGenieToken = exports.opsGenieUrl = exports.FAIRWORDS_ENVIRONMENT = exports.logMessage = exports.etlService = exports.instrumentationType = exports.instrumentationTypeWarning = exports.instrumentationTypePanic = exports.instrumentationTypeNotice = exports.instrumentationTypeInfo = exports.instrumentationTypeError = exports.instrumentationTypeEmergency = exports.instrumentationTypeDebug = exports.instrumentationTypeAlert = void 0;
const zod_1 = __webpack_require__(/*! zod */ "./node_modules/zod/lib/index.js");
exports.instrumentationTypeAlert = 'alert';
exports.instrumentationTypeDebug = 'debug';
exports.instrumentationTypeEmergency = 'emerg';
exports.instrumentationTypeError = 'error';
exports.instrumentationTypeInfo = 'info';
exports.instrumentationTypeNotice = 'notice';
exports.instrumentationTypePanic = 'panic';
exports.instrumentationTypeWarning = 'warning';
const instrumentationTypeArr = [
    exports.instrumentationTypePanic,
    exports.instrumentationTypeEmergency,
    exports.instrumentationTypeAlert,
    exports.instrumentationTypeError,
    exports.instrumentationTypeWarning,
    exports.instrumentationTypeInfo,
    exports.instrumentationTypeNotice,
    exports.instrumentationTypeDebug,
];
exports.instrumentationType = zod_1.z.enum(instrumentationTypeArr);
exports.etlService = 'ETL';
const keepService = 'Keep';
const reviewService = 'Review';
const ecommsServiceArr = [exports.etlService, keepService, reviewService];
const ecommsService = zod_1.z.enum(ecommsServiceArr);
const opsGenieLevel = zod_1.z.union([
    zod_1.z.literal('P1'),
    zod_1.z.literal('P2'),
    zod_1.z.literal('P3'),
    zod_1.z.literal('P4'),
]);
const opsGenieLevels = zod_1.z.record(exports.instrumentationType, opsGenieLevel);
const OPS_GENIE_ALIAS_MAX_LENGTH = 512;
exports.logMessage = zod_1.z.object({
    service: ecommsService,
    instrumentationType: exports.instrumentationType,
    title: zod_1.z.string(),
    message: zod_1.z.string(),
    executionArn: zod_1.z.string().optional(),
    executionStatus: zod_1.z.string().optional(),
    customerId: zod_1.z.string().optional(),
    customerName: zod_1.z.string().optional(),
    customerInitials: zod_1.z.string().optional(),
    tenantId: zod_1.z.string().optional(),
    errorReferenceId: zod_1.z.string().optional(),
    errorCode: zod_1.z.string().min(1).max(OPS_GENIE_ALIAS_MAX_LENGTH).optional(),
    details: zod_1.z.record(zod_1.z.string().min(1), zod_1.z.string()).optional(),
});
exports.FAIRWORDS_ENVIRONMENT = (process.env.FAIRWORDS_ENVIRONMENT === undefined)
    ? 'UNKNOWN'
    : process.env.FAIRWORDS_ENVIRONMENT;
exports.opsGenieUrl = process.env.OPS_GENIE_URL ?? '';
exports.opsGenieToken = process.env.OPS_GENIE_TOKEN ?? '';
const opsGenieDestination = 'opsGenie';
const notificationsDestination = zod_1.z.literal(opsGenieDestination);
const providerByInstrumentationType = zod_1.z.object({
    [exports.instrumentationTypePanic]: notificationsDestination,
    [exports.instrumentationTypeEmergency]: notificationsDestination,
    [exports.instrumentationTypeAlert]: notificationsDestination,
    [exports.instrumentationTypeError]: notificationsDestination,
    [exports.instrumentationTypeWarning]: notificationsDestination,
    [exports.instrumentationTypeInfo]: notificationsDestination,
    [exports.instrumentationTypeNotice]: notificationsDestination,
    [exports.instrumentationTypeDebug]: notificationsDestination,
});
exports.providerByServiceAndThenByInstrumentationType = zod_1.z.object({
    [exports.etlService]: providerByInstrumentationType,
    [keepService]: providerByInstrumentationType,
    [reviewService]: providerByInstrumentationType,
});
exports.OPS_GENIE_LEVELS = {
    [exports.instrumentationTypeEmergency]: 'P1',
    [exports.instrumentationTypeAlert]: 'P1',
    [exports.instrumentationTypePanic]: 'P1',
    [exports.instrumentationTypeError]: 'P2',
    [exports.instrumentationTypeWarning]: 'P4',
    [exports.instrumentationTypeNotice]: 'P4',
    [exports.instrumentationTypeInfo]: 'P4',
    [exports.instrumentationTypeDebug]: 'P4',
};
const opsGenieForEveryLevel = {
    [exports.instrumentationTypeEmergency]: opsGenieDestination,
    [exports.instrumentationTypeAlert]: opsGenieDestination,
    [exports.instrumentationTypePanic]: opsGenieDestination,
    [exports.instrumentationTypeError]: opsGenieDestination,
    [exports.instrumentationTypeWarning]: opsGenieDestination,
    [exports.instrumentationTypeNotice]: opsGenieDestination,
    [exports.instrumentationTypeInfo]: opsGenieDestination,
    [exports.instrumentationTypeDebug]: opsGenieDestination,
};
exports.opsGenieForEverything = {
    [exports.etlService]: opsGenieForEveryLevel,
    [keepService]: opsGenieForEveryLevel,
    [reviewService]: opsGenieForEveryLevel,
};
exports.lambdaErrorResponseParseAndTransformToLogMessage = zod_1.z.object({
    requestContext: zod_1.z.object({
        functionArn: zod_1.z.string(),
    }),
    responsePayload: zod_1.z.object({
        errorMessage: zod_1.z.string(),
        trace: zod_1.z.array(zod_1.z.string()).optional(),
    }),
}).transform(({ requestContext, responsePayload }) => ({
    service: exports.etlService,
    instrumentationType: exports.instrumentationTypeError,
    title: 'AWSLambdaFailureResponse',
    message: responsePayload.errorMessage,
    functionArn: requestContext.functionArn,
    trace: responsePayload.trace,
}));
exports.notificationParsingErrorCode = 'NOTIFICATION_PARSING_ERROR';
exports.dbNotificationSaverErrorCode = 'NOTIFICATION_SAVING_ERROR';
exports.notificationSendingErrorCode = 'NOTIFICATION_SENDING_ERROR';


/***/ }),

/***/ "./src/services/teamsHistorical/common.ts":
/*!************************************************!*\
  !*** ./src/services/teamsHistorical/common.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField = exports.ifTrueAddOptionalField = exports.getAllParticipantUsers = exports.getMsGraphUsersBatchRequest = exports.buildBatchRequests = exports.msGraphBatchUserFetchResponseSchema = exports.msGraphUsersResponseSchema = exports.getStartingEntities = exports.getHeaderEntity = exports.createInternerSet = exports.createNewStringInterner = exports.getNextMessageIndexBuilder = exports.createInternerByKey = exports.queryHandlerFromFunction = exports.getEmptyStringEntity = exports.notUndefinedAndNotNullAndNotEmpty = exports.getJsonlFileName = exports.mediaMessageKind = exports.imMessageKind = exports.messageType = exports.stringType = exports.mediaFileUrlType = exports.threadIdType = exports.userSetType = exports.userType = exports.headerType = exports.teamsHistoricalSource = exports.PROCESSING_RECORDS_UPDATER_TOKEN = exports.ALERT_NOTIFICATION_QUEUE_SERVICE_TOKEN = exports.TEAMS_HISTORICAL_WRITE_SERVICE_TOKEN = exports.DATA_RETRIEVAL_ISSUES_RECORD_LOGGER_TOKEN = exports.CREDENTIALS_GETTER_TOKEN = exports.CLIENT_SECRET_GETTER_TOKEN = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const zod_1 = __webpack_require__(/*! zod */ "./node_modules/zod/lib/index.js");
const validation_1 = __webpack_require__(/*! ../../validation */ "./src/validation/index.ts");
exports.CLIENT_SECRET_GETTER_TOKEN = Symbol('ClientSecretGetter');
exports.CREDENTIALS_GETTER_TOKEN = Symbol('CredentialsGetter');
exports.DATA_RETRIEVAL_ISSUES_RECORD_LOGGER_TOKEN = Symbol('DataRetrievalIssuesRecordLogger');
exports.TEAMS_HISTORICAL_WRITE_SERVICE_TOKEN = Symbol('TeamsHistoricalWriteService');
exports.ALERT_NOTIFICATION_QUEUE_SERVICE_TOKEN = Symbol('AlertNotificationQueueService');
exports.PROCESSING_RECORDS_UPDATER_TOKEN = Symbol('ProcessingRecordsUpdater');
exports.teamsHistoricalSource = 'teamsHistoricalSource';
const uniqueElementsCountStatsValidator = zod_1.z.object({
    users: validation_1.nonNegativeInteger,
    userSets: validation_1.nonNegativeInteger,
    threads: validation_1.nonNegativeInteger,
    mediaFileUrls: validation_1.nonNegativeInteger.optional(),
    strings: validation_1.nonNegativeInteger,
    messages: validation_1.nonNegativeInteger,
    totalWithoutHeader: validation_1.nonNegativeInteger,
});
const threadStatsValidator = zod_1.z.object({
    threadId: validation_1.nonNegativeInteger,
    messagesCount: validation_1.nonNegativeInteger,
    totalMessagesEstimatedSize: validation_1.nonNegativeInteger,
});
exports.headerType = 'Header';
exports.userType = 'User';
exports.userSetType = 'UserSet';
exports.threadIdType = 'ThreadId';
exports.mediaFileUrlType = 'MediaFileUrl';
exports.stringType = 'String';
exports.messageType = 'Message';
exports.imMessageKind = 'IM';
exports.mediaMessageKind = 'Media';
const headerValidator = zod_1.z.object({
    type: zod_1.z.literal(exports.headerType),
    sourceKey: zod_1.z.string(),
    fileName: zod_1.z.string(),
    customerInitials: zod_1.z.string(),
    uniqueElementCounts: uniqueElementsCountStatsValidator.optional(),
    threadStats: zod_1.z.array(threadStatsValidator).optional(),
});
const referencedValueValidator = (type, dataValidator) => zod_1.z.object({
    type: zod_1.z.literal(type),
    ref: validation_1.nonNegativeInteger,
    data: dataValidator,
});
const userDataValidator = zod_1.z.object({
    fullName: zod_1.z.string().optional(),
    identities: zod_1.z.array(zod_1.z.string()),
});
const optionalRegionOffsets = zod_1.z.object({
    start: validation_1.nonNegativeInteger.optional(),
    len: validation_1.nonNegativeInteger.optional(),
});
const serializedMessageValidatorCommon = {
    type: zod_1.z.literal(exports.messageType),
    fromUserRef: validation_1.nonNegativeInteger.optional(),
    allParticipantsRef: validation_1.nonNegativeInteger,
    originalTimestamp: validation_1.nonNegativeInteger,
    replyToOriginId: zod_1.z.string().optional(),
    originParentId: zod_1.z.string().optional(),
    threadIdRef: validation_1.nonNegativeInteger.optional(),
    threadName: zod_1.z.string().optional(),
    threadNameRef: validation_1.nonNegativeInteger.optional(),
    threadDescriptionRef: validation_1.nonNegativeInteger.optional(),
    subjectRef: validation_1.nonNegativeInteger.optional(),
    contentTextRef: validation_1.nonNegativeInteger,
    contentRef: validation_1.nonNegativeInteger,
    originId: zod_1.z.string(),
    isDeleted: zod_1.z.literal(true).optional(),
    isImportant: zod_1.z.literal(true).optional(),
    isUrgent: zod_1.z.literal(true).optional(),
    idxInFile: validation_1.nonNegativeInteger,
    pos: optionalRegionOffsets.optional(),
};
const serializedImMessageValidator = zod_1.z.object({
    ...serializedMessageValidatorCommon,
    kind: zod_1.z.literal(exports.imMessageKind),
});
const serializedMediaMessageValidator = zod_1.z.object({
    ...serializedMessageValidatorCommon,
    kind: zod_1.z.literal(exports.mediaMessageKind),
    audioFileUrlRef: validation_1.nonNegativeInteger.optional(),
    videoFileUrlRef: validation_1.nonNegativeInteger.optional(),
    startOffsetMs: zod_1.z.number(),
    lengthMs: zod_1.z.number(),
    isChatMessage: zod_1.z.literal(true).optional(),
    speakerAttributionCorrectnessProbability: zod_1.z.number().gte(0).lte(1).optional(),
});
const referencedUserDataValidator = referencedValueValidator(exports.userType, userDataValidator);
const referencedUserSetValidator = referencedValueValidator(exports.userSetType, zod_1.z.array(validation_1.nonNegativeInteger));
const referencedThreadIdValidator = referencedValueValidator(exports.threadIdType, zod_1.z.string());
const referencedMediaFileUrlValidator = referencedValueValidator(exports.mediaFileUrlType, zod_1.z.string());
const referencedStringValidator = referencedValueValidator(exports.stringType, zod_1.z.string());
const serializedMessageValidator = zod_1.z.union([
    serializedImMessageValidator,
    serializedMediaMessageValidator,
]);
const serializedMessageDataEntryValidator = zod_1.z.union([
    headerValidator,
    referencedUserDataValidator,
    referencedUserSetValidator,
    referencedThreadIdValidator,
    referencedMediaFileUrlValidator,
    referencedStringValidator,
    serializedMessageValidator,
]);
const getJsonlFileName = (customerId, sourceKey, dateStartExclusiveUtcIso8601, dateEndInclusiveUtcIso8601) => {
    const fileName = `${customerId}-${sourceKey}-` +
        `${dateStartExclusiveUtcIso8601}-${dateEndInclusiveUtcIso8601}.jsonl`;
    return fileName.replaceAll(':', '_');
};
exports.getJsonlFileName = getJsonlFileName;
const notUndefinedAndNotNullAndNotEmpty = (x) => x !== undefined && x !== null && x.length > 0;
exports.notUndefinedAndNotNullAndNotEmpty = notUndefinedAndNotNullAndNotEmpty;
const getEmptyStringEntity = (stringInterner) => {
    const emptyContent = '';
    const interningResults = stringInterner(emptyContent);
    return {
        type: exports.stringType,
        ref: interningResults.reference,
        data: emptyContent,
    };
};
exports.getEmptyStringEntity = getEmptyStringEntity;
const queryHandlerFromFunction = (handle) => ({
    handle,
});
exports.queryHandlerFromFunction = queryHandlerFromFunction;
const createEmptyReferenceIdMap = () => new Map();
const createGenericInterner = (initialState, getReferenceIfItemExists, addMissingItemToState) => {
    let currentState = initialState;
    return (input) => {
        const reference = getReferenceIfItemExists(currentState, input);
        if (reference !== undefined) {
            return {
                isExisted: true,
                reference,
            };
        }
        const [newState, newReference] = addMissingItemToState(currentState, input);
        currentState = newState;
        return {
            isExisted: false,
            reference: newReference,
        };
    };
};
const createInternerByKey = (getKey, getInitialMap = createEmptyReferenceIdMap) => () => createGenericInterner(getInitialMap(), (map, item) => map.get(getKey(item)), (map, item) => {
    const reference = map.size;
    const key = getKey(item);
    map.set(key, reference);
    return [map, reference];
});
exports.createInternerByKey = createInternerByKey;
const getNextMessageIndexBuilder = () => {
    let messageIndex = 0;
    return () => {
        const currentIndex = messageIndex;
        messageIndex += 1;
        return currentIndex;
    };
};
exports.getNextMessageIndexBuilder = getNextMessageIndexBuilder;
const createEmptyReferenceIdMapWithEmptyString = () => new Map([['', 0]]);
exports.createNewStringInterner = (0, exports.createInternerByKey)((str) => str, createEmptyReferenceIdMapWithEmptyString);
const createUserSetInterner = (0, exports.createInternerByKey)(JSON.stringify);
const createInternerSet = () => {
    const participantMap = new Map();
    return {
        stringInterner: (0, exports.createNewStringInterner)(),
        threadId: (0, exports.createNewStringInterner)(),
        participantInterner: (0, exports.createInternerByKey)((rec) => rec.id, () => participantMap)(),
        userSetInterner: createUserSetInterner(),
    };
};
exports.createInternerSet = createInternerSet;
const getHeaderEntity = (customerInitials, fileName, sourceKey) => ({
    type: exports.headerType,
    sourceKey,
    fileName,
    customerInitials,
});
exports.getHeaderEntity = getHeaderEntity;
const getStartingEntities = (customerInitials, fileName, sourceKey, stringInterner) => {
    const header = (0, exports.getHeaderEntity)(customerInitials, fileName, sourceKey);
    const emptyString = (0, exports.getEmptyStringEntity)(stringInterner);
    return [header, emptyString];
};
exports.getStartingEntities = getStartingEntities;
const userSchema = zod_1.z.object({
    id: zod_1.z.string(),
    displayName: zod_1.z.string(),
    mail: zod_1.z.string().email().nullable(),
});
const usersSchema = zod_1.z.array(userSchema);
exports.msGraphUsersResponseSchema = zod_1.z.object({
    '@odata.context': zod_1.z.string().url(),
    'value': usersSchema,
});
const msGraphUserFetchResponseSuccessSchema = zod_1.z.object({
    id: zod_1.z.string(),
    status: zod_1.z.literal(pure_utils_1.httpStatusCodes.ok),
    body: zod_1.z.object({
        displayName: zod_1.z.string(),
        mail: zod_1.z.string().nullable(),
        id: zod_1.z.string(),
    }),
});
const msGraphUserFetchResponseOtherSchema = zod_1.z.object({
    id: zod_1.z.string(),
    status: zod_1.z.number(),
    body: zod_1.z.record(zod_1.z.unknown()),
});
const msGraphUsersListResponseUnionSchema = zod_1.z.union([
    msGraphUserFetchResponseSuccessSchema,
    msGraphUserFetchResponseOtherSchema,
]);
exports.msGraphBatchUserFetchResponseSchema = zod_1.z.object({
    responses: zod_1.z.array(msGraphUsersListResponseUnionSchema),
});
const isSuccessResponse = (response) => response.status === pure_utils_1.httpStatusCodes.ok;
const transformUsersInfo = (successResponse) => ({
    displayName: successResponse.body.displayName,
    id: successResponse.body.id,
    mail: successResponse.body.mail,
});
const buildBatchRequests = (userIds) => userIds.map((userId, idx) => ({
    id: idx.toString(),
    method: 'GET',
    url: `/users/${userId}`,
}));
exports.buildBatchRequests = buildBatchRequests;
const MAX_MS_BATCH_REQUESTS = 20;
const getMsGraphUsersBatchRequest = async (userIds, graphApiBatchedQuery) => {
    const response = await graphApiBatchedQuery.handle({
        urlPrefix: '/users/',
        batchIds: userIds,
    });
    return exports.msGraphBatchUserFetchResponseSchema.parse(response);
};
exports.getMsGraphUsersBatchRequest = getMsGraphUsersBatchRequest;
const getAllParticipantUsers = async (userIds, graphApiBatchedQuery) => {
    const userIdBatches = (0, pure_utils_1.batch)(MAX_MS_BATCH_REQUESTS)(userIds);
    const promises = userIdBatches.map(async (userIdBatch) => (0, exports.getMsGraphUsersBatchRequest)(userIdBatch, graphApiBatchedQuery));
    const batchRequestResponses = await Promise.all(promises);
    return batchRequestResponses.map(r => r.responses).flat().filter(isSuccessResponse).map(transformUsersInfo);
};
exports.getAllParticipantUsers = getAllParticipantUsers;
const ifTrueAddOptionalField = (fieldName, value) => (0, pure_utils_1.conditionalField)(fieldName, value, (x) => x === true);
exports.ifTrueAddOptionalField = ifTrueAddOptionalField;
const ifDefinedAndNotNullAndNotEmptyThenAddOptionalField = (fieldName, value) => (0, pure_utils_1.conditionalField)(fieldName, value, exports.notUndefinedAndNotNullAndNotEmpty);
exports.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField = ifDefinedAndNotNullAndNotEmptyThenAddOptionalField;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/auth/accessTokenGetter.ts":
/*!********************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/auth/accessTokenGetter.ts ***!
  \********************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AccessTokenGetter = void 0;
const utils_1 = __webpack_require__(/*! ../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class AccessTokenGetter {
    credentialsGetter;
    tenantId;
    constructor(credentialsGetter, tenantId) {
        this.credentialsGetter = credentialsGetter;
        this.tenantId = tenantId;
    }
    async handle() {
        const credentials = await this.credentialsGetter.handle(this.tenantId);
        if (!credentials) {
            throw Error('Wrong or missing MS Graph API credentials.');
        }
        return (0, utils_1.getAccessToken)(credentials);
    }
}
exports.AccessTokenGetter = AccessTokenGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/auth/accessTokenGetterFactory.ts":
/*!***************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/auth/accessTokenGetterFactory.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AccessTokenGetterFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const common_2 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const accessTokenGetter_1 = __webpack_require__(/*! ./accessTokenGetter */ "./src/services/teamsHistorical/lib/auth/accessTokenGetter.ts");
let AccessTokenGetterFactory = class AccessTokenGetterFactory {
    credentialsGetter;
    constructor(credentialsGetter) {
        this.credentialsGetter = credentialsGetter;
    }
    handle(tenantId) {
        return new accessTokenGetter_1.AccessTokenGetter(this.credentialsGetter, tenantId);
    }
};
AccessTokenGetterFactory = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(common_2.CREDENTIALS_GETTER_TOKEN)),
    __metadata("design:paramtypes", [Object])
], AccessTokenGetterFactory);
exports.AccessTokenGetterFactory = AccessTokenGetterFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/auth/cachedAccessTokenGetter.ts":
/*!**************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/auth/cachedAccessTokenGetter.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CachedAccessTokenGetter = void 0;
class CachedAccessTokenGetter {
    accessTokenGetter;
    cachedToken;
    constructor(accessTokenGetter) {
        this.accessTokenGetter = accessTokenGetter;
        this.cachedToken = this.accessTokenGetter.handle();
    }
    async handle() {
        return {
            token: await this.cachedToken,
            refreshAndGetToken: async () => {
                const newCachedToken = this.accessTokenGetter.handle();
                this.cachedToken = newCachedToken;
                return newCachedToken;
            },
        };
    }
}
exports.CachedAccessTokenGetter = CachedAccessTokenGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/authenticatingGraphApiQuery.ts":
/*!*************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/authenticatingGraphApiQuery.ts ***!
  \*************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AuthenticatingGraphApiQuery = void 0;
const axios_1 = __webpack_require__(/*! axios */ "./node_modules/axios/dist/node/axios.cjs");
const AUTH_ATTEMPTS_COUNT = 3;
class AuthenticatingGraphApiQuery {
    queryHandler;
    accessTokenGetter;
    constructor(queryHandler, accessTokenGetter) {
        this.queryHandler = queryHandler;
        this.accessTokenGetter = accessTokenGetter;
    }
    async handle(query) {
        let counter = 0;
        while (counter < AUTH_ATTEMPTS_COUNT) {
            const { token, refreshAndGetToken } = await this.accessTokenGetter.handle();
            try {
                return await this.queryHandler.handle({
                    query,
                    token,
                });
            }
            catch (error) {
                if (!(error instanceof axios_1.AxiosError) || error.status !== axios_1.HttpStatusCode.Unauthorized) {
                    throw error;
                }
                await refreshAndGetToken();
                counter += 1;
            }
        }
        throw new Error(`Unauthorized after ${AUTH_ATTEMPTS_COUNT} attempts`);
    }
}
exports.AuthenticatingGraphApiQuery = AuthenticatingGraphApiQuery;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/constants.ts":
/*!*******************************************************!*\
  !*** ./src/services/teamsHistorical/lib/constants.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TEAMS_SOURCE_KEY = exports.MS_MESSAGE_TYPE_VALUE = exports.CREDENTIALS_QUERY_TOKEN = exports.COUNT_RESPONSE_KEY = exports.NEXT_LINK_RESPONSE_KEY = exports.MS_GRAPH_API_URL = void 0;
exports.MS_GRAPH_API_URL = 'https://graph.microsoft.com';
exports.NEXT_LINK_RESPONSE_KEY = '@odata.nextLink';
exports.COUNT_RESPONSE_KEY = '@odata.count';
exports.CREDENTIALS_QUERY_TOKEN = 'credentials-query';
exports.MS_MESSAGE_TYPE_VALUE = 'message';
exports.TEAMS_SOURCE_KEY = 'teams';


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/channels/channelInfoGetter.ts":
/*!********************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/channels/channelInfoGetter.ts ***!
  \********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChannelInfoGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class ChannelInfoGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createDataGetter)(utils_1.buildChannelInfoQueryPostfix, value => types_1.channelRawInfoSchema.parse(value), this.queryHandler);
    }
    async handle(teamAndChannelId) {
        return this.dataGetter(teamAndChannelId);
    }
}
exports.ChannelInfoGetter = ChannelInfoGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/channels/channelsMessagesGetter.ts":
/*!*************************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/channels/channelsMessagesGetter.ts ***!
  \*************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChannelsMessagesGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class ChannelsMessagesGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildChannelMessagesQueryPostfix, value => types_1.channelRawMessageSchema.parse(value), this.queryHandler);
    }
    handle(re) {
        return this.dataGetter(re);
    }
}
exports.ChannelsMessagesGetter = ChannelsMessagesGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/channels/channelsParticipantsGetter.ts":
/*!*****************************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/channels/channelsParticipantsGetter.ts ***!
  \*****************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChannelsParticipantsGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class ChannelsParticipantsGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildChannelParticipantsQueryPostfix, value => types_1.aadUserConversationMember.parse(value), this.queryHandler);
    }
    handle(teamAndChannelId) {
        return this.dataGetter(teamAndChannelId);
    }
}
exports.ChannelsParticipantsGetter = ChannelsParticipantsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/channels/teamsGetter.ts":
/*!**************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/channels/teamsGetter.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class TeamsGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildTeamsQueryPostfix, value => types_1.teamSchema.parse(value), this.queryHandler);
    }
    handle() {
        return this.dataGetter(null);
    }
}
exports.TeamsGetter = TeamsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/chats/chatInfoGetter.ts":
/*!**************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/chats/chatInfoGetter.ts ***!
  \**************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChatInfoGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class ChatInfoGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createDataGetter)(utils_1.buildChatInfoQueryPostfix, value => types_1.chatRawInfoSchema.parse(value), this.queryHandler);
    }
    async handle(chatId) {
        return this.dataGetter(chatId);
    }
}
exports.ChatInfoGetter = ChatInfoGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/chats/chatsMessagesGetter.ts":
/*!*******************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/chats/chatsMessagesGetter.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChatsMessagesGetter = exports.chatsMessagesWithWrongLicensedUserGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
const axios_1 = __webpack_require__(/*! axios */ "./node_modules/axios/dist/node/axios.cjs");
const util_1 = __webpack_require__(/*! util */ "util");
const logger_1 = __webpack_require__(/*! ../../../../../core/logger */ "./src/core/logger.ts");
const logger = (0, logger_1.getLogger)(__filename);
const paymentRequireStatusMsGraphApiCode = 'PaymentRequired';
const isPaymentRequireError = (error) => error.response?.status === axios_1.HttpStatusCode.PaymentRequired ||
    error.response?.data.code === paymentRequireStatusMsGraphApiCode;
const chatsMessagesWithWrongLicensedUserGetter = (getter, userWrongLicenseDbWriter) => (req) => ({
    async *[Symbol.asyncIterator]() {
        try {
            const res = await getter.handle(req);
            yield* res;
        }
        catch (error) {
            const maybeAxiosError = error;
            if (error instanceof axios_1.AxiosError && isPaymentRequireError(maybeAxiosError)) {
                logger.error(`${paymentRequireStatusMsGraphApiCode}; ${(0, util_1.inspect)(maybeAxiosError.response?.data)} for ${(0, util_1.inspect)(req)}`);
                await userWrongLicenseDbWriter(req, paymentRequireStatusMsGraphApiCode);
                return;
            }
            throw error;
        }
    },
});
exports.chatsMessagesWithWrongLicensedUserGetter = chatsMessagesWithWrongLicensedUserGetter;
class ChatsMessagesGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildChatMessagesQueryPostfix, value => types_1.chatRawMessageSchema.parse(value), this.queryHandler);
    }
    handle(dataRequest) {
        return this.dataGetter(dataRequest);
    }
}
exports.ChatsMessagesGetter = ChatsMessagesGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/chats/chatsParticipantsGetter.ts":
/*!***********************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/chats/chatsParticipantsGetter.ts ***!
  \***********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ChatsParticipantsGetter = exports.wrapForbiddenInsufficientPermissionsForChatsParticipantsGetter = exports.forbiddenInsufficientPermissionErrorType = void 0;
const axios_1 = __webpack_require__(/*! axios */ "./node_modules/axios/dist/node/axios.cjs");
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
exports.forbiddenInsufficientPermissionErrorType = 'ForbiddenInsufficientPermissionsToGetChatParticipants';
const forbiddenStatusMsGraphApiCode = 'Forbidden';
const insufficientPrivilegesMsGraphApiMessage = 'InsufficientPrivileges';
const isForbiddenError = (error) => (0, axios_1.isAxiosError)(error) &&
    'response' in error &&
    'error' in error.response.data &&
    'message' in error.response.data.error &&
    (0, pure_utils_1.isPlainObject)(error.response.data.error) &&
    error.response.data.error.message === insufficientPrivilegesMsGraphApiMessage &&
    error.response.data.error.code === forbiddenStatusMsGraphApiCode;
const wrapForbiddenInsufficientPermissionsForChatsParticipantsGetter = (getter) => async (chatId) => {
    try {
        const asyncIterable = await getter.handle(chatId);
        const asyncIterator = asyncIterable[Symbol.asyncIterator]();
        const firstItem = await asyncIterator.next();
        if (firstItem.done) {
            return (0, pure_utils_1.success)((0, pure_utils_1.createAsyncIterable)([]));
        }
        return (0, pure_utils_1.success)({
            async *[Symbol.asyncIterator]() {
                yield firstItem.value;
                do {
                    const item = await asyncIterator.next();
                    if (item.done) {
                        break;
                    }
                    yield item.value;
                } while (true);
            },
        });
    }
    catch (error) {
        if (isForbiddenError(error)) {
            return (0, pure_utils_1.failure)({
                type: exports.forbiddenInsufficientPermissionErrorType,
                message: error.message,
            });
        }
        return (0, pure_utils_1.failure)((0, pure_utils_1.transformExceptionToUnknownError)(error));
    }
};
exports.wrapForbiddenInsufficientPermissionsForChatsParticipantsGetter = wrapForbiddenInsufficientPermissionsForChatsParticipantsGetter;
class ChatsParticipantsGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildChatsUsersQueryPostfix, value => types_1.rawMemberDataSchema.parse(value), this.queryHandler);
    }
    handle(chatId) {
        return this.dataGetter(chatId);
    }
}
exports.ChatsParticipantsGetter = ChatsParticipantsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/chats/teamsUserIdsByCustomerIdGetter.ts":
/*!******************************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/chats/teamsUserIdsByCustomerIdGetter.ts ***!
  \******************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsUsersByCustomerIdGetter = void 0;
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
const EMAILS_BATCH_SIZE = 15;
class TeamsUsersByCustomerIdGetter {
    usersByEmailsGetter;
    genericBatchedGetter;
    constructor(usersByEmailsGetter) {
        this.usersByEmailsGetter = usersByEmailsGetter;
        this.genericBatchedGetter = (0, utils_1.prepareGenericBatchedGetter)(EMAILS_BATCH_SIZE, usersByEmailsGetter.handle.bind(usersByEmailsGetter));
    }
    handle(jobParameters) {
        return this.genericBatchedGetter(jobParameters.emails);
    }
}
exports.TeamsUsersByCustomerIdGetter = TeamsUsersByCustomerIdGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/chats/usersByEmailsGetter.ts":
/*!*******************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/chats/usersByEmailsGetter.ts ***!
  \*******************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UsersByEmailsGetter = void 0;
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
class UsersByEmailsGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildUsersQueryPostfix, value => types_1.chatUsersRawSchema.parse(value), this.queryHandler);
    }
    handle(emails) {
        return this.dataGetter(emails);
    }
}
exports.UsersByEmailsGetter = UsersByEmailsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetter.ts":
/*!**********************************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetter.ts ***!
  \**********************************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DistributionListMemberEmailsGetter = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const common_1 = __webpack_require__(/*! ../../../common */ "./src/services/teamsHistorical/common.ts");
const getGroupsMembers = (groups, groupMembersGetter) => ({
    async *[Symbol.asyncIterator]() {
        for (const group of groups) {
            const members = groupMembersGetter.handle(group.id);
            yield* members;
        }
    },
});
class DistributionListMemberEmailsGetter {
    groupsGetter;
    groupMembersGetter;
    constructor(groupsGetter, groupMembersGetter) {
        this.groupsGetter = groupsGetter;
        this.groupMembersGetter = groupMembersGetter;
    }
    async handle(distributionListEmails) {
        const groups = await (0, pure_utils_1.convertAsyncIterableToArray)(this.groupsGetter.handle(distributionListEmails));
        const groupMembers = getGroupsMembers(groups, this.groupMembersGetter);
        const members = await (0, pure_utils_1.convertAsyncIterableToArray)(groupMembers);
        const matchedGroupsEmails = new Set(groups.map(group => group.mail ?? ''));
        const maybeIndividualUsersEmails = distributionListEmails.filter(email => !matchedGroupsEmails.has(email));
        const emails = (0, pure_utils_1.getUniqueValues)(members.map(member => member.mail)).filter(common_1.notUndefinedAndNotNullAndNotEmpty);
        return [...emails, ...maybeIndividualUsersEmails];
    }
}
exports.DistributionListMemberEmailsGetter = DistributionListMemberEmailsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetterFactory.ts":
/*!*****************************************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetterFactory.ts ***!
  \*****************************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DistributionListMemberEmailsGetterFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const graphApiQueryFactory_1 = __webpack_require__(/*! ../../graphApiQueryFactory */ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts");
const groupsGetter_1 = __webpack_require__(/*! ./groupsGetter */ "./src/services/teamsHistorical/lib/getters/lists/groupsGetter.ts");
const groupMembersGetter_1 = __webpack_require__(/*! ./groupMembersGetter */ "./src/services/teamsHistorical/lib/getters/lists/groupMembersGetter.ts");
const distributionListMemberEmailsGetter_1 = __webpack_require__(/*! ./distributionListMemberEmailsGetter */ "./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetter.ts");
let DistributionListMemberEmailsGetterFactory = class DistributionListMemberEmailsGetterFactory {
    graphApiQueryFactory;
    constructor(graphApiQueryFactory) {
        this.graphApiQueryFactory = graphApiQueryFactory;
    }
    handle(tenantId) {
        const graphApiQueryHandler = this.graphApiQueryFactory.handle(tenantId);
        const groupsGetter = new groupsGetter_1.GroupsGetter(graphApiQueryHandler);
        const groupMembersGetter = new groupMembersGetter_1.GroupMembersGetter(graphApiQueryHandler);
        return new distributionListMemberEmailsGetter_1.DistributionListMemberEmailsGetter(groupsGetter, groupMembersGetter);
    }
};
DistributionListMemberEmailsGetterFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [graphApiQueryFactory_1.GraphApiQueryFactory])
], DistributionListMemberEmailsGetterFactory);
exports.DistributionListMemberEmailsGetterFactory = DistributionListMemberEmailsGetterFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/lists/groupMembersGetter.ts":
/*!******************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/lists/groupMembersGetter.ts ***!
  \******************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GroupMembersGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class GroupMembersGetter {
    queryHandler;
    dataGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.dataGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildGroupMembersQueryPostfix, value => types_1.groupMemberSchema.parse(value), this.queryHandler);
    }
    handle(groupId) {
        return this.dataGetter(groupId);
    }
}
exports.GroupMembersGetter = GroupMembersGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/lists/groupMembersGetterFactory.ts":
/*!*************************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/lists/groupMembersGetterFactory.ts ***!
  \*************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GroupMembersGetterFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const graphApiQueryFactory_1 = __webpack_require__(/*! ../../graphApiQueryFactory */ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts");
const groupMembersGetter_1 = __webpack_require__(/*! ./groupMembersGetter */ "./src/services/teamsHistorical/lib/getters/lists/groupMembersGetter.ts");
let GroupMembersGetterFactory = class GroupMembersGetterFactory {
    graphApiQueryHandlerFactory;
    constructor(graphApiQueryHandlerFactory) {
        this.graphApiQueryHandlerFactory = graphApiQueryHandlerFactory;
    }
    handle(tenantId) {
        const graphApiQueryHandler = this.graphApiQueryHandlerFactory.handle(tenantId);
        return new groupMembersGetter_1.GroupMembersGetter(graphApiQueryHandler);
    }
};
GroupMembersGetterFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [graphApiQueryFactory_1.GraphApiQueryFactory])
], GroupMembersGetterFactory);
exports.GroupMembersGetterFactory = GroupMembersGetterFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/lists/groupsGetter.ts":
/*!************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/lists/groupsGetter.ts ***!
  \************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GroupsGetter = void 0;
const types_1 = __webpack_require__(/*! ../../types */ "./src/services/teamsHistorical/lib/types.ts");
const utils_1 = __webpack_require__(/*! ../../utils */ "./src/services/teamsHistorical/lib/utils.ts");
class GroupsGetter {
    queryHandler;
    genericBatchedGetter;
    constructor(queryHandler) {
        this.queryHandler = queryHandler;
        this.genericBatchedGetter = (0, utils_1.createPaginatedDataGetter)(utils_1.buildGroupsQueryPostfix, value => types_1.groupSchema.parse(value), this.queryHandler);
    }
    handle(emails) {
        return this.genericBatchedGetter(emails);
    }
}
exports.GroupsGetter = GroupsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/lists/groupsGetterFactory.ts":
/*!*******************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/lists/groupsGetterFactory.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GroupsGetterFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const groupsGetter_1 = __webpack_require__(/*! ./groupsGetter */ "./src/services/teamsHistorical/lib/getters/lists/groupsGetter.ts");
const graphApiQueryFactory_1 = __webpack_require__(/*! ../../graphApiQueryFactory */ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts");
let GroupsGetterFactory = class GroupsGetterFactory {
    graphApiQueryHandlerFactory;
    constructor(graphApiQueryHandlerFactory) {
        this.graphApiQueryHandlerFactory = graphApiQueryHandlerFactory;
    }
    handle(tenantId) {
        const graphApiQueryHandler = this.graphApiQueryHandlerFactory.handle(tenantId);
        return new groupsGetter_1.GroupsGetter(graphApiQueryHandler);
    }
};
GroupsGetterFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [graphApiQueryFactory_1.GraphApiQueryFactory])
], GroupsGetterFactory);
exports.GroupsGetterFactory = GroupsGetterFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/teamsChannelEntityGetters.ts":
/*!*******************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/teamsChannelEntityGetters.ts ***!
  \*******************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsChannelEntityGettersFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const teamsGetter_1 = __webpack_require__(/*! ./channels/teamsGetter */ "./src/services/teamsHistorical/lib/getters/channels/teamsGetter.ts");
const channelsMessagesGetter_1 = __webpack_require__(/*! ./channels/channelsMessagesGetter */ "./src/services/teamsHistorical/lib/getters/channels/channelsMessagesGetter.ts");
const channelsParticipantsGetter_1 = __webpack_require__(/*! ./channels/channelsParticipantsGetter */ "./src/services/teamsHistorical/lib/getters/channels/channelsParticipantsGetter.ts");
const teamsUserIdsByCustomerIdGetter_1 = __webpack_require__(/*! ./chats/teamsUserIdsByCustomerIdGetter */ "./src/services/teamsHistorical/lib/getters/chats/teamsUserIdsByCustomerIdGetter.ts");
const channelInfoGetter_1 = __webpack_require__(/*! ./channels/channelInfoGetter */ "./src/services/teamsHistorical/lib/getters/channels/channelInfoGetter.ts");
const userEmailsByIdsGetter_1 = __webpack_require__(/*! ./userEmailsByIdsGetter */ "./src/services/teamsHistorical/lib/getters/userEmailsByIdsGetter.ts");
const usersByEmailsGetter_1 = __webpack_require__(/*! ./chats/usersByEmailsGetter */ "./src/services/teamsHistorical/lib/getters/chats/usersByEmailsGetter.ts");
const graphApiQueryFactory_1 = __webpack_require__(/*! ../graphApiQueryFactory */ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts");
const graphApiBatchedQueryFactory_1 = __webpack_require__(/*! ../graphApiBatchedQueryFactory */ "./src/services/teamsHistorical/lib/graphApiBatchedQueryFactory.ts");
let TeamsChannelEntityGettersFactory = class TeamsChannelEntityGettersFactory {
    graphApiQueryFactory;
    graphApiBatchedQueryFactory;
    constructor(graphApiQueryFactory, graphApiBatchedQueryFactory) {
        this.graphApiQueryFactory = graphApiQueryFactory;
        this.graphApiBatchedQueryFactory = graphApiBatchedQueryFactory;
    }
    handle(tenantId) {
        const graphApiQueryHandler = this.graphApiQueryFactory.handle(tenantId);
        const graphApiBatchedQueryHandler = this.graphApiBatchedQueryFactory.handle(tenantId);
        const usersByEmailsGetter = new usersByEmailsGetter_1.UsersByEmailsGetter(graphApiQueryHandler);
        return {
            teamsGetter: new teamsGetter_1.TeamsGetter(graphApiQueryHandler),
            participantsGetter: new channelsParticipantsGetter_1.ChannelsParticipantsGetter(graphApiQueryHandler),
            userEmailsByIdsGetter: new userEmailsByIdsGetter_1.UserEmailsByIdsGetter(graphApiBatchedQueryHandler),
            messagesGetter: new channelsMessagesGetter_1.ChannelsMessagesGetter(graphApiQueryHandler),
            threadInfoGetter: new channelInfoGetter_1.ChannelInfoGetter(graphApiQueryHandler),
            usersByCustomerIdGetter: new teamsUserIdsByCustomerIdGetter_1.TeamsUsersByCustomerIdGetter(usersByEmailsGetter),
        };
    }
};
TeamsChannelEntityGettersFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [graphApiQueryFactory_1.GraphApiQueryFactory,
        graphApiBatchedQueryFactory_1.GraphApiBatchedQueryFactory])
], TeamsChannelEntityGettersFactory);
exports.TeamsChannelEntityGettersFactory = TeamsChannelEntityGettersFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/teamsChatsEntityGetters.ts":
/*!*****************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/teamsChatsEntityGetters.ts ***!
  \*****************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsChatEntityGettersFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const chatsParticipantsGetter_1 = __webpack_require__(/*! ./chats/chatsParticipantsGetter */ "./src/services/teamsHistorical/lib/getters/chats/chatsParticipantsGetter.ts");
const chatsMessagesGetter_1 = __webpack_require__(/*! ./chats/chatsMessagesGetter */ "./src/services/teamsHistorical/lib/getters/chats/chatsMessagesGetter.ts");
const teamsUserIdsByCustomerIdGetter_1 = __webpack_require__(/*! ./chats/teamsUserIdsByCustomerIdGetter */ "./src/services/teamsHistorical/lib/getters/chats/teamsUserIdsByCustomerIdGetter.ts");
const chatInfoGetter_1 = __webpack_require__(/*! ./chats/chatInfoGetter */ "./src/services/teamsHistorical/lib/getters/chats/chatInfoGetter.ts");
const userEmailsByIdsGetter_1 = __webpack_require__(/*! ./userEmailsByIdsGetter */ "./src/services/teamsHistorical/lib/getters/userEmailsByIdsGetter.ts");
const usersByEmailsGetter_1 = __webpack_require__(/*! ./chats/usersByEmailsGetter */ "./src/services/teamsHistorical/lib/getters/chats/usersByEmailsGetter.ts");
const graphApiQueryFactory_1 = __webpack_require__(/*! ../graphApiQueryFactory */ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts");
const graphApiBatchedQueryFactory_1 = __webpack_require__(/*! ../graphApiBatchedQueryFactory */ "./src/services/teamsHistorical/lib/graphApiBatchedQueryFactory.ts");
let TeamsChatEntityGettersFactory = class TeamsChatEntityGettersFactory {
    graphApiQueryFactory;
    graphApiBatchedQueryFactory;
    constructor(graphApiQueryFactory, graphApiBatchedQueryFactory) {
        this.graphApiQueryFactory = graphApiQueryFactory;
        this.graphApiBatchedQueryFactory = graphApiBatchedQueryFactory;
    }
    handle(tenantId) {
        const graphApiQueryHandler = this.graphApiQueryFactory.handle(tenantId);
        const graphApiBatchedQueryHandler = this.graphApiBatchedQueryFactory.handle(tenantId);
        const usersByEmailsGetter = new usersByEmailsGetter_1.UsersByEmailsGetter(graphApiQueryHandler);
        return {
            userEmailsByIdsGetter: new userEmailsByIdsGetter_1.UserEmailsByIdsGetter(graphApiBatchedQueryHandler),
            usersByCustomerIdGetter: new teamsUserIdsByCustomerIdGetter_1.TeamsUsersByCustomerIdGetter(usersByEmailsGetter),
            participantsGetter: new chatsParticipantsGetter_1.ChatsParticipantsGetter(graphApiQueryHandler),
            messagesGetter: new chatsMessagesGetter_1.ChatsMessagesGetter(graphApiQueryHandler),
            threadInfoGetter: new chatInfoGetter_1.ChatInfoGetter(graphApiQueryHandler),
        };
    }
};
TeamsChatEntityGettersFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [graphApiQueryFactory_1.GraphApiQueryFactory,
        graphApiBatchedQueryFactory_1.GraphApiBatchedQueryFactory])
], TeamsChatEntityGettersFactory);
exports.TeamsChatEntityGettersFactory = TeamsChatEntityGettersFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/getters/userEmailsByIdsGetter.ts":
/*!***************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/getters/userEmailsByIdsGetter.ts ***!
  \***************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.UserEmailsByIdsGetter = void 0;
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const userEmailsByIdsGetter = (graphApiBatchedQueryHandler) => (userIds) => ({
    async *[Symbol.asyncIterator]() {
        const users = await (0, common_1.getAllParticipantUsers)(userIds, graphApiBatchedQueryHandler);
        yield* users.map(user => ({
            ...user,
            email: user.mail,
        }));
    },
});
class UserEmailsByIdsGetter {
    genericBatchedGetter;
    constructor(graphApiBatchedQueryHandler) {
        this.genericBatchedGetter = userEmailsByIdsGetter(graphApiBatchedQueryHandler);
    }
    handle(ids) {
        return this.genericBatchedGetter(ids);
    }
}
exports.UserEmailsByIdsGetter = UserEmailsByIdsGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/graphApiAxiosInstance.ts":
/*!*******************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/graphApiAxiosInstance.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GraphApiAxiosInstance = void 0;
const axios_1 = __importDefault(__webpack_require__(/*! axios */ "./node_modules/axios/dist/node/axios.cjs"));
const axios_retry_1 = __importDefault(__webpack_require__(/*! axios-retry */ "./node_modules/axios-retry/dist/cjs/index.js"));
const axios_request_throttle_1 = __importDefault(__webpack_require__(/*! axios-request-throttle */ "./node_modules/axios-request-throttle/lib/index.js"));
const utils_1 = __webpack_require__(/*! ./utils */ "./src/services/teamsHistorical/lib/utils.ts");
const constants_1 = __webpack_require__(/*! ./constants */ "./src/services/teamsHistorical/lib/constants.ts");
class GraphApiAxiosInstance {
    instance;
    constructor() {
        this.instance = axios_1.default.create({
            baseURL: constants_1.MS_GRAPH_API_URL,
        });
        const THROTTLE_REQUESTS_PER_SECOND = 20;
        const RETRIES_COUNT = 3;
        (0, axios_retry_1.default)(this.instance, (0, utils_1.getRetryConfig)(RETRIES_COUNT));
        axios_request_throttle_1.default.use(this.instance, { requestsPerSecond: THROTTLE_REQUESTS_PER_SECOND });
    }
    handle() {
        return this.instance;
    }
}
exports.GraphApiAxiosInstance = GraphApiAxiosInstance;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/graphApiAxiosInstanceFactory.ts":
/*!**************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/graphApiAxiosInstanceFactory.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GraphApiAxiosInstanceFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const logger_1 = __webpack_require__(/*! ../../../core/logger */ "./src/core/logger.ts");
const graphApiAxiosInstance_1 = __webpack_require__(/*! ./graphApiAxiosInstance */ "./src/services/teamsHistorical/lib/graphApiAxiosInstance.ts");
const logger = (0, logger_1.getLogger)(__filename);
let GraphApiAxiosInstanceFactory = class GraphApiAxiosInstanceFactory {
    cachedInstances = new Map();
    handle(tenantId) {
        const existingInstance = this.cachedInstances.get(tenantId);
        if (!existingInstance) {
            const newInstance = new graphApiAxiosInstance_1.GraphApiAxiosInstance();
            logger.info(`Axios instance for tenant ${tenantId} has been created`);
            this.cachedInstances.set(tenantId, newInstance);
            return newInstance;
        }
        return existingInstance;
    }
};
GraphApiAxiosInstanceFactory = __decorate([
    (0, common_1.Injectable)()
], GraphApiAxiosInstanceFactory);
exports.GraphApiAxiosInstanceFactory = GraphApiAxiosInstanceFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/graphApiBatchedQuery.ts":
/*!******************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/graphApiBatchedQuery.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GraphApiBatchedQuery = void 0;
const logger_1 = __webpack_require__(/*! ../../../core/logger */ "./src/core/logger.ts");
const logger = (0, logger_1.getLogger)(__filename);
class GraphApiBatchedQuery {
    graphApiAxiosInstance;
    constructor(graphApiAxiosInstance) {
        this.graphApiAxiosInstance = graphApiAxiosInstance;
    }
    async handle(input) {
        logger.debug(`GraphApiBatchedQuery requesting POST: ${JSON.stringify(input)}`);
        const axios = this.graphApiAxiosInstance.handle();
        const response = await axios.post('v1.0/$batch', {
            requests: input.query.batchIds.map(id => ({
                id,
                method: 'GET',
                url: input.query.urlPrefix + id,
            })),
        }, {
            headers: {
                Authorization: `Bearer ${input.token}`,
                'Content-Type': 'application/json',
                Accept: 'application/json',
            },
        });
        return response.data;
    }
}
exports.GraphApiBatchedQuery = GraphApiBatchedQuery;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/graphApiBatchedQueryFactory.ts":
/*!*************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/graphApiBatchedQueryFactory.ts ***!
  \*************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GraphApiBatchedQueryFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const accessTokenGetterFactory_1 = __webpack_require__(/*! ./auth/accessTokenGetterFactory */ "./src/services/teamsHistorical/lib/auth/accessTokenGetterFactory.ts");
const cachedAccessTokenGetter_1 = __webpack_require__(/*! ./auth/cachedAccessTokenGetter */ "./src/services/teamsHistorical/lib/auth/cachedAccessTokenGetter.ts");
const authenticatingGraphApiQuery_1 = __webpack_require__(/*! ./authenticatingGraphApiQuery */ "./src/services/teamsHistorical/lib/authenticatingGraphApiQuery.ts");
const graphApiAxiosInstanceFactory_1 = __webpack_require__(/*! ./graphApiAxiosInstanceFactory */ "./src/services/teamsHistorical/lib/graphApiAxiosInstanceFactory.ts");
const graphApiBatchedQuery_1 = __webpack_require__(/*! ./graphApiBatchedQuery */ "./src/services/teamsHistorical/lib/graphApiBatchedQuery.ts");
let GraphApiBatchedQueryFactory = class GraphApiBatchedQueryFactory {
    accessTokenGetterFactory;
    graphApiAxiosInstanceFactory;
    constructor(accessTokenGetterFactory, graphApiAxiosInstanceFactory) {
        this.accessTokenGetterFactory = accessTokenGetterFactory;
        this.graphApiAxiosInstanceFactory = graphApiAxiosInstanceFactory;
    }
    handle(tenantId) {
        const accessTokenGetter = this.accessTokenGetterFactory.handle(tenantId);
        const graphApiAxiosInstance = this.graphApiAxiosInstanceFactory.handle(tenantId);
        const cachedAccessTokenGetter = new cachedAccessTokenGetter_1.CachedAccessTokenGetter(accessTokenGetter);
        return new authenticatingGraphApiQuery_1.AuthenticatingGraphApiQuery(new graphApiBatchedQuery_1.GraphApiBatchedQuery(graphApiAxiosInstance), cachedAccessTokenGetter);
    }
};
GraphApiBatchedQueryFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [accessTokenGetterFactory_1.AccessTokenGetterFactory,
        graphApiAxiosInstanceFactory_1.GraphApiAxiosInstanceFactory])
], GraphApiBatchedQueryFactory);
exports.GraphApiBatchedQueryFactory = GraphApiBatchedQueryFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/graphApiQuery.ts":
/*!***********************************************************!*\
  !*** ./src/services/teamsHistorical/lib/graphApiQuery.ts ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GraphApiGetQuery = void 0;
const logger_1 = __webpack_require__(/*! ../../../core/logger */ "./src/core/logger.ts");
const logger = (0, logger_1.getLogger)(__filename);
class GraphApiGetQuery {
    graphApiAxiosInstanceHandler;
    constructor(graphApiAxiosInstanceHandler) {
        this.graphApiAxiosInstanceHandler = graphApiAxiosInstanceHandler;
    }
    async handle(input) {
        logger.debug(`SimpleGraphApiQuery requesting GET: ${input.query}`);
        const axios = this.graphApiAxiosInstanceHandler.handle();
        const response = await axios.get(input.query, {
            headers: {
                Authorization: `Bearer ${input.token}`,
            },
        });
        return response.data;
    }
}
exports.GraphApiGetQuery = GraphApiGetQuery;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts":
/*!******************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/graphApiQueryFactory.ts ***!
  \******************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.GraphApiQueryFactory = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const graphApiQuery_1 = __webpack_require__(/*! ./graphApiQuery */ "./src/services/teamsHistorical/lib/graphApiQuery.ts");
const accessTokenGetterFactory_1 = __webpack_require__(/*! ./auth/accessTokenGetterFactory */ "./src/services/teamsHistorical/lib/auth/accessTokenGetterFactory.ts");
const graphApiAxiosInstanceFactory_1 = __webpack_require__(/*! ./graphApiAxiosInstanceFactory */ "./src/services/teamsHistorical/lib/graphApiAxiosInstanceFactory.ts");
const cachedAccessTokenGetter_1 = __webpack_require__(/*! ./auth/cachedAccessTokenGetter */ "./src/services/teamsHistorical/lib/auth/cachedAccessTokenGetter.ts");
const authenticatingGraphApiQuery_1 = __webpack_require__(/*! ./authenticatingGraphApiQuery */ "./src/services/teamsHistorical/lib/authenticatingGraphApiQuery.ts");
let GraphApiQueryFactory = class GraphApiQueryFactory {
    accessTokenGetterFactory;
    graphApiAxiosInstanceFactory;
    constructor(accessTokenGetterFactory, graphApiAxiosInstanceFactory) {
        this.accessTokenGetterFactory = accessTokenGetterFactory;
        this.graphApiAxiosInstanceFactory = graphApiAxiosInstanceFactory;
    }
    handle(tenantId) {
        const accessTokenGetter = this.accessTokenGetterFactory.handle(tenantId);
        const graphApiAxiosInstance = this.graphApiAxiosInstanceFactory.handle(tenantId);
        const cachedAccessTokenGetter = new cachedAccessTokenGetter_1.CachedAccessTokenGetter(accessTokenGetter);
        return new authenticatingGraphApiQuery_1.AuthenticatingGraphApiQuery(new graphApiQuery_1.GraphApiGetQuery(graphApiAxiosInstance), cachedAccessTokenGetter);
    }
};
GraphApiQueryFactory = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [accessTokenGetterFactory_1.AccessTokenGetterFactory,
        graphApiAxiosInstanceFactory_1.GraphApiAxiosInstanceFactory])
], GraphApiQueryFactory);
exports.GraphApiQueryFactory = GraphApiQueryFactory;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/channels.ts":
/*!*****************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/channels.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getEntitiesForSingleTeam = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const types_1 = __webpack_require__(/*! ../types */ "./src/services/teamsHistorical/lib/types.ts");
const constants_1 = __webpack_require__(/*! ../constants */ "./src/services/teamsHistorical/lib/constants.ts");
const common_1 = __webpack_require__(/*! ./common */ "./src/services/teamsHistorical/lib/processing/common.ts");
const utils_1 = __webpack_require__(/*! ../utils */ "./src/services/teamsHistorical/lib/utils.ts");
const MESSAGES_CHUNK_SIZE = 20000;
const sortByChannelAndThenByTime = (0, pure_utils_1.sort)((a, b) => {
    const teamComparisonResult = a.channelIdentity.teamId.localeCompare(b.channelIdentity.teamId);
    if (teamComparisonResult !== 0) {
        return teamComparisonResult;
    }
    const channelComparisonResult = a.channelIdentity.channelId.localeCompare(b.channelIdentity.channelId);
    if (channelComparisonResult !== 0) {
        return channelComparisonResult;
    }
    return a.createdDateTime.localeCompare(b.createdDateTime);
});
const chunkWiseSortMessages = (messages, chunkSize) => {
    const chunkedAsyncIterable = (0, pure_utils_1.chunkAsyncIterable)(chunkSize, messages);
    const chunkedSortedAsyncIterable = (0, pure_utils_1.mapAsyncIterable)(chunkedAsyncIterable, sortByChannelAndThenByTime);
    return (0, pure_utils_1.concatAsyncIterables)(chunkedSortedAsyncIterable);
};
const getChannelIds = (message) => ({
    data: {
        teamId: message.channelIdentity.teamId,
        channelId: message.channelIdentity.channelId,
    },
    key: `${message.channelIdentity.teamId}-${message.channelIdentity.channelId}`,
});
const getChannelNameAndDescriptionByInfo = (channelInfo) => ({
    name: channelInfo.displayName,
    description: channelInfo.description,
});
const replaceWithDummyResultfullParticipantsGetter = (entityGetters) => ({
    ...entityGetters,
    participantsGetter: {
        handle: async (id) => {
            const result = await entityGetters.participantsGetter.handle(id);
            return (0, pure_utils_1.success)(result);
        },
    },
});
const getEntitiesForSingleTeam = (input, entityGetters, interners, getNextMessageIndex, maxTimestampUpdater, messageIdSet, monitoredUserIds) => async (team) => {
    const messages = await entityGetters.messagesGetter.handle({
        dateStartExclusiveIso8601: input.dateStartExclusiveUtcIso8601,
        dateEndInclusiveIso8601: input.dateEndInclusiveUtcIso8601,
        userOrTeamId: team.id,
        email: null,
    });
    const filteredMessages = (0, pure_utils_1.filterAsyncIterable)(messages, (message) => {
        const isMessageUnique = !messageIdSet.has(message.id);
        messageIdSet.add(message.id);
        return message.messageType === constants_1.MS_MESSAGE_TYPE_VALUE && isMessageUnique;
    });
    const sortedMessages = chunkWiseSortMessages(filteredMessages, MESSAGES_CHUNK_SIZE);
    const isAnyParticipantMonitored = (participants) => {
        const participantsIds = participants
            .filter(types_1.isAadUserConversationMember)
            .map(p => p.userId);
        const participantsIdSet = new Set(participantsIds);
        return (0, utils_1.hasIntersection)(new Set(monitoredUserIds), participantsIdSet);
    };
    const genericMessageInfoGetters = {
        getNextMessageIndex,
        maxTimestampUpdater,
        getChannelOrChatIds: getChannelIds,
        getChannelOrChatNameAndDescription: getChannelNameAndDescriptionByInfo,
        isAnyParticipantMonitored,
    };
    return (0, common_1.processSortedMessages)(input, team.id, replaceWithDummyResultfullParticipantsGetter(entityGetters), sortedMessages, interners, genericMessageInfoGetters);
};
exports.getEntitiesForSingleTeam = getEntitiesForSingleTeam;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/chats.ts":
/*!**************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/chats.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getEntitiesForSingleUser = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const constants_1 = __webpack_require__(/*! ../constants */ "./src/services/teamsHistorical/lib/constants.ts");
const common_1 = __webpack_require__(/*! ./common */ "./src/services/teamsHistorical/lib/processing/common.ts");
const MESSAGES_CHUNK_SIZE = 10000;
const sortByChatAndThenByTime = (0, pure_utils_1.sort)((a, b) => {
    const chatComparisonResult = a.chatId.localeCompare(b.chatId);
    if (chatComparisonResult !== 0) {
        return chatComparisonResult;
    }
    return a.createdDateTime.localeCompare(b.createdDateTime);
});
const chunkWiseSortMessages = (messages, chunkSize) => {
    const chunkedAsyncIterable = (0, pure_utils_1.chunkAsyncIterable)(chunkSize, messages);
    const chunkedSortedAsyncIterable = (0, pure_utils_1.mapAsyncIterable)(chunkedAsyncIterable, sortByChatAndThenByTime);
    return (0, pure_utils_1.concatAsyncIterables)(chunkedSortedAsyncIterable);
};
const getChatIds = (message) => ({
    data: message.chatId,
    key: message.chatId,
});
const getChatNameByInfo = (chatInfo) => ({
    name: chatInfo.topic,
    description: null,
});
const getEntitiesForSingleUser = (input, entityGetters, interners, getNextMessageIndex, maxTimestampUpdater, messageIdSet) => async (user) => {
    const messageDataRequest = {
        dateStartExclusiveIso8601: input.dateStartExclusiveUtcIso8601,
        dateEndInclusiveIso8601: input.dateEndInclusiveUtcIso8601,
        userOrTeamId: user.id,
        email: user.mail,
    };
    const messages = await entityGetters.messagesGetter.handle(messageDataRequest);
    const filteredMessages = (0, pure_utils_1.filterAsyncIterable)(messages, (message) => {
        const isMessageUnique = !messageIdSet.has(message.id);
        messageIdSet.add(message.id);
        return message.messageType === constants_1.MS_MESSAGE_TYPE_VALUE && isMessageUnique;
    });
    const sortedMessages = chunkWiseSortMessages(filteredMessages, MESSAGES_CHUNK_SIZE);
    const genericMessageInfoGetters = {
        getNextMessageIndex,
        maxTimestampUpdater,
        getChannelOrChatIds: getChatIds,
        getChannelOrChatNameAndDescription: getChatNameByInfo,
        isAnyParticipantMonitored: () => true,
    };
    return (0, common_1.processSortedMessages)(input, user.id, entityGetters, sortedMessages, interners, genericMessageInfoGetters);
};
exports.getEntitiesForSingleUser = getEntitiesForSingleUser;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/common.ts":
/*!***************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/common.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.processSortedMessages = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const types_1 = __webpack_require__(/*! ../types */ "./src/services/teamsHistorical/lib/types.ts");
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const messages_1 = __webpack_require__(/*! ./messages */ "./src/services/teamsHistorical/lib/processing/messages.ts");
const users_1 = __webpack_require__(/*! ./users */ "./src/services/teamsHistorical/lib/processing/users.ts");
const threads_1 = __webpack_require__(/*! ./threads */ "./src/services/teamsHistorical/lib/processing/threads.ts");
const logger_1 = __webpack_require__(/*! ../../../../core/logger */ "./src/core/logger.ts");
const userSets_1 = __webpack_require__(/*! ./userSets */ "./src/services/teamsHistorical/lib/processing/userSets.ts");
const logger = (0, logger_1.getLogger)(__filename);
const addVisibleHistoryStartTimestamp = (participant) => ({
    ...participant,
    visibleHistoryStartTimestamp: new Date(participant.visibleHistoryStartDateTime).getTime(),
});
const sortParticipantsByVisibleHistoryStartTimestampAscending = (0, pure_utils_1.sortByFieldWithComparisonFunction)('visibleHistoryStartTimestamp', pure_utils_1.numOrderingFunctions.descending);
const startThread = async (threadId, channelOrChatIdStr, entityGetters, getChannelOrChatNameAndDescription, userOrTeamId) => {
    logger.info(`Starting thread ${channelOrChatIdStr} for user or team id=${userOrTeamId}`);
    const participantGetterResult = await entityGetters.participantsGetter.handle(threadId);
    const currentParticipants = [];
    let channelOrChatNameAndDescription = undefined;
    if (participantGetterResult.isSuccess) {
        currentParticipants.push(...await (0, pure_utils_1.convertAsyncIterableToArray)(participantGetterResult.value));
        const threadInfo = await entityGetters.threadInfoGetter.handle(threadId);
        channelOrChatNameAndDescription = getChannelOrChatNameAndDescription(threadInfo);
    }
    else if (participantGetterResult.error.type === pure_utils_1.unknownErrorType) {
        throw participantGetterResult.error;
    }
    return {
        threadId,
        channelOrChatIdStr,
        channelOrChatNameAndDescription,
        accumulatedMessages: [],
        currentParticipants,
    };
};
const getSendersIdsExceptCurrentParticipants = (messages, currentParticipantsIdsSet) => new Set(messages.map(message => message.from?.user?.id)
    .filter(common_1.notUndefinedAndNotNullAndNotEmpty)
    .filter(participantId => !currentParticipantsIdsSet.has(participantId)));
const getUserWithIdEqualToUserId = (user) => ({
    ...user,
    id: (0, common_1.notUndefinedAndNotNullAndNotEmpty)(user.userId) ? user.userId : user.id,
});
const getSortedParticipantsStack = async (threadMutableData, userEmailsByIdsGetter) => {
    const aadUserConversationMembers = threadMutableData.currentParticipants
        .filter(types_1.isAadUserConversationMember);
    const participantsWithTs = aadUserConversationMembers
        .map(getUserWithIdEqualToUserId)
        .map(addVisibleHistoryStartTimestamp);
    const currentParticipantsIdsSet = new Set(participantsWithTs.map(p => p.id));
    const sendersIdsExceptCurrentParticipants = getSendersIdsExceptCurrentParticipants(threadMutableData.accumulatedMessages, currentParticipantsIdsSet);
    if (sendersIdsExceptCurrentParticipants.size > 0) {
        const enrichedSenders = await (0, pure_utils_1.convertAsyncIterableToArray)(userEmailsByIdsGetter.handle(Array.from(sendersIdsExceptCurrentParticipants)));
        participantsWithTs.push(...enrichedSenders.map(users_1.createTeamsMemberDataWithTsFromSenderUser));
    }
    return sortParticipantsByVisibleHistoryStartTimestampAscending(participantsWithTs);
};
const prepareThreadFinalization = (userEmailsByIdsGetter, interners, customerId, userOrTeamId, getNextMessageIndex, maxTimestampUpdater, isAnyParticipantMonitored) => (threadMutableData) => ({
    async *[Symbol.asyncIterator]() {
        const sortedParticipantsStack = await getSortedParticipantsStack(threadMutableData, userEmailsByIdsGetter);
        const isIntersectionBetweenParticipantsAndMonitoredUsers = isAnyParticipantMonitored(sortedParticipantsStack);
        if (!isIntersectionBetweenParticipantsAndMonitoredUsers) {
            logger.info(`Thread ${threadMutableData.channelOrChatIdStr}` +
                `for user or team id=${userOrTeamId} doesn't have any monitored participant.`);
            return;
        }
        const threadInterningResults = (0, threads_1.getThreadInterningResults)(threadMutableData, interners);
        const emptyStringReferenceId = (0, common_1.getEmptyStringEntity)(interners.stringInterner).ref;
        const participantById = (0, pure_utils_1.toMap)(sortedParticipantsStack, users_1.getParticipantId, pure_utils_1.identity);
        const currentParticipants = [];
        yield* threadInterningResults.newEntities;
        for (const message of threadMutableData.accumulatedMessages) {
            const { newEntities, allParticipantsRef } = (0, userSets_1.getUserSetDescriptor)(sortedParticipantsStack, message, interners, currentParticipants);
            const maybeSenderRef = (0, users_1.getMaybeSenderRef)(message, participantById, interners);
            const messageContentTextOrHtmlInterningResults = (0, messages_1.getInternedMessageContentTextOrHtml)(message, interners.stringInterner);
            if (messageContentTextOrHtmlInterningResults.newlyCreatedEntry !== undefined) {
                newEntities.push(messageContentTextOrHtmlInterningResults.newlyCreatedEntry);
            }
            const maybeSubjectInterningResult = (0, messages_1.maybeInternSubjectAndSummary)(message.subject, message.summary, interners.stringInterner);
            if (maybeSubjectInterningResult?.newlyCreatedEntry !== undefined) {
                newEntities.push(maybeSubjectInterningResult.newlyCreatedEntry);
            }
            yield* newEntities;
            yield (0, messages_1.createMessageEntry)(message, threadInterningResults, maybeSenderRef, allParticipantsRef, maybeSubjectInterningResult, messageContentTextOrHtmlInterningResults, emptyStringReferenceId, threadMutableData, customerId, userOrTeamId, getNextMessageIndex);
            maxTimestampUpdater(new Date(message.lastModifiedDateTime).getTime());
        }
        logger.info(`Thread ${threadMutableData.channelOrChatIdStr}` +
            `for user or team id=${userOrTeamId} has been finished.`);
    },
});
const prepareGetCurrentThreadAndMaybeStartNewOne = (genericMessageInfoGetters, entityGetters, userOrTeamId) => async (nThreadInfo, message) => {
    const { data: threadId, key: channelOrChatIdStr } = genericMessageInfoGetters.getChannelOrChatIds(message);
    if (nThreadInfo === undefined || threadId !== nThreadInfo.threadId) {
        return startThread(threadId, channelOrChatIdStr, entityGetters, genericMessageInfoGetters.getChannelOrChatNameAndDescription, userOrTeamId);
    }
    return nThreadInfo;
};
const processSortedMessages = (input, userOrTeamId, entityGetters, sortedMessages, interners, genericMessageInfoGetters) => ({
    async *[Symbol.asyncIterator]() {
        const customerId = input.jobParameters.customerId;
        const userEmailsByIdsGetter = entityGetters.userEmailsByIdsGetter;
        const getCurrentThreadAndMaybeStartNewOne = prepareGetCurrentThreadAndMaybeStartNewOne(genericMessageInfoGetters, entityGetters, userOrTeamId);
        const finalizePreviousThread = prepareThreadFinalization(userEmailsByIdsGetter, interners, customerId, userOrTeamId, input.getNextMessageIndex, input.maxTimestampUpdater, genericMessageInfoGetters.isAnyParticipantMonitored);
        let threadInfo = undefined;
        let prevThreadInfo = undefined;
        for await (const message of sortedMessages) {
            threadInfo = await getCurrentThreadAndMaybeStartNewOne(threadInfo, message);
            if (prevThreadInfo !== undefined && threadInfo !== prevThreadInfo) {
                yield* finalizePreviousThread(prevThreadInfo);
            }
            threadInfo.accumulatedMessages.push(message);
            prevThreadInfo = threadInfo;
        }
        if (threadInfo !== undefined) {
            yield* finalizePreviousThread(threadInfo);
        }
    },
});
exports.processSortedMessages = processSortedMessages;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/messages.ts":
/*!*****************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/messages.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.createMessageEntry = exports.maybeInternSubjectAndSummary = exports.getInternedMessageContentTextOrHtml = void 0;
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const types_1 = __webpack_require__(/*! ../types */ "./src/services/teamsHistorical/lib/types.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const getInternedMessageContentTextOrHtml = (message, stringInterner) => {
    const { content, contentType } = message.body;
    const stringContent = content ?? '';
    const interningResults = stringInterner(stringContent);
    if (interningResults.isExisted) {
        return {
            contentReferenceId: interningResults.reference,
            contentType,
        };
    }
    const newlyCreatedEntry = {
        type: common_1.stringType,
        ref: interningResults.reference,
        data: stringContent,
    };
    return {
        newlyCreatedEntry,
        contentReferenceId: interningResults.reference,
        contentType,
    };
};
exports.getInternedMessageContentTextOrHtml = getInternedMessageContentTextOrHtml;
const getSubjectAndSummary = (subject, summary) => {
    if ((subject === undefined || subject === null) && (summary === undefined || summary === null)) {
        return undefined;
    }
    return [subject, summary].filter(v => v).join(' | ');
};
const maybeInternSubjectAndSummary = (subject, summary, stringInterner) => {
    const subjectAndSummary = getSubjectAndSummary(subject, summary);
    if (subjectAndSummary === undefined) {
        return undefined;
    }
    const subjectAndSummaryInterningResults = stringInterner(subjectAndSummary);
    if (subjectAndSummaryInterningResults.isExisted) {
        return {
            referenceId: subjectAndSummaryInterningResults.reference,
        };
    }
    const newlyCreatedEntry = {
        type: common_1.stringType,
        ref: subjectAndSummaryInterningResults.reference,
        data: subjectAndSummary,
    };
    return {
        referenceId: subjectAndSummaryInterningResults.reference,
        newlyCreatedEntry,
    };
};
exports.maybeInternSubjectAndSummary = maybeInternSubjectAndSummary;
const getMessageContentReferences = ({ contentType, contentReferenceId }, emptyStringReferenceId) => {
    if (contentType === types_1.htmlContentType) {
        return {
            contentRef: contentReferenceId,
            contentTextRef: emptyStringReferenceId,
        };
    }
    return {
        contentRef: emptyStringReferenceId,
        contentTextRef: contentReferenceId,
    };
};
const createMessageEntry = (message, threadInterningResults, maybeSenderRef, allParticipantsRef, maybeSubjectInterningResult, messageContentTextOrHtmlInterningResults, emptyStringReferenceId, threadMutableData, customerId, userOrTeamId, getNextMessageIndex) => {
    const originalTimestamp = new Date(message.createdDateTime).getTime();
    const messageEntry = {
        type: common_1.messageType,
        kind: common_1.imMessageKind,
        fromUserRef: maybeSenderRef,
        allParticipantsRef,
        originalTimestamp,
        threadIdRef: threadInterningResults.threadIdRef,
        threadNameRef: threadInterningResults.threadNameRef,
        threadDescriptionRef: threadInterningResults.threadDescriptionRef,
        ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('subjectRef', maybeSubjectInterningResult?.referenceId),
        ...getMessageContentReferences(messageContentTextOrHtmlInterningResults, emptyStringReferenceId),
        originId: `${customerId}/${userOrTeamId}/${threadMutableData.channelOrChatIdStr}/${message.id}`,
        idxInFile: getNextMessageIndex(),
    };
    if (message.importance === types_1.highMessageImportance) {
        messageEntry.isImportant = true;
    }
    if (message.importance === types_1.urgentMessageImportance) {
        messageEntry.isUrgent = true;
    }
    return messageEntry;
};
exports.createMessageEntry = createMessageEntry;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/threads.ts":
/*!****************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/threads.ts ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getThreadInterningResults = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const getMaybeThreadEntity = (type, interningResult, data) => {
    if (!interningResult.isExisted) {
        return {
            type,
            ref: interningResult.reference,
            data,
        };
    }
    return undefined;
};
const prepareInternThreadDataAndGetMaybeInterningResult = (type, interner, newEntities) => (data) => {
    let interningResult = undefined;
    if (data) {
        interningResult = interner(data);
        const maybeNewEntity = getMaybeThreadEntity(type, interningResult, data);
        if (maybeNewEntity !== undefined) {
            newEntities.push(maybeNewEntity);
        }
    }
    return interningResult;
};
const getThreadInterningResults = (threadData, interners) => {
    const newEntities = [];
    const internThreadId = prepareInternThreadDataAndGetMaybeInterningResult(common_1.threadIdType, interners.threadId, newEntities);
    const internThreadInfo = prepareInternThreadDataAndGetMaybeInterningResult(common_1.stringType, interners.stringInterner, newEntities);
    const threadIdInterningResult = internThreadId(threadData.channelOrChatIdStr);
    if (threadIdInterningResult?.reference === undefined) {
        throw Error('Thread ID must be defined');
    }
    const maybeThreadNameInterningResult = internThreadInfo(threadData.channelOrChatNameAndDescription?.name);
    const maybeThreadDescriptionInterningResult = internThreadInfo(threadData.channelOrChatNameAndDescription?.description);
    return {
        threadIdRef: threadIdInterningResult.reference,
        ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('threadNameRef', maybeThreadNameInterningResult?.reference),
        ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('threadDescriptionRef', maybeThreadDescriptionInterningResult?.reference),
        newEntities,
    };
};
exports.getThreadInterningResults = getThreadInterningResults;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/userSets.ts":
/*!*****************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/userSets.ts ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getUserSetDescriptor = exports.getSerializableEntryForUserSet = exports.getNewSerializedUserEntities = exports.getNewParticipants = void 0;
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const users_1 = __webpack_require__(/*! ./users */ "./src/services/teamsHistorical/lib/processing/users.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const getNewParticipants = (message, sortedParticipantsStack) => {
    const messageTimestamp = new Date(message.lastModifiedDateTime).getTime();
    const newParticipants = [];
    let participant = sortedParticipantsStack.pop();
    while (participant !== undefined) {
        if (messageTimestamp < participant.visibleHistoryStartTimestamp) {
            sortedParticipantsStack.push(participant);
            break;
        }
        newParticipants.push(participant);
        participant = sortedParticipantsStack.pop();
    }
    return newParticipants;
};
exports.getNewParticipants = getNewParticipants;
const getNewSerializedUserEntities = (enrichedUsers) => enrichedUsers.reduce((acc, user) => {
    acc.push((0, users_1.getSerializableEntryForUser)(user.data, user.interningResult.reference));
    return acc;
}, []);
exports.getNewSerializedUserEntities = getNewSerializedUserEntities;
const getSerializableEntryForUserSet = (participants, referenceId) => ({
    type: common_1.userSetType,
    ref: referenceId,
    data: Array.from(new Set(participants)),
});
exports.getSerializableEntryForUserSet = getSerializableEntryForUserSet;
const getMaybeNewUserSet = (userSetInterningResults, userSetUsersRefs) => {
    if (!userSetInterningResults.isExisted) {
        return {
            type: common_1.userSetType,
            ref: userSetInterningResults.reference,
            data: userSetUsersRefs,
        };
    }
    return undefined;
};
const getUserSetDescriptor = (sortedParticipantsStack, message, interners, currentParticipants) => {
    const newEntities = [];
    const newParticipants = (0, exports.getNewParticipants)(message, sortedParticipantsStack);
    currentParticipants.push(...newParticipants);
    const usersInterningResult = currentParticipants.map(user => ({
        data: user,
        interningResult: interners.participantInterner(user),
    }));
    const newUsersInterningResults = usersInterningResult.filter(u => !u.interningResult.isExisted);
    const newUsers = (0, exports.getNewSerializedUserEntities)(newUsersInterningResults);
    if ((0, common_1.notUndefinedAndNotNullAndNotEmpty)(newUsers)) {
        newEntities.push(...newUsers);
    }
    const userSetUsersRefs = (0, pure_utils_1.sort)(pure_utils_1.numOrderingFunctions.ascending)(usersInterningResult.map(u => u.interningResult.reference));
    const userSetInterningResults = interners.userSetInterner(userSetUsersRefs);
    const maybeUserSetToExpose = getMaybeNewUserSet(userSetInterningResults, userSetUsersRefs);
    if (maybeUserSetToExpose !== undefined) {
        newEntities.push(maybeUserSetToExpose);
    }
    return {
        allParticipantsRef: userSetInterningResults.reference,
        newEntities,
    };
};
exports.getUserSetDescriptor = getUserSetDescriptor;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/processing/users.ts":
/*!**************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/processing/users.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.getMaybeSenderRef = exports.getParticipantId = exports.createTeamsMemberDataWithTsFromSenderUser = exports.getSerializableEntryForUser = void 0;
const types_1 = __webpack_require__(/*! ../types */ "./src/services/teamsHistorical/lib/types.ts");
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const transformTeamsMessageSenderUserToIUserData = (member) => {
    const maybeFullName = (0, common_1.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField)('fullName', member.displayName);
    if ('email' in member && typeof member.email === 'string' && member.email.length > 0) {
        return {
            identities: [member.email, member.id],
            ...maybeFullName,
        };
    }
    return {
        identities: [`TemporaryTeamId:${member.id}`],
        ...maybeFullName,
    };
};
const transformAadUserConversationMemberToIUserData = (member) => ({
    identities: [member.email, member.userId].filter(common_1.notUndefinedAndNotNullAndNotEmpty),
    ...(0, common_1.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField)('fullName', member.displayName),
});
const transformTeamworkUserConversationMemberToIUserData = (member) => ({
    identities: [member.id].filter(common_1.notUndefinedAndNotNullAndNotEmpty),
    ...(0, common_1.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField)('fullName', member.displayName),
});
const createGenericSingleFieldTransformerToUserData = (fieldName, addedFieldPrefix) => (member) => {
    const fieldValue = member[fieldName];
    const identities = (0, common_1.notUndefinedAndNotNullAndNotEmpty)(fieldValue)
        ? [`${addedFieldPrefix}:${fieldValue}`]
        : [];
    return {
        identities,
        ...(0, common_1.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField)('fullName', member.displayName),
    };
};
const transformAnonymousGuestConversationMemberToIUserData = createGenericSingleFieldTransformerToUserData('anonymousGuestId', 'AnonymousGuestId');
const transformAzureCommunicationServicesUserConversationMemberToIUserData = createGenericSingleFieldTransformerToUserData('azureCommunicationServicesId', 'AzureCommunicationServicesId');
const transformMicrosoftAccountUserConversationMemberToIUserData = createGenericSingleFieldTransformerToUserData('userId', 'MicrosoftAccountId');
const unknownStr = 'unknown';
const transformSkypeForBusinessUserConversationMemberToIUserData = (member) => {
    const maybeFullName = (0, common_1.ifDefinedAndNotNullAndNotEmptyThenAddOptionalField)('fullName', member.displayName);
    if (!(0, common_1.notUndefinedAndNotNullAndNotEmpty)(member.tenantId) && !(0, common_1.notUndefinedAndNotNullAndNotEmpty)(member.userId)) {
        return {
            identities: ['UnknownSkypeForBusinessUser'],
            ...maybeFullName,
        };
    }
    const identity = `SkypeForBusinessUser:tenant:${member.tenantId ?? unknownStr}:userId:${member.userId ?? unknownStr}`;
    return {
        identities: [identity],
        ...maybeFullName,
    };
};
const transformSkypeUserConversationMemberToIUserData = createGenericSingleFieldTransformerToUserData('skypeId', 'SkypeId');
const transformers = {
    [types_1.aadUserConversationMemberODataType]: transformAadUserConversationMemberToIUserData,
    [types_1.teamworkUserConversationMemberODataType]: transformTeamworkUserConversationMemberToIUserData,
    [types_1.anonymousGuestConversationMemberODataType]: transformAnonymousGuestConversationMemberToIUserData,
    [types_1.azureCommunicationServicesUserConversationMemberODataType]: transformAzureCommunicationServicesUserConversationMemberToIUserData,
    [types_1.microsoftAccountUserConversationMemberODataType]: transformMicrosoftAccountUserConversationMemberToIUserData,
    [types_1.skypeForBusinessUserConversationMemberODataType]: transformSkypeForBusinessUserConversationMemberToIUserData,
    [types_1.skypeUserConversationMemberODataType]: transformSkypeUserConversationMemberToIUserData,
};
const memberTypeKeys = new Set(Object.keys(transformers));
const isTransformerKey = (typeKey) => memberTypeKeys.has(typeKey);
const transformRawMemberDataToIUserData = (member) => {
    const key = member[types_1.oDataTypeFieldName];
    if (!isTransformerKey(key)) {
        throw new Error(`Unknown member type: ${key}`);
    }
    const transformer = transformers[key];
    return transformer(member);
};
const transformMessageSenderOrTeamsMessageSenderUserToIUserData = (member) => (types_1.oDataTypeFieldName in member
    ? transformRawMemberDataToIUserData(member)
    : transformTeamsMessageSenderUserToIUserData(member));
const getSerializableEntryForUser = (member, referenceId) => ({
    type: common_1.userType,
    ref: referenceId,
    data: transformMessageSenderOrTeamsMessageSenderUserToIUserData(member),
});
exports.getSerializableEntryForUser = getSerializableEntryForUser;
const createTeamsMemberDataWithTsFromSenderUser = (participant) => ({
    [types_1.oDataTypeFieldName]: '#microsoft.graph.aadUserConversationMember',
    displayName: participant.displayName,
    visibleHistoryStartDateTime: new Date('1970-01-01T00:00:00.000Z').toISOString(),
    id: participant.id,
    userId: participant.id,
    email: participant.email,
    visibleHistoryStartTimestamp: 0,
});
exports.createTeamsMemberDataWithTsFromSenderUser = createTeamsMemberDataWithTsFromSenderUser;
const getParticipantId = (participant) => participant.id;
exports.getParticipantId = getParticipantId;
const getMaybeSenderRef = (message, participantById, interners) => {
    let senderRef = undefined;
    if (message.from?.user?.id === undefined) {
        return senderRef;
    }
    const sender = participantById.get(message.from.user.id);
    if (sender) {
        const senderInterningResult = interners.participantInterner(sender);
        senderRef = senderInterningResult.reference;
    }
    return senderRef;
};
exports.getMaybeSenderRef = getMaybeSenderRef;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/teamsChannelMessagesGetter.ts":
/*!************************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/teamsChannelMessagesGetter.ts ***!
  \************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsChannelMessagesGetter = void 0;
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const channels_1 = __webpack_require__(/*! ./processing/channels */ "./src/services/teamsHistorical/lib/processing/channels.ts");
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const teamsChannelEntityGetters_1 = __webpack_require__(/*! ./getters/teamsChannelEntityGetters */ "./src/services/teamsHistorical/lib/getters/teamsChannelEntityGetters.ts");
let TeamsChannelMessagesGetter = class TeamsChannelMessagesGetter {
    entityGettersFactory;
    constructor(entityGettersFactory) {
        this.entityGettersFactory = entityGettersFactory;
    }
    async handle(input) {
        const entityGetters = this.entityGettersFactory.handle(input.jobParameters.tenantId);
        const teams = await entityGetters.teamsGetter.handle(undefined);
        const messageIdSet = new Set();
        const chatUsersIterable = entityGetters.usersByCustomerIdGetter.handle(input.jobParameters);
        const chatUsers = await (0, pure_utils_1.convertAsyncIterableToArray)(chatUsersIterable);
        const chatUsersIds = chatUsers.map(user => user.id);
        return (0, pure_utils_1.flatMapAsyncIterable)(teams, (0, channels_1.getEntitiesForSingleTeam)(input, entityGetters, input.interners, input.getNextMessageIndex, input.maxTimestampUpdater, messageIdSet, chatUsersIds));
    }
};
TeamsChannelMessagesGetter = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [teamsChannelEntityGetters_1.TeamsChannelEntityGettersFactory])
], TeamsChannelMessagesGetter);
exports.TeamsChannelMessagesGetter = TeamsChannelMessagesGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/teamsChatMessagesGetter.ts":
/*!*********************************************************************!*\
  !*** ./src/services/teamsHistorical/lib/teamsChatMessagesGetter.ts ***!
  \*********************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsChatMessagesGetter = void 0;
const common_1 = __webpack_require__(/*! ../common */ "./src/services/teamsHistorical/common.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const common_2 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const teamsChatsEntityGetters_1 = __webpack_require__(/*! ./getters/teamsChatsEntityGetters */ "./src/services/teamsHistorical/lib/getters/teamsChatsEntityGetters.ts");
const chats_1 = __webpack_require__(/*! ./processing/chats */ "./src/services/teamsHistorical/lib/processing/chats.ts");
const chatsMessagesGetter_1 = __webpack_require__(/*! ./getters/chats/chatsMessagesGetter */ "./src/services/teamsHistorical/lib/getters/chats/chatsMessagesGetter.ts");
const chatsParticipantsGetter_1 = __webpack_require__(/*! ./getters/chats/chatsParticipantsGetter */ "./src/services/teamsHistorical/lib/getters/chats/chatsParticipantsGetter.ts");
const prepareUserWrongLicenseDbWriter = (dataRetrievalIssuesRecordLogger, jobParameters) => async (dataRequest, errorType) => {
    const sourceSpecificData = {
        errorType,
        customerType: jobParameters.customerType,
        tenantId: jobParameters.tenantId,
        userId: dataRequest.userOrTeamId,
        ...(dataRequest.email === null ? {} : { email: dataRequest.email }),
    };
    await dataRetrievalIssuesRecordLogger.handle({
        sourceSpecificData,
        sourceKey: common_1.teamsHistoricalSource,
        customerInitials: jobParameters.customerInitials,
        timestampUnixMsUtcStartExclusive: new Date(dataRequest.dateStartExclusiveIso8601).getTime(),
        timestampUnixMsUtcEndInclusive: new Date(dataRequest.dateEndInclusiveIso8601).getTime(),
    });
};
let TeamsChatMessagesGetter = class TeamsChatMessagesGetter {
    entityGettersFactory;
    dataRetrievalIssuesRecordLogger;
    constructor(entityGettersFactory, dataRetrievalIssuesRecordLogger) {
        this.entityGettersFactory = entityGettersFactory;
        this.dataRetrievalIssuesRecordLogger = dataRetrievalIssuesRecordLogger;
    }
    handle(input) {
        const entityGetters = this.entityGettersFactory.handle(input.jobParameters.tenantId);
        const patchedEntityGetters = {
            ...entityGetters,
            messagesGetter: (0, common_1.queryHandlerFromFunction)((0, chatsMessagesGetter_1.chatsMessagesWithWrongLicensedUserGetter)(entityGetters.messagesGetter, prepareUserWrongLicenseDbWriter(this.dataRetrievalIssuesRecordLogger, input.jobParameters))),
            participantsGetter: (0, common_1.queryHandlerFromFunction)((0, chatsParticipantsGetter_1.wrapForbiddenInsufficientPermissionsForChatsParticipantsGetter)(entityGetters.participantsGetter)),
        };
        const chatUsers = patchedEntityGetters.usersByCustomerIdGetter.handle(input.jobParameters);
        const messageIdSet = new Set();
        return (0, pure_utils_1.flatMapAsyncIterable)(chatUsers, (0, chats_1.getEntitiesForSingleUser)(input, patchedEntityGetters, input.interners, input.getNextMessageIndex, input.maxTimestampUpdater, messageIdSet));
    }
};
TeamsChatMessagesGetter = __decorate([
    (0, common_2.Injectable)(),
    __param(1, (0, common_2.Inject)(common_1.DATA_RETRIEVAL_ISSUES_RECORD_LOGGER_TOKEN)),
    __metadata("design:paramtypes", [teamsChatsEntityGetters_1.TeamsChatEntityGettersFactory, Object])
], TeamsChatMessagesGetter);
exports.TeamsChatMessagesGetter = TeamsChatMessagesGetter;


/***/ }),

/***/ "./src/services/teamsHistorical/lib/types.ts":
/*!***************************************************!*\
  !*** ./src/services/teamsHistorical/lib/types.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.channelRawMessageSchema = exports.chatRawMessageSchema = exports.baseMessagesRawSchema = exports.chatsRawSchema = exports.chatUsersRawSchema = exports.teamsChannelIdentitySchema = exports.rawMemberDataSchema = exports.skypeUserConversationMember = exports.skypeUserConversationMemberODataType = exports.skypeForBusinessUserConversationMember = exports.skypeForBusinessUserConversationMemberODataType = exports.microsoftAccountUserConversationMember = exports.microsoftAccountUserConversationMemberODataType = exports.azureCommunicationServicesUserConversationMember = exports.azureCommunicationServicesUserConversationMemberODataType = exports.anonymousGuestConversationMember = exports.anonymousGuestConversationMemberODataType = exports.isTeamworkUserConversationMember = exports.teamworkUserConversationMember = exports.teamworkUserConversationMemberODataType = exports.isAadUserConversationMember = exports.aadUserConversationMember = exports.aadUserConversationMemberODataType = exports.oDataTypeFieldName = exports.teamSchema = exports.groupMemberSchema = exports.groupSchema = exports.teamsMessageBodySchema = exports.htmlContentType = exports.textContentType = exports.teamsMessageUserDescriptorSchema = exports.teamsMessageSenderUserSchema = exports.userIdAndEmailWithDisplayNameSchema = exports.genericIdSchema = exports.msPageDataSchema = exports.graphApiCredentialsSchema = exports.graphApiBasicCredentialsSchema = exports.graphApiSecretSchema = exports.teamsHistoricalJobParametersSchema = exports.teamsHistoricalJobReadyProfileSchema = exports.dipCustomerType = exports.etlCustomerType = exports.teamsHistoricalProfileBaseSchema = exports.timeRangeSchema = exports.teamsHistoricalJobName = exports.urgentMessageImportance = exports.highMessageImportance = exports.normalMessageImportance = exports.lowMessageImportance = exports.genericValidatedObject = void 0;
exports.channelRawInfoSchema = exports.chatRawInfoSchema = exports.baseChatOrChannelInfoRawSchema = void 0;
const zod_1 = __webpack_require__(/*! zod */ "./node_modules/zod/lib/index.js");
const constants_1 = __webpack_require__(/*! ./constants */ "./src/services/teamsHistorical/lib/constants.ts");
const validation_1 = __webpack_require__(/*! ../../../validation */ "./src/validation/index.ts");
exports.genericValidatedObject = zod_1.z.record(zod_1.z.string(), zod_1.z.object({}).passthrough());
exports.lowMessageImportance = 'low';
exports.normalMessageImportance = 'normal';
exports.highMessageImportance = 'high';
exports.urgentMessageImportance = 'urgent';
exports.teamsHistoricalJobName = 'teams-historical';
exports.timeRangeSchema = zod_1.z.object({
    dateStartExclusiveUtcIso8601: zod_1.z.string(),
    dateEndInclusiveUtcIso8601: zod_1.z.string(),
});
exports.teamsHistoricalProfileBaseSchema = zod_1.z.object({
    customerId: validation_1.objectIdString,
    customerInitials: zod_1.z.string(),
    tenantId: zod_1.z.string(),
    emails: zod_1.z.array(validation_1.nonBlankString),
});
exports.etlCustomerType = 'etl';
exports.dipCustomerType = 'dip';
exports.teamsHistoricalJobReadyProfileSchema = exports.teamsHistoricalProfileBaseSchema.extend({
    customerType: zod_1.z.union([zod_1.z.literal(exports.etlCustomerType), zod_1.z.literal(exports.dipCustomerType)]),
    lastUpdateTimeMs: validation_1.nonNegativeInteger,
    scheduleTimeoutInMinutes: validation_1.positiveInteger,
    getMessagesUpToTimestampMs: validation_1.nonNegativeInteger.optional(),
    isDryRun: zod_1.z.literal(true).optional(),
    teamsBucket: validation_1.nonBlankString,
});
exports.teamsHistoricalJobParametersSchema = exports.teamsHistoricalJobReadyProfileSchema.extend({
    jobName: zod_1.z.literal(exports.teamsHistoricalJobName),
    outputPath: zod_1.z.string().optional(),
});
exports.graphApiSecretSchema = zod_1.z.object({
    msGraphApiSecret: zod_1.z.string(),
});
exports.graphApiBasicCredentialsSchema = zod_1.z.object({
    clientId: zod_1.z.string(),
    tenantId: zod_1.z.string(),
});
exports.graphApiCredentialsSchema = exports.graphApiBasicCredentialsSchema.extend({
    clientSecret: zod_1.z.string(),
});
exports.msPageDataSchema = zod_1.z.object({
    [constants_1.NEXT_LINK_RESPONSE_KEY]: zod_1.z.string().optional(),
    [constants_1.COUNT_RESPONSE_KEY]: zod_1.z.number().optional(),
    value: zod_1.z.unknown().array(),
});
exports.genericIdSchema = zod_1.z.object({
    id: zod_1.z.string(),
});
exports.userIdAndEmailWithDisplayNameSchema = exports.genericIdSchema.merge(zod_1.z.object({
    mail: zod_1.z.string().optional().nullable(),
    displayName: zod_1.z.string(),
})).transform(user => ({
    ...user,
    email: user.mail,
}));
exports.teamsMessageSenderUserSchema = zod_1.z.object({
    id: zod_1.z.string(),
    displayName: zod_1.z.string().nullable(),
});
exports.teamsMessageUserDescriptorSchema = zod_1.z.object({
    application: exports.genericIdSchema.nullable(),
    device: exports.genericIdSchema.nullable(),
    user: exports.teamsMessageSenderUserSchema.nullable(),
});
exports.textContentType = 'text';
exports.htmlContentType = 'html';
exports.teamsMessageBodySchema = zod_1.z.object({
    contentType: zod_1.z.union([zod_1.z.literal(exports.htmlContentType), zod_1.z.literal(exports.textContentType)]),
    content: zod_1.z.string().nullable(),
});
exports.groupSchema = zod_1.z.object({
    id: validation_1.nonBlankString,
    mail: zod_1.z.string().nullable().optional(),
});
exports.groupMemberSchema = zod_1.z.object({
    id: validation_1.nonBlankString,
    mail: zod_1.z.string().nullable().optional(),
});
exports.teamSchema = zod_1.z.object({
    id: validation_1.nonBlankString,
    email: zod_1.z.string().nullable().optional(),
});
const commonConversationMemberFields = zod_1.z.object({
    displayName: zod_1.z.string().nullable(),
    visibleHistoryStartDateTime: zod_1.z.string().default('0001-01-01T00:00:00Z'),
    id: zod_1.z.string(),
});
exports.oDataTypeFieldName = '@odata.type';
exports.aadUserConversationMemberODataType = '#microsoft.graph.aadUserConversationMember';
exports.aadUserConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.aadUserConversationMemberODataType),
    userId: zod_1.z.string(),
    email: zod_1.z.string().nullable().optional(),
});
const isAadUserConversationMember = (member) => member[exports.oDataTypeFieldName] === exports.aadUserConversationMemberODataType;
exports.isAadUserConversationMember = isAadUserConversationMember;
exports.teamworkUserConversationMemberODataType = '#microsoft.graph.teamworkUserIdentity';
exports.teamworkUserConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.teamworkUserConversationMemberODataType),
    userId: zod_1.z.string(),
});
const isTeamworkUserConversationMember = (member) => member[exports.oDataTypeFieldName] === exports.teamworkUserConversationMemberODataType;
exports.isTeamworkUserConversationMember = isTeamworkUserConversationMember;
exports.anonymousGuestConversationMemberODataType = '#microsoft.graph.anonymousGuestConversationMember';
exports.anonymousGuestConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.anonymousGuestConversationMemberODataType),
    anonymousGuestId: zod_1.z.string().nullable(),
});
exports.azureCommunicationServicesUserConversationMemberODataType = '#microsoft.graph.azureCommunicationServicesUserConversationMember';
exports.azureCommunicationServicesUserConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.azureCommunicationServicesUserConversationMemberODataType),
    azureCommunicationServicesId: zod_1.z.string().nullable(),
});
exports.microsoftAccountUserConversationMemberODataType = '#microsoft.graph.microsoftAccountUserConversationMember';
exports.microsoftAccountUserConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.microsoftAccountUserConversationMemberODataType),
    userId: zod_1.z.string().nullable(),
});
exports.skypeForBusinessUserConversationMemberODataType = '#microsoft.graph.skypeForBusinessUserConversationMember';
exports.skypeForBusinessUserConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.skypeForBusinessUserConversationMemberODataType),
    tenantId: zod_1.z.string().nullable(),
    userId: zod_1.z.string().nullable(),
});
exports.skypeUserConversationMemberODataType = '#microsoft.graph.skypeUserConversationMember';
exports.skypeUserConversationMember = commonConversationMemberFields.extend({
    [exports.oDataTypeFieldName]: zod_1.z.literal(exports.skypeUserConversationMemberODataType),
    skypeId: zod_1.z.string().nullable(),
});
exports.rawMemberDataSchema = zod_1.z.discriminatedUnion(exports.oDataTypeFieldName, [
    exports.aadUserConversationMember,
    exports.teamworkUserConversationMember,
    exports.anonymousGuestConversationMember,
    exports.azureCommunicationServicesUserConversationMember,
    exports.microsoftAccountUserConversationMember,
    exports.skypeForBusinessUserConversationMember,
    exports.skypeUserConversationMember,
]);
exports.teamsChannelIdentitySchema = zod_1.z.object({
    teamId: zod_1.z.string(),
    channelId: zod_1.z.string(),
});
exports.chatUsersRawSchema = zod_1.z.object({
    id: zod_1.z.string(),
    displayName: zod_1.z.string().nullable(),
    mail: zod_1.z.string().nullable(),
    mobilePhone: zod_1.z.string().nullable().optional(),
});
exports.chatsRawSchema = zod_1.z.object({
    id: zod_1.z.string(),
    topic: zod_1.z.string().nullable(),
    tenantId: zod_1.z.string().nullable(),
});
exports.baseMessagesRawSchema = zod_1.z.object({
    id: zod_1.z.string(),
    messageType: zod_1.z.string(),
    createdDateTime: zod_1.z.string(),
    lastModifiedDateTime: zod_1.z.string(),
    subject: zod_1.z.string().nullable(),
    summary: zod_1.z.string().nullable(),
    importance: zod_1.z.union([
        zod_1.z.literal(exports.lowMessageImportance),
        zod_1.z.literal(exports.normalMessageImportance),
        zod_1.z.literal(exports.highMessageImportance),
        zod_1.z.literal(exports.urgentMessageImportance),
    ]),
    from: exports.teamsMessageUserDescriptorSchema.nullable(),
    body: exports.teamsMessageBodySchema,
});
exports.chatRawMessageSchema = exports.baseMessagesRawSchema.merge(zod_1.z.object({
    chatId: zod_1.z.string(),
}));
exports.channelRawMessageSchema = exports.baseMessagesRawSchema.merge(zod_1.z.object({
    channelIdentity: exports.teamsChannelIdentitySchema,
}));
exports.baseChatOrChannelInfoRawSchema = zod_1.z.object({
    id: zod_1.z.string(),
});
exports.chatRawInfoSchema = exports.baseChatOrChannelInfoRawSchema.merge(zod_1.z.object({
    topic: zod_1.z.string().nullable(),
}));
exports.channelRawInfoSchema = exports.baseChatOrChannelInfoRawSchema.merge(zod_1.z.object({
    displayName: zod_1.z.string().nullable(),
    description: zod_1.z.string().nullable(),
}));


/***/ }),

/***/ "./src/services/teamsHistorical/lib/utils.ts":
/*!***************************************************!*\
  !*** ./src/services/teamsHistorical/lib/utils.ts ***!
  \***************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.buildChatInfoQueryPostfix = exports.buildChatMessagesQueryPostfix = exports.buildChatsUsersQueryPostfix = exports.buildUsersQueryPostfix = exports.buildChannelInfoQueryPostfix = exports.buildChannelParticipantsQueryPostfix = exports.buildChannelMessagesQueryPostfix = exports.buildTeamsQueryPostfix = exports.buildGroupMembersQueryPostfix = exports.buildGroupsQueryPostfix = exports.prepareGenericBatchedGetter = exports.removeUserIdField = exports.createDataGetter = exports.createPaginatedDataGetter = exports.getPaginatedData = exports.getAccessToken = exports.getTeamAndChannelKey = exports.createMaxTimestampUpdater = exports.splitByType = exports.hasIntersection = exports.getTeamsCustomersValidationResult = exports.transformRecordsWithCustomerInitialsToLowerCase = exports.getRetryConfig = exports.DEFAULT_RETRY_AFTER_MS = exports.isFulfilled = void 0;
const msal_node_1 = __webpack_require__(/*! @azure/msal-node */ "./node_modules/@azure/msal-node/dist/index.mjs");
const types_1 = __webpack_require__(/*! ./types */ "./src/services/teamsHistorical/lib/types.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const constants_1 = __webpack_require__(/*! ./constants */ "./src/services/teamsHistorical/lib/constants.ts");
const axios_retry_1 = __importDefault(__webpack_require__(/*! axios-retry */ "./node_modules/axios-retry/dist/cjs/index.js"));
const axios_1 = __webpack_require__(/*! axios */ "./node_modules/axios/dist/node/axios.cjs");
const errorProcessing_1 = __webpack_require__(/*! ../../../common/errorProcessing */ "./src/common/errorProcessing.ts");
const isFulfilled = (input) => input.status === 'fulfilled';
exports.isFulfilled = isFulfilled;
const retryCondition = (error) => (axios_retry_1.default.isNetworkOrIdempotentRequestError(error) ||
    error.status === axios_1.HttpStatusCode.TooManyRequests ||
    error.status === axios_1.HttpStatusCode.ServiceUnavailable);
exports.DEFAULT_RETRY_AFTER_MS = 5000;
const getRetryConfig = (retries) => ({
    retryCondition,
    retries,
    retryDelay: (retryCount, error) => {
        const retryAfterHeader = error.response?.headers['retry-after'] ?? exports.DEFAULT_RETRY_AFTER_MS;
        const maybeNumberRetryAfterHeader = Number(retryAfterHeader);
        const maybeIntegerRetryAfter = Number.isInteger(maybeNumberRetryAfterHeader);
        if (retryAfterHeader && maybeIntegerRetryAfter) {
            return maybeNumberRetryAfterHeader;
        }
        if (retryAfterHeader && !maybeIntegerRetryAfter) {
            const remainingTime = Math.ceil((new Date(String(retryAfterHeader)).getTime() - new Date().getTime()) / 1000);
            if (remainingTime > 0) {
                return remainingTime;
            }
        }
        return axios_retry_1.default.exponentialDelay(retryCount, error);
    },
});
exports.getRetryConfig = getRetryConfig;
const transformRecordWithCustomerInitialsToLowerCase = (customerDescriptor) => ({
    ...customerDescriptor,
    customerInitials: customerDescriptor.customerInitials.toLowerCase(),
});
const transformRecordsWithCustomerInitialsToLowerCase = (input) => input.map(customerDescriptor => ({
    ...customerDescriptor,
    customerInitials: customerDescriptor.customerInitials.toLowerCase(),
}));
exports.transformRecordsWithCustomerInitialsToLowerCase = transformRecordsWithCustomerInitialsToLowerCase;
const getTeamsCustomersValidationResult = (customerDescriptors, validationSchema) => {
    const success = [];
    const fails = [];
    for (const customerDescriptor of customerDescriptors) {
        const customerDescriptorParsingResult = validationSchema.safeParse(customerDescriptor);
        if (customerDescriptorParsingResult.success) {
            success.push(transformRecordWithCustomerInitialsToLowerCase(customerDescriptorParsingResult.data));
        }
        else {
            fails.push((0, errorProcessing_1.getEnrichedZodError)(customerDescriptorParsingResult.error, customerDescriptor));
        }
    }
    return {
        success,
        fails,
    };
};
exports.getTeamsCustomersValidationResult = getTeamsCustomersValidationResult;
const hasIntersection = (set1, set2) => {
    const baseSet = set1.size < set2.size ? set1 : set2;
    const secondarySet = baseSet === set1 ? set2 : set1;
    for (const el of baseSet) {
        if (secondarySet.has(el)) {
            return true;
        }
    }
    return false;
};
exports.hasIntersection = hasIntersection;
const splitByType = (arr, checkType) => {
    const as = [];
    const bs = [];
    arr.forEach((x) => {
        if (checkType(x)) {
            as.push(x);
        }
        else {
            bs.push(x);
        }
    });
    return [as, bs];
};
exports.splitByType = splitByType;
const createMaxTimestampUpdater = (currentMaximumTimestamp) => (messageTimestamp) => {
    if (currentMaximumTimestamp.value < messageTimestamp) {
        currentMaximumTimestamp.value = messageTimestamp;
    }
};
exports.createMaxTimestampUpdater = createMaxTimestampUpdater;
const getTeamAndChannelKey = (message) => `${message.channelIdentity.teamId}%-%${message.channelIdentity.channelId}`;
exports.getTeamAndChannelKey = getTeamAndChannelKey;
const getAccessToken = async (credentials) => {
    const config = {
        auth: {
            clientId: credentials.clientId,
            authority: `https://login.microsoftonline.com/${credentials.tenantId}/`,
            clientSecret: credentials.clientSecret,
            knownAuthorities: [`https://login.microsoftonline.com/${credentials.tenantId}/`],
        },
    };
    const cca = new msal_node_1.ConfidentialClientApplication(config);
    const clientCredentialRequest = {
        scopes: ['https://graph.microsoft.com/.default'],
    };
    const response = await cca.acquireTokenByClientCredential(clientCredentialRequest);
    if (!response?.accessToken) {
        throw Error('Got an empty response or access token');
    }
    return response.accessToken;
};
exports.getAccessToken = getAccessToken;
const getPaginatedData = (url, queryHandler, itemsLimit) => ({
    async *[Symbol.asyncIterator]() {
        let currentUrl = url;
        let theRest = itemsLimit;
        while (currentUrl !== undefined) {
            const nextData = await queryHandler.handle(currentUrl);
            const validatedData = types_1.msPageDataSchema.parse(nextData);
            yield* validatedData.value;
            if (theRest !== undefined) {
                if (theRest <= 0) {
                    break;
                }
                theRest = theRest - validatedData.value.length;
            }
            currentUrl = validatedData[constants_1.NEXT_LINK_RESPONSE_KEY];
        }
    },
});
exports.getPaginatedData = getPaginatedData;
const createPaginatedDataGetter = (getUrl, validate, queryHandler, itemsLimit) => (req) => ({
    async *[Symbol.asyncIterator]() {
        const firstPageUrl = getUrl(req);
        if (firstPageUrl === undefined) {
            yield* (0, pure_utils_1.createEmptyAsyncIterable)();
            return;
        }
        const unValidatedData = (0, exports.getPaginatedData)(firstPageUrl, queryHandler, itemsLimit);
        yield* (0, pure_utils_1.mapAsyncIterable)(unValidatedData, validate);
    },
});
exports.createPaginatedDataGetter = createPaginatedDataGetter;
const createDataGetter = (getUrl, validate, queryHandler) => async (req) => {
    const url = getUrl(req);
    const data = await queryHandler.handle(url);
    return validate(data);
};
exports.createDataGetter = createDataGetter;
const shiftDateMs = (date, offsetMs = 1) => {
    const fixedDateAsNumber = new Date(date).getTime() + offsetMs;
    return new Date(fixedDateAsNumber).toISOString();
};
exports.removeUserIdField = (0, pure_utils_1.removeFields)(['userId']);
const prepareGenericBatchedGetter = (batchSize, getter) => (input) => ({
    async *[Symbol.asyncIterator]() {
        const batches = (0, pure_utils_1.batch)(batchSize)(input);
        for (const currentBatch of batches) {
            yield* getter(currentBatch);
        }
    },
});
exports.prepareGenericBatchedGetter = prepareGenericBatchedGetter;
const getListBasedFilter = (field, data) => {
    if (data === undefined || data.length === 0) {
        return undefined;
    }
    return `$filter=${field} in (${data.map(item => `'${item}'`).join(',')})`;
};
const buildGroupsQueryPostfix = (emails) => {
    const filter = getListBasedFilter('mail', emails);
    return filter ? `v1.0/groups?${filter}` : undefined;
};
exports.buildGroupsQueryPostfix = buildGroupsQueryPostfix;
const buildGroupMembersQueryPostfix = (groupId) => `v1.0/groups/${groupId}/transitiveMembers/microsoft.graph.user`;
exports.buildGroupMembersQueryPostfix = buildGroupMembersQueryPostfix;
const buildTeamsQueryPostfix = () => 'v1.0/teams';
exports.buildTeamsQueryPostfix = buildTeamsQueryPostfix;
const buildChannelMessagesQueryPostfix = (re) => {
    const dateEndInclusiveIso8601 = shiftDateMs(re.dateEndInclusiveIso8601);
    return `v1.0/teams/${re.userOrTeamId}/channels/getAllMessages?model=A&` +
        `$filter=lastModifiedDateTime gt ${re.dateStartExclusiveIso8601} and ` +
        `lastModifiedDateTime lt ${dateEndInclusiveIso8601}`;
};
exports.buildChannelMessagesQueryPostfix = buildChannelMessagesQueryPostfix;
const buildChannelParticipantsQueryPostfix = (ids) => `v1.0/teams/${ids.teamId}/channels/${ids.channelId}/members`;
exports.buildChannelParticipantsQueryPostfix = buildChannelParticipantsQueryPostfix;
const buildChannelInfoQueryPostfix = (ids) => `v1.0/teams/${ids.teamId}/channels/${ids.channelId}`;
exports.buildChannelInfoQueryPostfix = buildChannelInfoQueryPostfix;
const buildUsersQueryPostfix = (emails) => {
    const filter = getListBasedFilter('mail', emails);
    return filter ? `v1.0/users?${filter}` : undefined;
};
exports.buildUsersQueryPostfix = buildUsersQueryPostfix;
const buildChatsUsersQueryPostfix = (chatId) => `v1.0/chats/${chatId}/members`;
exports.buildChatsUsersQueryPostfix = buildChatsUsersQueryPostfix;
const buildChatMessagesQueryPostfix = (re) => {
    const dateEndInclusiveIso8601 = shiftDateMs(re.dateEndInclusiveIso8601);
    return `v1.0/users/${re.userOrTeamId}/chats/getAllMessages?` +
        `model=A&$filter=lastModifiedDateTime gt ${re.dateStartExclusiveIso8601} and ` +
        `lastModifiedDateTime lt ${dateEndInclusiveIso8601}`;
};
exports.buildChatMessagesQueryPostfix = buildChatMessagesQueryPostfix;
const buildChatInfoQueryPostfix = (chatId) => `v1.0/chats/${chatId}`;
exports.buildChatInfoQueryPostfix = buildChatInfoQueryPostfix;


/***/ }),

/***/ "./src/services/teamsHistorical/local/auth/credentialsGetterLocal.ts":
/*!***************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/auth/credentialsGetterLocal.ts ***!
  \***************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CredentialsGetterLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const common_2 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const types_1 = __webpack_require__(/*! ../../lib/types */ "./src/services/teamsHistorical/lib/types.ts");
let CredentialsGetterLocal = class CredentialsGetterLocal {
    secretGetter;
    constructor(secretGetter) {
        this.secretGetter = secretGetter;
    }
    async handle(tenantId) {
        const clientSecret = await this.secretGetter.handle();
        const clientId = process.env.CLIENT_ID;
        if (!clientId) {
            throw new Error('CLIENT_ID environment variable is required');
        }
        return types_1.graphApiCredentialsSchema.parse({
            clientId,
            tenantId,
            clientSecret,
        });
    }
};
CredentialsGetterLocal = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, common_1.Inject)(common_2.CLIENT_SECRET_GETTER_TOKEN)),
    __metadata("design:paramtypes", [Object])
], CredentialsGetterLocal);
exports.CredentialsGetterLocal = CredentialsGetterLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/local/auth/customerSecretGetterLocal.ts":
/*!******************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/auth/customerSecretGetterLocal.ts ***!
  \******************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.CustomerSecretGetterLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
let CustomerSecretGetterLocal = class CustomerSecretGetterLocal {
    async handle() {
        const secret = process.env.CLIENT_SECRET;
        if (!secret) {
            throw new Error('CLIENT_SECRET environment variable is required');
        }
        return secret;
    }
};
CustomerSecretGetterLocal = __decorate([
    (0, common_1.Injectable)()
], CustomerSecretGetterLocal);
exports.CustomerSecretGetterLocal = CustomerSecretGetterLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/local/auth/teamsHistoricalLocalAuthModule.ts":
/*!***********************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/auth/teamsHistoricalLocalAuthModule.ts ***!
  \***********************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsHistoricalAuthLocalModule = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const common_2 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const accessTokenGetterFactory_1 = __webpack_require__(/*! ../../lib/auth/accessTokenGetterFactory */ "./src/services/teamsHistorical/lib/auth/accessTokenGetterFactory.ts");
const credentialsGetterLocal_1 = __webpack_require__(/*! ./credentialsGetterLocal */ "./src/services/teamsHistorical/local/auth/credentialsGetterLocal.ts");
const customerSecretGetterLocal_1 = __webpack_require__(/*! ./customerSecretGetterLocal */ "./src/services/teamsHistorical/local/auth/customerSecretGetterLocal.ts");
let TeamsHistoricalAuthLocalModule = class TeamsHistoricalAuthLocalModule {
};
TeamsHistoricalAuthLocalModule = __decorate([
    (0, common_1.Module)({
        providers: [
            {
                provide: common_2.CLIENT_SECRET_GETTER_TOKEN,
                useClass: customerSecretGetterLocal_1.CustomerSecretGetterLocal,
            },
            {
                provide: common_2.CREDENTIALS_GETTER_TOKEN,
                useClass: credentialsGetterLocal_1.CredentialsGetterLocal,
            },
            accessTokenGetterFactory_1.AccessTokenGetterFactory,
        ],
        exports: [accessTokenGetterFactory_1.AccessTokenGetterFactory],
    })
], TeamsHistoricalAuthLocalModule);
exports.TeamsHistoricalAuthLocalModule = TeamsHistoricalAuthLocalModule;


/***/ }),

/***/ "./src/services/teamsHistorical/local/constants.ts":
/*!*********************************************************!*\
  !*** ./src/services/teamsHistorical/local/constants.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.PROCESSING_RECORDS_LOG_FILENAME = exports.ERROR_LOG_FILENAME = void 0;
exports.ERROR_LOG_FILENAME = 'error.log';
exports.PROCESSING_RECORDS_LOG_FILENAME = 'processing-records.log';


/***/ }),

/***/ "./src/services/teamsHistorical/local/scripts/teamsHistoricalLocalRunner.ts":
/*!**********************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/scripts/teamsHistoricalLocalRunner.ts ***!
  \**********************************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.teamsHistoricalJobRunner = exports.getDistributionListsEmails = void 0;
const core_1 = __webpack_require__(/*! @nestjs/core */ "./node_modules/@nestjs/core/index.js");
const logger_1 = __webpack_require__(/*! ../../../../core/logger */ "./src/core/logger.ts");
const teamsHistoricalLocalModule_1 = __webpack_require__(/*! ../teamsHistoricalLocalModule */ "./src/services/teamsHistorical/local/teamsHistoricalLocalModule.ts");
const teamsHistoricalJobService_1 = __webpack_require__(/*! ../../teamsHistoricalJobService */ "./src/services/teamsHistorical/teamsHistoricalJobService.ts");
const types_1 = __webpack_require__(/*! ../../lib/types */ "./src/services/teamsHistorical/lib/types.ts");
const fs_1 = __webpack_require__(/*! fs */ "fs");
const path_1 = __webpack_require__(/*! path */ "path");
const distributionListMemberEmailsGetterFactory_1 = __webpack_require__(/*! ../../lib/getters/lists/distributionListMemberEmailsGetterFactory */ "./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetterFactory.ts");
const readline_1 = __webpack_require__(/*! readline */ "readline");
const zod_1 = __webpack_require__(/*! zod */ "./node_modules/zod/lib/index.js");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const validation_1 = __webpack_require__(/*! ../../../../validation */ "./src/validation/index.ts");
const constants_1 = __webpack_require__(/*! ../constants */ "./src/services/teamsHistorical/local/constants.ts");
const common_1 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const logger = (0, logger_1.getLogger)(__filename);
const previous24HoursInMilliseconds = Date.now() - (24 * 60 * 60 * 1000);
const readLastLineOfFile = async (filePath) => {
    const fileStream = (0, fs_1.createReadStream)(filePath);
    const rl = (0, readline_1.createInterface)({ input: fileStream });
    let lastLine = '';
    for await (const line of rl) {
        lastLine = line;
    }
    return lastLine;
};
const processedRecordsSchema = zod_1.z.object({
    filter: zod_1.z.object({
        customerInitials: validation_1.nonBlankString,
        customerType: validation_1.nonBlankString,
    }),
    update: zod_1.z.object({
        lastUpdateTimeMs: validation_1.positiveInteger,
        scheduleTimeoutInMinutes: zod_1.z.number().int(),
        jobStartTimeMs: validation_1.positiveInteger,
    }),
});
const processedRecordsLogMessageSchema = zod_1.z.array(processedRecordsSchema);
const defaultTimestampMessage = 'Start timestamp is now previous 24 hours';
const maybeExtractTimestampFromLogLine = (logLine) => {
    const [maybeLastDateLogLine, logMessage] = logLine.split(': ');
    if (maybeLastDateLogLine === undefined || logMessage === undefined) {
        logger.warn(`processing-records.log line format invalid, expected "YYYY-MM-DDTHH:mm:ss.sssZ: <log message>", received: ${logLine}`);
        return undefined;
    }
    const maybeLastDate = new Date(maybeLastDateLogLine);
    if (isNaN(maybeLastDate.getTime())) {
        logger.warn(`processing-records.log last timestamp invalid, expected "YYYY-MM-DDTHH:mm:ss.sssZ", received: ${maybeLastDateLogLine}`);
        return undefined;
    }
    const maybeLogMessage = processedRecordsLogMessageSchema.safeParse(JSON.parse(logMessage));
    if (!maybeLogMessage.success) {
        logger.warn(`processing-records.log log message invalid, error: ${JSON.stringify(maybeLogMessage.error)}`);
        return undefined;
    }
    const maybeProcessedRecords = maybeLogMessage.data[0];
    if (maybeProcessedRecords === undefined) {
        logger.warn('processing-records.log log message content missing');
        return undefined;
    }
    return maybeProcessedRecords.update.lastUpdateTimeMs;
};
const getLastTimestampOrDefault = async () => {
    try {
        const logPath = (0, path_1.join)(process.cwd(), constants_1.PROCESSING_RECORDS_LOG_FILENAME);
        const lastLine = await readLastLineOfFile(logPath);
        const timestamp = maybeExtractTimestampFromLogLine(lastLine);
        if (timestamp === undefined) {
            logger.info(defaultTimestampMessage);
            return previous24HoursInMilliseconds;
        }
        return timestamp;
    }
    catch (err) {
        logger.error(`issue with getLastTimestampOrDefault ${JSON.stringify(err)}`);
        logger.info(defaultTimestampMessage);
        return previous24HoursInMilliseconds;
    }
};
const initApp = async () => core_1.NestFactory.createApplicationContext(teamsHistoricalLocalModule_1.TeamsHistoricalLocalModule);
const getDistributionListsEmails = async (tenantId, app, distributionListEmails = []) => {
    const service = app.get(distributionListMemberEmailsGetterFactory_1.DistributionListMemberEmailsGetterFactory);
    return service.handle(tenantId).handle(distributionListEmails);
};
exports.getDistributionListsEmails = getDistributionListsEmails;
const teamsHistoricalJobRunner = async (params, app) => {
    const service = app.get(teamsHistoricalJobService_1.TeamsHistoricalJobService);
    await service.handle(params);
};
exports.teamsHistoricalJobRunner = teamsHistoricalJobRunner;
const showHelp = () => {
    logger.info(`
Teams Historical Local Runner Processing Tool

USAGE:
  node teamsHistoricalLocalRunner.js [OPTIONS]

OPTIONS:
  --customerId <string>                             Customer ID (required)
  --customerInitials <string>                       Customer initials (required)
  --tenantId <string>                               Tenant ID (required)
  --emails <email1,email2,...>                      Comma-separated list of emails (optional, default: [])
  --customerType <dip|etl>                          Customer type (optional, default: 'etl')
  --startTimeMs <number>                            Start timestamp in milliseconds (optional, default: 24h ago)
  --teamsBucket <string>                            Teams bucket name (optional, default: 'teamsBucket')
  --endTimeMs <number>                              End timestamp in milliseconds (optional)
  --isDryRun <true|false>                           Dry run mode (optional, default: false)
  --output <path>                                   Output file path (optional)
  --useDistributionLists <true|false>               Use distribution lists (optional, default: false)
  --useDistributionListsEmails <email1,email2,...>  Filter distribution lists by specific emails (optional)
  --help                                            Show this help message

EXAMPLES:
  node teamsHistoricalLocalRunner.js --customerId 123 --customerInitials ABC --tenantId tenant-123
  node teamsHistoricalLocalRunner.js --customerId 123 --customerInitials ABC --tenantId tenant-123 --isDryRun true
  node teamsHistoricalLocalRunner.js --customerId 123 --customerInitials ABC --tenantId tenant-123 --emails user1@example.com,user2@example.com
`);
    process.exit(0);
};
const argvSchemaWithTransforms = zod_1.z.object({
    customerId: validation_1.nonBlankString,
    customerInitials: validation_1.nonBlankString,
    tenantId: validation_1.nonBlankString,
    emails: zod_1.z.string().optional().transform((val) => (val ? val.split(',') : [])),
    customerType: zod_1.z.enum(['dip', 'etl']).default('etl'),
    startTimeMs: zod_1.z.string().regex(/^\d+$/u).optional().transform(val => (val ? parseInt(val) : undefined)),
    endTimeMs: zod_1.z.string().regex(/^\d+$/u).optional().transform(val => (val ? parseInt(val) : undefined)),
    isDryRun: zod_1.z.enum(['true', 'false']).optional().transform(val => (val === 'true' ? true : undefined)),
    output: zod_1.z.string().optional(),
    useDistributionLists: zod_1.z.enum(['true', 'false']).optional().transform(val => (val === 'true' ? true : undefined)),
    useDistributionListsEmails: zod_1.z.string().optional().transform(val => (val ? val.split(',') : undefined)),
}).transform(({ startTimeMs, endTimeMs, output, isDryRun, useDistributionLists, useDistributionListsEmails, ...rest }) => ({
    ...rest,
    ...(0, common_1.ifTrueAddOptionalField)('isDryRun', isDryRun),
    ...(0, common_1.ifTrueAddOptionalField)('useDistributionLists', useDistributionLists),
    ...(0, pure_utils_1.ifDefinedThenAddOptionalField)('useDistributionListsEmails', useDistributionListsEmails),
    lastUpdateTimeMs: startTimeMs,
    getMessagesUpToTimestampMs: endTimeMs,
    outputPath: output,
}));
const parseArguments = async () => {
    const args = process.argv.slice(2);
    if (args.includes('--help') || args.includes('-h')) {
        showHelp();
    }
    const rawArgs = {};
    for (let i = 0; i < args.length; i += 2) {
        const flag = args[i];
        const value = args[i + 1];
        if (!flag || !value) {
            throw new Error(`Missing value for flag: ${flag ?? 'undefined'}`);
        }
        if (!flag.startsWith('--')) {
            throw new Error(`Invalid flag format: ${flag}. Flags must start with --`);
        }
        const key = flag.slice(2);
        rawArgs[key] = value;
    }
    const validatedArgs = argvSchemaWithTransforms.parse(rawArgs);
    const params = {
        ...validatedArgs,
        teamsBucket: 'teamsBucket',
        jobName: types_1.teamsHistoricalJobName,
        scheduleTimeoutInMinutes: 60,
        lastUpdateTimeMs: validatedArgs.lastUpdateTimeMs ?? await getLastTimestampOrDefault(),
    };
    return params;
};
const runner = async () => {
    if (process.argv.length < 3) {
        logger.error('No arguments provided. Use --help to see available options.');
        process.exit(1);
    }
    const { useDistributionLists, useDistributionListsEmails, ...jobParams } = await parseArguments();
    const validatedParams = types_1.teamsHistoricalJobParametersSchema.parse(jobParams);
    const app = await initApp();
    if (useDistributionLists) {
        const distributionListEmails = await (0, exports.getDistributionListsEmails)(validatedParams.tenantId, app, useDistributionListsEmails);
        validatedParams.emails = [...(jobParams.emails ?? []), ...distributionListEmails];
    }
    await (0, exports.teamsHistoricalJobRunner)(validatedParams, app);
    await app.close();
};
void runner().then(() => {
    logger.info('runner', { step: 'END' });
    process.exit(0);
}).catch((error) => {
    logger.error('runner', {
        step: 'END',
        error: error instanceof Error ? error.stack : error,
    });
    throw error;
});
process.on('SIGINT', () => {
    console.info('Got SIGINT (aka ctrl-c in docker). Graceful shutdown ', new Date().toISOString());
});
process.on('SIGTERM', () => {
    console.info('Got SIGTERM (docker container stop). Graceful shutdown ', new Date().toISOString());
});


/***/ }),

/***/ "./src/services/teamsHistorical/local/teamsHistoricalLocalModule.ts":
/*!**************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/teamsHistoricalLocalModule.ts ***!
  \**************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsHistoricalLocalModule = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const teamsChatsEntityGetters_1 = __webpack_require__(/*! ../lib/getters/teamsChatsEntityGetters */ "./src/services/teamsHistorical/lib/getters/teamsChatsEntityGetters.ts");
const teamsChannelEntityGetters_1 = __webpack_require__(/*! ../lib/getters/teamsChannelEntityGetters */ "./src/services/teamsHistorical/lib/getters/teamsChannelEntityGetters.ts");
const teamsHistoricalJobService_1 = __webpack_require__(/*! ../teamsHistoricalJobService */ "./src/services/teamsHistorical/teamsHistoricalJobService.ts");
const teamsChannelMessagesGetter_1 = __webpack_require__(/*! ../lib/teamsChannelMessagesGetter */ "./src/services/teamsHistorical/lib/teamsChannelMessagesGetter.ts");
const teamsChatMessagesGetter_1 = __webpack_require__(/*! ../lib/teamsChatMessagesGetter */ "./src/services/teamsHistorical/lib/teamsChatMessagesGetter.ts");
const graphApiAxiosInstanceFactory_1 = __webpack_require__(/*! ../lib/graphApiAxiosInstanceFactory */ "./src/services/teamsHistorical/lib/graphApiAxiosInstanceFactory.ts");
const graphApiQueryFactory_1 = __webpack_require__(/*! ../lib/graphApiQueryFactory */ "./src/services/teamsHistorical/lib/graphApiQueryFactory.ts");
const graphApiBatchedQueryFactory_1 = __webpack_require__(/*! ../lib/graphApiBatchedQueryFactory */ "./src/services/teamsHistorical/lib/graphApiBatchedQueryFactory.ts");
const groupsGetterFactory_1 = __webpack_require__(/*! ../lib/getters/lists/groupsGetterFactory */ "./src/services/teamsHistorical/lib/getters/lists/groupsGetterFactory.ts");
const groupMembersGetterFactory_1 = __webpack_require__(/*! ../lib/getters/lists/groupMembersGetterFactory */ "./src/services/teamsHistorical/lib/getters/lists/groupMembersGetterFactory.ts");
const distributionListMemberEmailsGetterFactory_1 = __webpack_require__(/*! ../lib/getters/lists/distributionListMemberEmailsGetterFactory */ "./src/services/teamsHistorical/lib/getters/lists/distributionListMemberEmailsGetterFactory.ts");
const teamsHistoricalLocalAuthModule_1 = __webpack_require__(/*! ./auth/teamsHistoricalLocalAuthModule */ "./src/services/teamsHistorical/local/auth/teamsHistoricalLocalAuthModule.ts");
const dataRetrievalIssuesRecordLoggerLocal_1 = __webpack_require__(/*! ./writers/dataRetrievalIssuesRecordLoggerLocal */ "./src/services/teamsHistorical/local/writers/dataRetrievalIssuesRecordLoggerLocal.ts");
const processingRecordsUpdaterLocal_1 = __webpack_require__(/*! ./writers/processingRecordsUpdaterLocal */ "./src/services/teamsHistorical/local/writers/processingRecordsUpdaterLocal.ts");
const alertNotificationQueueServiceLocal_1 = __webpack_require__(/*! ./writers/alertNotificationQueueServiceLocal */ "./src/services/teamsHistorical/local/writers/alertNotificationQueueServiceLocal.ts");
const teamsHistoricalWriteServiceLocal_1 = __webpack_require__(/*! ./writers/teamsHistoricalWriteServiceLocal */ "./src/services/teamsHistorical/local/writers/teamsHistoricalWriteServiceLocal.ts");
const fileLoggerLocal_1 = __webpack_require__(/*! ./writers/fileLoggerLocal */ "./src/services/teamsHistorical/local/writers/fileLoggerLocal.ts");
const common_2 = __webpack_require__(/*! ../common */ "./src/services/teamsHistorical/common.ts");
let TeamsHistoricalLocalModule = class TeamsHistoricalLocalModule {
};
TeamsHistoricalLocalModule = __decorate([
    (0, common_1.Module)({
        imports: [
            teamsHistoricalLocalAuthModule_1.TeamsHistoricalAuthLocalModule,
        ],
        providers: [
            graphApiAxiosInstanceFactory_1.GraphApiAxiosInstanceFactory,
            graphApiQueryFactory_1.GraphApiQueryFactory,
            graphApiBatchedQueryFactory_1.GraphApiBatchedQueryFactory,
            groupsGetterFactory_1.GroupsGetterFactory,
            groupMembersGetterFactory_1.GroupMembersGetterFactory,
            distributionListMemberEmailsGetterFactory_1.DistributionListMemberEmailsGetterFactory,
            teamsChannelEntityGetters_1.TeamsChannelEntityGettersFactory,
            teamsChatsEntityGetters_1.TeamsChatEntityGettersFactory,
            teamsChannelMessagesGetter_1.TeamsChannelMessagesGetter,
            teamsChatMessagesGetter_1.TeamsChatMessagesGetter,
            teamsHistoricalJobService_1.TeamsHistoricalJobService,
            dataRetrievalIssuesRecordLoggerLocal_1.DataRetrievalIssuesRecordLoggerLocal,
            processingRecordsUpdaterLocal_1.ProcessingRecordsUpdaterLocal,
            alertNotificationQueueServiceLocal_1.AlertNotificationQueueServiceLocal,
            teamsHistoricalWriteServiceLocal_1.TeamsHistoricalWriteServiceLocal,
            fileLoggerLocal_1.FileLoggerLocal,
            {
                provide: common_2.DATA_RETRIEVAL_ISSUES_RECORD_LOGGER_TOKEN,
                useExisting: dataRetrievalIssuesRecordLoggerLocal_1.DataRetrievalIssuesRecordLoggerLocal,
            },
            {
                provide: common_2.PROCESSING_RECORDS_UPDATER_TOKEN,
                useExisting: processingRecordsUpdaterLocal_1.ProcessingRecordsUpdaterLocal,
            },
            {
                provide: common_2.ALERT_NOTIFICATION_QUEUE_SERVICE_TOKEN,
                useExisting: alertNotificationQueueServiceLocal_1.AlertNotificationQueueServiceLocal,
            },
            {
                provide: common_2.TEAMS_HISTORICAL_WRITE_SERVICE_TOKEN,
                useExisting: teamsHistoricalWriteServiceLocal_1.TeamsHistoricalWriteServiceLocal,
            },
        ],
    })
], TeamsHistoricalLocalModule);
exports.TeamsHistoricalLocalModule = TeamsHistoricalLocalModule;


/***/ }),

/***/ "./src/services/teamsHistorical/local/writers/alertNotificationQueueServiceLocal.ts":
/*!******************************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/writers/alertNotificationQueueServiceLocal.ts ***!
  \******************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.AlertNotificationQueueServiceLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const constants_1 = __webpack_require__(/*! ../constants */ "./src/services/teamsHistorical/local/constants.ts");
const fileLoggerLocal_1 = __webpack_require__(/*! ./fileLoggerLocal */ "./src/services/teamsHistorical/local/writers/fileLoggerLocal.ts");
let AlertNotificationQueueServiceLocal = class AlertNotificationQueueServiceLocal {
    fileLogger;
    constructor(fileLogger) {
        this.fileLogger = fileLogger;
    }
    async handle(notificationDetails) {
        await this.fileLogger.handle({ data: notificationDetails,
            filename: constants_1.ERROR_LOG_FILENAME });
    }
};
AlertNotificationQueueServiceLocal = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [fileLoggerLocal_1.FileLoggerLocal])
], AlertNotificationQueueServiceLocal);
exports.AlertNotificationQueueServiceLocal = AlertNotificationQueueServiceLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/local/writers/dataRetrievalIssuesRecordLoggerLocal.ts":
/*!********************************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/writers/dataRetrievalIssuesRecordLoggerLocal.ts ***!
  \********************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.DataRetrievalIssuesRecordLoggerLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const constants_1 = __webpack_require__(/*! ../constants */ "./src/services/teamsHistorical/local/constants.ts");
const fileLoggerLocal_1 = __webpack_require__(/*! ./fileLoggerLocal */ "./src/services/teamsHistorical/local/writers/fileLoggerLocal.ts");
let DataRetrievalIssuesRecordLoggerLocal = class DataRetrievalIssuesRecordLoggerLocal {
    fileLogger;
    constructor(fileLogger) {
        this.fileLogger = fileLogger;
    }
    async handle(input) {
        await this.fileLogger.handle({ data: input,
            filename: constants_1.ERROR_LOG_FILENAME });
    }
};
DataRetrievalIssuesRecordLoggerLocal = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [fileLoggerLocal_1.FileLoggerLocal])
], DataRetrievalIssuesRecordLoggerLocal);
exports.DataRetrievalIssuesRecordLoggerLocal = DataRetrievalIssuesRecordLoggerLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/local/writers/fileLoggerLocal.ts":
/*!***********************************************************************!*\
  !*** ./src/services/teamsHistorical/local/writers/fileLoggerLocal.ts ***!
  \***********************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FileLoggerLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const fs_1 = __webpack_require__(/*! fs */ "fs");
const path_1 = __webpack_require__(/*! path */ "path");
let FileLoggerLocal = class FileLoggerLocal {
    async handle(input) {
        const timestamp = new Date().toISOString();
        const logEntry = `${timestamp}: ${JSON.stringify(input.data)}\n`;
        const logPath = (0, path_1.join)(process.cwd(), input.filename);
        await fs_1.promises.appendFile(logPath, logEntry, 'utf8');
    }
};
FileLoggerLocal = __decorate([
    (0, common_1.Injectable)()
], FileLoggerLocal);
exports.FileLoggerLocal = FileLoggerLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/local/writers/processingRecordsUpdaterLocal.ts":
/*!*************************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/writers/processingRecordsUpdaterLocal.ts ***!
  \*************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.ProcessingRecordsUpdaterLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const constants_1 = __webpack_require__(/*! ../constants */ "./src/services/teamsHistorical/local/constants.ts");
const fileLoggerLocal_1 = __webpack_require__(/*! ./fileLoggerLocal */ "./src/services/teamsHistorical/local/writers/fileLoggerLocal.ts");
let ProcessingRecordsUpdaterLocal = class ProcessingRecordsUpdaterLocal {
    fileLogger;
    constructor(fileLogger) {
        this.fileLogger = fileLogger;
    }
    async handle(input) {
        await this.fileLogger.handle({ data: input,
            filename: constants_1.PROCESSING_RECORDS_LOG_FILENAME });
    }
};
ProcessingRecordsUpdaterLocal = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [fileLoggerLocal_1.FileLoggerLocal])
], ProcessingRecordsUpdaterLocal);
exports.ProcessingRecordsUpdaterLocal = ProcessingRecordsUpdaterLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/local/writers/teamsHistoricalWriteServiceLocal.ts":
/*!****************************************************************************************!*\
  !*** ./src/services/teamsHistorical/local/writers/teamsHistoricalWriteServiceLocal.ts ***!
  \****************************************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsHistoricalWriteServiceLocal = void 0;
const common_1 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const fs_1 = __webpack_require__(/*! fs */ "fs");
const path_1 = __webpack_require__(/*! path */ "path");
const common_2 = __webpack_require__(/*! ../../common */ "./src/services/teamsHistorical/common.ts");
const stream_1 = __webpack_require__(/*! stream */ "stream");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
let TeamsHistoricalWriteServiceLocal = class TeamsHistoricalWriteServiceLocal {
    async handle(input) {
        const { jobParameters, data, fileName, getMessagesCount } = input;
        const outputDir = jobParameters.outputPath || (0, path_1.join)(process.cwd(), 'local-output', jobParameters.customerInitials, common_2.teamsHistoricalSource);
        const filePath = (0, path_1.join)(outputDir, fileName);
        await fs_1.promises.mkdir(outputDir, { recursive: true });
        const content = stream_1.Readable.from((0, pure_utils_1.mapAsyncIterable)(data, value => `${JSON.stringify(value)}\n`));
        await fs_1.promises.writeFile(filePath, content, 'utf8');
        console.log(`${jobParameters.customerInitials}: ${getMessagesCount()} messages were written to ${filePath}`);
    }
};
TeamsHistoricalWriteServiceLocal = __decorate([
    (0, common_1.Injectable)()
], TeamsHistoricalWriteServiceLocal);
exports.TeamsHistoricalWriteServiceLocal = TeamsHistoricalWriteServiceLocal;


/***/ }),

/***/ "./src/services/teamsHistorical/teamsHistoricalJobService.ts":
/*!*******************************************************************!*\
  !*** ./src/services/teamsHistorical/teamsHistoricalJobService.ts ***!
  \*******************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.TeamsHistoricalJobService = void 0;
const common_1 = __webpack_require__(/*! ./common */ "./src/services/teamsHistorical/common.ts");
const common_2 = __webpack_require__(/*! @nestjs/common */ "./node_modules/@nestjs/common/index.js");
const teamsChannelMessagesGetter_1 = __webpack_require__(/*! ./lib/teamsChannelMessagesGetter */ "./src/services/teamsHistorical/lib/teamsChannelMessagesGetter.ts");
const logger_1 = __webpack_require__(/*! ../../core/logger */ "./src/core/logger.ts");
const pure_utils_1 = __webpack_require__(/*! @fairwords/pure-utils */ "./node_modules/@fairwords/pure-utils/src/index.js");
const utils_1 = __webpack_require__(/*! ./lib/utils */ "./src/services/teamsHistorical/lib/utils.ts");
const teamsChatMessagesGetter_1 = __webpack_require__(/*! ./lib/teamsChatMessagesGetter */ "./src/services/teamsHistorical/lib/teamsChatMessagesGetter.ts");
const errorProcessing_1 = __webpack_require__(/*! ../../common/errorProcessing */ "./src/common/errorProcessing.ts");
const types_1 = __webpack_require__(/*! ../notifications/types */ "./src/services/notifications/types.ts");
const logger = (0, logger_1.getLogger)(__filename);
const teamsHistoricalJobServiceErrorCode = 'TEAMS_HISTORICAL_JOB_SERVICE_ERROR';
const writeResultsToLogs = async (data, getMessagesCount) => {
    for await (const item of data) {
        logger.info(JSON.stringify(item));
    }
    logger.info(`Total messages count: ${getMessagesCount()}`);
};
let TeamsHistoricalJobService = class TeamsHistoricalJobService {
    teamsChannelMessages;
    teamsChatMessages;
    processingRecordsUpdater;
    alertNotificationQueueService;
    teamsHistoricalWriteService;
    constructor(teamsChannelMessages, teamsChatMessages, processingRecordsUpdater, alertNotificationQueueService, teamsHistoricalWriteService) {
        this.teamsChannelMessages = teamsChannelMessages;
        this.teamsChatMessages = teamsChatMessages;
        this.processingRecordsUpdater = processingRecordsUpdater;
        this.alertNotificationQueueService = alertNotificationQueueService;
        this.teamsHistoricalWriteService = teamsHistoricalWriteService;
    }
    async handle(jobParameters) {
        try {
            const jobStartTimeMs = Date.now();
            logger.info(`Got input parameters: ${JSON.stringify(jobParameters)}`);
            const dateStartExclusiveUtcIso8601 = new Date(jobParameters.lastUpdateTimeMs).toISOString();
            const dateEndInclusiveUtcIso8601 = jobParameters.getMessagesUpToTimestampMs === undefined
                ? new Date().toISOString()
                : new Date(jobParameters.getMessagesUpToTimestampMs).toISOString();
            logger.info(`Start processing ${jobParameters.customerInitials} ` +
                `from ${dateStartExclusiveUtcIso8601} to ${dateEndInclusiveUtcIso8601} ` +
                `with the input data ${JSON.stringify(jobParameters)}`);
            const fileName = (0, common_1.getJsonlFileName)(jobParameters.customerId, common_1.teamsHistoricalSource, dateStartExclusiveUtcIso8601, dateEndInclusiveUtcIso8601);
            const interners = (0, common_1.createInternerSet)();
            const getNextMessageIndex = (0, common_1.getNextMessageIndexBuilder)();
            const maxMessageTimestampHolder = { value: jobParameters.lastUpdateTimeMs };
            const maxTimestampUpdater = (0, utils_1.createMaxTimestampUpdater)(maxMessageTimestampHolder);
            const messagesHandlerInput = {
                dateStartExclusiveUtcIso8601,
                dateEndInclusiveUtcIso8601,
                jobParameters,
                fileName,
                interners,
                getNextMessageIndex,
                maxTimestampUpdater,
            };
            const startingEntries = (0, common_1.getStartingEntities)(jobParameters.customerInitials, fileName, common_1.teamsHistoricalSource, interners.stringInterner);
            const teamsChannelMessages = await this.teamsChannelMessages.handle(messagesHandlerInput);
            const teamsChatMessages = this.teamsChatMessages.handle(messagesHandlerInput);
            const allTeamsMessages = (0, pure_utils_1.concatAsyncIterables)([startingEntries, teamsChatMessages, teamsChannelMessages]);
            if (jobParameters.isDryRun) {
                await writeResultsToLogs(allTeamsMessages, getNextMessageIndex);
            }
            else {
                await this.teamsHistoricalWriteService.handle({
                    jobParameters,
                    data: allTeamsMessages,
                    fileName,
                    getMessagesCount: getNextMessageIndex,
                });
            }
            if (jobParameters.isDryRun) {
                return;
            }
            await this.processingRecordsUpdater.handle([{
                    filter: {
                        customerInitials: jobParameters.customerInitials,
                        customerType: jobParameters.customerType,
                    },
                    update: {
                        jobStartTimeMs,
                        lastUpdateTimeMs: maxMessageTimestampHolder.value,
                        scheduleTimeoutInMinutes: jobParameters.scheduleTimeoutInMinutes,
                    },
                }]);
        }
        catch (error) {
            const err = (0, errorProcessing_1.normalizePotentialWebRequestError)(error);
            await this.publishError(err, jobParameters.customerInitials, jobParameters.tenantId);
            logger.error(err);
        }
    }
    async publishError(error, customerInitials, tenantId) {
        await this.alertNotificationQueueService.handle({
            title: `The error during the Teams Historical processed: customer=${customerInitials} | ${tenantId}`,
            message: error.message,
            notificationLevel: types_1.instrumentationTypeError,
            customerInitials,
            tenantId,
            errorCode: teamsHistoricalJobServiceErrorCode,
        });
    }
};
TeamsHistoricalJobService = __decorate([
    (0, common_2.Injectable)(),
    __param(2, (0, common_2.Inject)(common_1.PROCESSING_RECORDS_UPDATER_TOKEN)),
    __param(3, (0, common_2.Inject)(common_1.ALERT_NOTIFICATION_QUEUE_SERVICE_TOKEN)),
    __param(4, (0, common_2.Inject)(common_1.TEAMS_HISTORICAL_WRITE_SERVICE_TOKEN)),
    __metadata("design:paramtypes", [teamsChannelMessagesGetter_1.TeamsChannelMessagesGetter,
        teamsChatMessagesGetter_1.TeamsChatMessagesGetter, Object, Object, Object])
], TeamsHistoricalJobService);
exports.TeamsHistoricalJobService = TeamsHistoricalJobService;


/***/ }),

/***/ "./src/validation/index.ts":
/*!*********************************!*\
  !*** ./src/validation/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.nonNegativeIntegerStringTransform = exports.percentageStringTransform = exports.integerMoreOrEqualThanOneStringTransform = exports.objectIdString = exports.nonNegativeNumericIntegerString = exports.positiveNumericIntegerString = exports.iso8601String = exports.nonBlankString = exports.nonNegativeInteger = exports.positiveNumber = exports.positiveInteger = void 0;
const mongoose_1 = __webpack_require__(/*! mongoose */ "./node_modules/mongoose/index.js");
const zod_1 = __webpack_require__(/*! zod */ "./node_modules/zod/lib/index.js");
exports.positiveInteger = zod_1.z.number().positive().int();
exports.positiveNumber = zod_1.z.number().positive();
exports.nonNegativeInteger = zod_1.z.number().nonnegative().int();
exports.nonBlankString = zod_1.z.string().refine((value) => value.trim().length > 0, 'String must be non-blank (contain not only whitespaces)');
const iso8601Regex = /^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?(?:[+-]\d\d:\d\d|Z)?$/iu;
exports.iso8601String = zod_1.z.string().refine((value) => value.search(iso8601Regex) >= 0 &&
    !isNaN(new Date(value).getTime()), 'String must be a valid ISO 8601 date');
const positiveNumberIntegerRegex = /^[1-9]\d*$/iu;
exports.positiveNumericIntegerString = zod_1.z.string().refine((value) => value.search(positiveNumberIntegerRegex) >= 0 &&
    !isNaN(Number(value)), 'String must be a numeric positive integer string');
const nonNegativeIntegerNumberRegex = /^\d+$/iu;
exports.nonNegativeNumericIntegerString = zod_1.z.string().refine((value) => value.search(nonNegativeIntegerNumberRegex) >= 0 &&
    !isNaN(Number(value)), 'String must be a numeric non-negative integer string');
exports.objectIdString = zod_1.z
    .string()
    .refine(val => mongoose_1.Types.ObjectId.isValid(val), {
    message: 'Invalid ObjectId string',
});
exports.integerMoreOrEqualThanOneStringTransform = zod_1.z.string().refine((val) => {
    const num = Number(val);
    return !isNaN(num) && Number.isInteger(num) && num >= 1;
}, { message: 'Must be a string representation of an integer not less than 1' }).transform(Number);
exports.percentageStringTransform = zod_1.z.string().refine((val) => {
    const num = Number(val);
    return !isNaN(num) && Number.isInteger(num) && num >= 0 && num <= 100;
}, { message: 'Must be a string representation of an integer between 0 and 100' }).transform(Number);
exports.nonNegativeIntegerStringTransform = zod_1.z.string().refine((val) => {
    const num = Number(val);
    return !isNaN(num) && Number.isInteger(num) && num >= 0;
}, { message: 'Must be a string representation of an integer not less than 0' }).transform(Number);


/***/ }),

/***/ "assert":
/*!*************************!*\
  !*** external "assert" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ "async_hooks":
/*!******************************!*\
  !*** external "async_hooks" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("async_hooks");

/***/ }),

/***/ "buffer":
/*!*************************!*\
  !*** external "buffer" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("buffer");

/***/ }),

/***/ "crypto":
/*!*************************!*\
  !*** external "crypto" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("crypto");

/***/ }),

/***/ "dns":
/*!**********************!*\
  !*** external "dns" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("dns");

/***/ }),

/***/ "events":
/*!*************************!*\
  !*** external "events" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ "http":
/*!***********************!*\
  !*** external "http" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ "https":
/*!************************!*\
  !*** external "https" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ "net":
/*!**********************!*\
  !*** external "net" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("net");

/***/ }),

/***/ "node:async_hooks":
/*!***********************************!*\
  !*** external "node:async_hooks" ***!
  \***********************************/
/***/ ((module) => {

"use strict";
module.exports = require("node:async_hooks");

/***/ }),

/***/ "os":
/*!*********************!*\
  !*** external "os" ***!
  \*********************/
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ "perf_hooks":
/*!*****************************!*\
  !*** external "perf_hooks" ***!
  \*****************************/
/***/ ((module) => {

"use strict";
module.exports = require("perf_hooks");

/***/ }),

/***/ "process":
/*!**************************!*\
  !*** external "process" ***!
  \**************************/
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ "punycode":
/*!***************************!*\
  !*** external "punycode" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("punycode");

/***/ }),

/***/ "querystring":
/*!******************************!*\
  !*** external "querystring" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("querystring");

/***/ }),

/***/ "readline":
/*!***************************!*\
  !*** external "readline" ***!
  \***************************/
/***/ ((module) => {

"use strict";
module.exports = require("readline");

/***/ }),

/***/ "repl":
/*!***********************!*\
  !*** external "repl" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("repl");

/***/ }),

/***/ "stream":
/*!*************************!*\
  !*** external "stream" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ "string_decoder":
/*!*********************************!*\
  !*** external "string_decoder" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("string_decoder");

/***/ }),

/***/ "timers":
/*!*************************!*\
  !*** external "timers" ***!
  \*************************/
/***/ ((module) => {

"use strict";
module.exports = require("timers");

/***/ }),

/***/ "tls":
/*!**********************!*\
  !*** external "tls" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tls");

/***/ }),

/***/ "tty":
/*!**********************!*\
  !*** external "tty" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ "url":
/*!**********************!*\
  !*** external "url" ***!
  \**********************/
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ "util":
/*!***********************!*\
  !*** external "util" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ "zlib":
/*!***********************!*\
  !*** external "zlib" ***!
  \***********************/
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			id: moduleId,
/******/ 			loaded: false,
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/******/ 	// the startup function
/******/ 	__webpack_require__.x = () => {
/******/ 		// Load entry module and return exports
/******/ 		// This entry module depends on other loaded chunks and execution need to be delayed
/******/ 		var __webpack_exports__ = __webpack_require__.O(undefined, ["chunks/vendors-node_modules"], () => (__webpack_require__("./src/services/teamsHistorical/local/scripts/teamsHistoricalLocalRunner.ts")))
/******/ 		__webpack_exports__ = __webpack_require__.O(__webpack_exports__);
/******/ 		return __webpack_exports__;
/******/ 	};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/chunk loaded */
/******/ 	(() => {
/******/ 		var deferred = [];
/******/ 		__webpack_require__.O = (result, chunkIds, fn, priority) => {
/******/ 			if(chunkIds) {
/******/ 				priority = priority || 0;
/******/ 				for(var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--) deferred[i] = deferred[i - 1];
/******/ 				deferred[i] = [chunkIds, fn, priority];
/******/ 				return;
/******/ 			}
/******/ 			var notFulfilled = Infinity;
/******/ 			for (var i = 0; i < deferred.length; i++) {
/******/ 				var [chunkIds, fn, priority] = deferred[i];
/******/ 				var fulfilled = true;
/******/ 				for (var j = 0; j < chunkIds.length; j++) {
/******/ 					if ((priority & 1 === 0 || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => (__webpack_require__.O[key](chunkIds[j])))) {
/******/ 						chunkIds.splice(j--, 1);
/******/ 					} else {
/******/ 						fulfilled = false;
/******/ 						if(priority < notFulfilled) notFulfilled = priority;
/******/ 					}
/******/ 				}
/******/ 				if(fulfilled) {
/******/ 					deferred.splice(i--, 1)
/******/ 					var r = fn();
/******/ 					if (r !== undefined) result = r;
/******/ 				}
/******/ 			}
/******/ 			return result;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks and sibling chunks for the entrypoint
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "" + chunkId + ".js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/node module decorator */
/******/ 	(() => {
/******/ 		__webpack_require__.nmd = (module) => {
/******/ 			module.paths = [];
/******/ 			if (!module.children) module.children = [];
/******/ 			return module;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/require chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded chunks
/******/ 		// "1" means "loaded", otherwise not loaded yet
/******/ 		var installedChunks = {
/******/ 			"teamsHistoricalRunner": 1
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.O.require = (chunkId) => (installedChunks[chunkId]);
/******/ 		
/******/ 		var installChunk = (chunk) => {
/******/ 			var moreModules = chunk.modules, chunkIds = chunk.ids, runtime = chunk.runtime;
/******/ 			for(var moduleId in moreModules) {
/******/ 				if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 					__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 				}
/******/ 			}
/******/ 			if(runtime) runtime(__webpack_require__);
/******/ 			for(var i = 0; i < chunkIds.length; i++)
/******/ 				installedChunks[chunkIds[i]] = 1;
/******/ 			__webpack_require__.O();
/******/ 		};
/******/ 		
/******/ 		// require() chunk loading for javascript
/******/ 		__webpack_require__.f.require = (chunkId, promises) => {
/******/ 			// "1" is the signal for "already loaded"
/******/ 			if(!installedChunks[chunkId]) {
/******/ 				if(true) { // all chunks have JS
/******/ 					installChunk(require("./" + __webpack_require__.u(chunkId)));
/******/ 				} else installedChunks[chunkId] = 1;
/******/ 			}
/******/ 		};
/******/ 		
/******/ 		// no external install chunk
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/startup chunk dependencies */
/******/ 	(() => {
/******/ 		var next = __webpack_require__.x;
/******/ 		__webpack_require__.x = () => {
/******/ 			__webpack_require__.e("chunks/vendors-node_modules");
/******/ 			return next();
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// run startup
/******/ 	var __webpack_exports__ = __webpack_require__.x();
/******/ 	var __webpack_export_target__ = exports;
/******/ 	for(var i in __webpack_exports__) __webpack_export_target__[i] = __webpack_exports__[i];
/******/ 	if(__webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", { value: true });
/******/ 	
/******/ })()
;