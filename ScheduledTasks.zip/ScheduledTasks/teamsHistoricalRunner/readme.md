# Teams Historical Local Job

A standalone tool for retrieving and processing Microsoft Teams historical chat data locally. This package includes a PowerShell wrapper script that securely manages credentials and executes a Node.js application to fetch Teams messages for specified users or distribution lists.

## Description

The Teams Historical Local Job consists of two main components:

1. **PowerShell Script (`teamsHistoricalRunner.ps1`)** - A secure wrapper that:
   - Retrieves Microsoft Graph API credentials from Windows Credential Manager
   - Sets environment variables for authentication
   - Executes the Node.js application with specified parameters
   - Cleans up sensitive environment variables after execution

2. **Node.js Application (`teamsHistoricalRunner.js`)** - The core processing engine that:
   - Connects to Microsoft Graph API using provided credentials
   - Retrieves Teams chat messages for specified users or distribution lists
   - Processes and filters messages based on time ranges
   - Optionally includes users from organization distribution lists when `-UseDistributionLists` is enabled
   - Outputs results to specified location or console

## Requirements

### Ecomms Customer Identifiers

Users should be provided the following:
- CustomerId
- CustomerInitials

### System Requirements
- **Windows Credential Manager** - Built into Windows systems
- **CredentialManager PowerShell Module** - Install using: `Install-Module -Name CredentialManager`
- **Node.js** - Minimum supported version: v18 or higher

### Microsoft Entra App Registration
- Register or use an existing application in the [Microsoft Entra admin center](https://entra.microsoft.com/)
- Obtain the following credentials:
  - **Tenant ID** - Your organization's directory ID
  - **Client ID** - The application (client) ID
  - **Client Secret** - A client secret for the registered application
- Configure appropriate Microsoft Graph API permissions for Teams data access
  - ChannelMember.Read.All
  - ChannelMessage.Read.All
  - Chat.Read.All
  - ChatMember.Read.All
  - Group.Read.All
  - Team.ReadBasic.All
  - TeamMember.Read.All
  - TeamSettings.Read.All
  - User.Read.All

### Credential Setup
Store the following credentials in Windows Credential Manager as Generic Credentials:
- **Target:** `TeamsApp_TenantId` → **Password:** Your Tenant ID
- **Target:** `TeamsApp_ClientId` → **Password:** Your Client ID  
- **Target:** `TeamsApp_ClientSecret` → **Password:** Your Client Secret

#### Adding Credentials via PowerShell
You can add credentials using PowerShell with the CredentialManager module:

```powershell
# Install the CredentialManager module if not already installed
Install-Module -Name CredentialManager -Force

# Add Tenant ID
New-StoredCredential -Target "TeamsApp_TenantId" -UserName "TeamsApp_TenantId" -Password "c6e6ddab-d81d-4450-a166-5922ee7ef312" -Type Generic

# Add Client ID  
New-StoredCredential -Target "TeamsApp_ClientId" -UserName "TeamsApp_ClientId" -Password "bc701d44-7278-4851-b75b-eabe7037b12e" -Type Generic

# Add Client Secret
New-StoredCredential -Target "TeamsApp_ClientSecret" -UserName "TeamsApp_ClientSecret" -Password "cTN8Q~mg~ql46UQVk4LvY_W-PgAWl3u.A1Rz8cl1" -Type Generic
```

Replace `YOUR_TENANT_ID_HERE`, `YOUR_CLIENT_ID_HERE`, and `YOUR_CLIENT_SECRET_HERE` with your actual credentials.

## Usage

1. Extract the zip archive to your desired location
2. Open PowerShell and navigate to the extracted directory
3. Run the script with required parameters:

```powershell
.\teamsHistoricalRunner.ps1 -CustomerId "YOUR_CUSTOMER_ID_HERE" -CustomerInitials "NEE"
```

### Basic Examples

```powershell
# Basic execution with required parameters
.\teamsHistoricalRunner.ps1 -CustomerId "6733b8f2ab3b1dc8e08d4113" -CustomerInitials "NEE"

# Dry run mode to test configuration
.\teamsHistoricalRunner.ps1 -CustomerId "6733b8f2ab3b1dc8e08d4113" -CustomerInitials "NEE" -IsDryRun "true"

# Process specific email addresses
.\teamsHistoricalRunner.ps1 -CustomerId "6733b8f2ab3b1dc8e08d4113" -CustomerInitials "NEE" -Emails "user1@company.com,user2@company.com"

# Custom time range processing
.\teamsHistoricalRunner.ps1 -CustomerId "6733b8f2ab3b1dc8e08d4113" -CustomerInitials "NEE" -StartTimeMs "1640995200000" -EndTimeMs "1641081600000"

# Include distribution list members in processing
.\teamsHistoricalRunner.ps1 -CustomerId "6733b8f2ab3b1dc8e08d4113" -CustomerInitials "NEE" -UseDistributionLists "true"

# Combine specific emails with distribution lists
.\teamsHistoricalRunner.ps1 -CustomerId "6733b8f2ab3b1dc8e08d4113" -CustomerInitials "NEE" -Emails "user1@company.com" -UseDistributionLists "true"
```

## Output

### Default Output Location
By default, output files are saved to:
```
local-output\{customer-initials}\teamsHistoricalSource\
```

For example, if `-CustomerInitials "ABC"` is specified, files will be saved to:
```
local-output\ABC\teamsHistoricalSource\
```

### File Naming Convention
Output files follow this naming pattern:
```
{customerId}-teamsHistoricalSource-{startTimeIso8601}-{endTimeIso8601}.jsonl
```

**Example filename:**
```
CUST001-teamsHistoricalSource-2024-01-01T00:00:00.000Z-2024-01-02T00:00:00.000Z.jsonl
```

### Custom Output Location
Use the `-Output` parameter to specify a custom output path:
```powershell
.\teamsHistoricalRunner.ps1 -CustomerId "123" -CustomerInitials "ABC" -Output "C:\My\Custom\Path\"
```

## Options

### Required Parameters
| Parameter             | Description                               |
|-----------------------|-------------------------------------------|
| `-CustomerId`         | Unique identifier for the customer        |
| `-CustomerInitials`   | Customer initials                         |

### Optional Parameters
| Parameter                     | Type   | Default                                                   | Description                                                                                                                                                                                             |
|-------------------------------|--------|-----------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| `-Emails`                     | String | -                                                         | Comma-separated list of email addresses to monitor associated messages                                                                                                                                  |
| `-CustomerType`               | String | "etl"                                                     | Customer type (`dip` or `etl`)                                                                                                                                                                          |
| `-StartTimeMs`                | String | 24h ago                                                   | Unix/Epoch Start timestamp in milliseconds                                                                                                                                                              |
| `-EndTimeMs`                  | String | -                                                         | Unix/Epoch End timestamp in milliseconds                                                                                                                                                                |
| `-IsDryRun`                   | String | "false"                                                   | Enable dry run mode (`true` or `false`)                                                                                                                                                                 |
| `-Output`                     | String | `local-output/{customer-initials}/teamsHistoricalSource/` | Custom output file path                                                                                                                                                                                 |
| `-UseDistributionLists`       | String | "false"                                                   | Process distribution lists - retrieves email addresses from the tenant's organization group lists and adds them to the processing queue alongside any emails specified in `-Emails` (`true` or `false`) |
| `-UseDistributionListsEmails` | String | -                                                         | Comma-separated list of email addresses to only processes distribution lists matching these email addresses instead of all tenant distribution lists                                                    |
| `-Help`                       | Switch | -                                                         | Display help information                                                                                                                                                                                |

### Script Behavior Notes
  - When the script runs without a `-StartTimeMs` flag it will check for an existing `processing-records.log` to get the most recent timestamp of the previous run as a starting time, else it will default to the last 24 hours.
  - It will only get messages from participants that match the monitored emails list.  This also includes distribution (groups) list emails.
  - If `-UseDistributionLists` is true and there is no `-UseDistributionListsEmails` flag, it will use all distribution lists in the organization.
  - When obtaining historical message data, job completion may vary depending on the message volume from the specified date range.  If trying to retrieve large amounts of data, try performing the job in batches (daily or weekly date ranges).

## Troubleshooting

### Common Issues

**Credential Errors:**
- Ensure all three credentials are stored in Windows Credential Manager
- Verify credential targets match exactly: `TeamsApp_TenantId`, `TeamsApp_ClientId`, `TeamsApp_ClientSecret`

**PowerShell Module Missing:**
```powershell
Install-Module -Name CredentialManager -Force
```

**Node.js Not Found:**
- Install Node.js v18 or higher from [nodejs.org](https://nodejs.org/)
- Verify installation: `node --version`

## Changelog

### Version 0.1.1 (ETL v.0.0.377)
- Fix missing FileLoggerLocal import

### Version 0.1.0 (Initial Release)
- Initial release of Teams Historical Local Job
- PowerShell wrapper for secure credential management
- Node.js application for Teams data processing
- Support for user-specific and distribution list processing
- Configurable time ranges and output options
- Dry run mode for testing and validation
