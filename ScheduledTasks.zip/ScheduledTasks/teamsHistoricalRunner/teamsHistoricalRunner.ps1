param(
    [Parameter(Mandatory=$true)]
    [string]$CustomerId,

    [Parameter(Mandatory=$true)]
    [string]$CustomerInitials,

    [Parameter(Mandatory=$false)]
    [string]$Emails,

    [Parameter(Mandatory=$false)]
    [ValidateSet("dip", "etl")]
    [string]$CustomerType = "etl",

    [Parameter(Mandatory=$false)]
    [string]$StartTimeMs,

    [Parameter(Mandatory=$false)]
    [string]$EndTimeMs,

    [Parameter(Mandatory=$false)]
    [ValidateSet("true", "false")]
    [string]$IsDryRun = "false",

    [Parameter(Mandatory=$false)]
    [string]$Output,

    [Parameter(Mandatory=$false)]
    [ValidateSet("true", "false")]
    [string]$UseDistributionLists = "false",

    [Parameter(Mandatory=$false)]
    [string]$UseDistributionListsEmails,

    [Parameter(Mandatory=$false)]
    [switch]$Help
)

# Show help if requested
if ($Help) {
    Write-Host @"
Teams Historical Local Processing Tool - PowerShell Wrapper

USAGE:
  .\teamsHistoricalRunner.ps1 [OPTIONS]

REQUIRED OPTIONS:
  -CustomerId <string>                             Customer ID
  -CustomerInitials <string>                       Customer initials

OPTIONAL OPTIONS:
  -Emails <email1,email2,...>                      Comma-separated list of emails
  -CustomerType <dip|etl>                          Customer type (default: 'etl')
  -StartTimeMs <number>                            Start timestamp in milliseconds (default: 24h ago)
  -EndTimeMs <number>                              End timestamp in milliseconds
  -IsDryRun <true|false>                           Dry run mode (default: false)
  -Output <path>                                   Output file path
  -UseDistributionLists <true|false>               Use distribution lists (default: false)
  -UseDistributionListsEmails <email1,email2,...>  Filter distribution lists by specific emails
  -Help                                            Show this help message

CREDENTIAL REQUIREMENTS:
This script expects the following credentials in Windows Credential Manager:
  - Target: "TeamsApp_TenantId" -> Generic credential containing Tenant ID
  - Target: "TeamsApp_ClientId" -> Generic credential containing Client ID
  - Target: "TeamsApp_ClientSecret" -> Generic credential containing Client Secret

EXAMPLE:
  .\teamsHistoricalRunner.ps1 -CustomerId "CUST001" -CustomerInitials "ABC" -CustomerType "etl" -IsDryRun "true"
"@
    exit 0
}

try {
    Write-Host "Starting Teams Historical Local Processing..." -ForegroundColor Green

    # Check if CredentialManager module is available
    if (-not (Get-Module -ListAvailable -Name CredentialManager)) {
        Write-Error "CredentialManager PowerShell module is not installed. Please install it first using: Install-Module -Name CredentialManager"
        exit 1
    }

    # Import CredentialManager module
    Import-Module CredentialManager -Force

    Write-Host "Retrieving credentials from Windows Credential Manager..." -ForegroundColor Yellow

    # Retrieve credentials from Windows Credential Manager
    $tenantIdCred = Get-StoredCredential -Target "TeamsApp_TenantId" -ErrorAction SilentlyContinue
    $clientIdCred = Get-StoredCredential -Target "TeamsApp_ClientId" -ErrorAction SilentlyContinue
    $clientSecretCred = Get-StoredCredential -Target "TeamsApp_ClientSecret" -ErrorAction SilentlyContinue

    # Check if all required credentials were found
    if (-not $tenantIdCred) {
        Write-Error "Tenant ID credential not found. Please store it in Credential Manager with target 'TeamsApp_TenantId'"
        exit 1
    }

    if (-not $clientIdCred) {
        Write-Error "Client ID credential not found. Please store it in Credential Manager with target 'TeamsApp_ClientId'"
        exit 1
    }

    if (-not $clientSecretCred) {
        Write-Error "Client Secret credential not found. Please store it in Credential Manager with target 'TeamsApp_ClientSecret'"
        exit 1
    }

    # Extract credential values - convert SecureString to plain text
    # For generic credentials, the password field typically contains the actual value
    $tenantId = $tenantIdCred.GetNetworkCredential().Password
    $clientId = $clientIdCred.GetNetworkCredential().Password
    $clientSecret = $clientSecretCred.GetNetworkCredential().Password

    Write-Host "Credentials retrieved successfully" -ForegroundColor Green

    # Set environment variables
    $env:CLIENT_ID = $clientId
    $env:CLIENT_SECRET = $clientSecret

    Write-Host "Environment variables set: CLIENT_ID and CLIENT_SECRET" -ForegroundColor Green

    # Build arguments for Node.js script
    $nodeArgs = @(
        "--customerId", $CustomerId,
        "--customerInitials", $CustomerInitials,
        "--tenantId", $tenantId
    )

    # Add optional parameters if provided
    if ($Emails) {
        $nodeArgs += @("--emails", $Emails)
    }

    if ($CustomerType -ne "etl") {
        $nodeArgs += @("--customerType", $CustomerType)
    }

    if ($StartTimeMs) {
        $nodeArgs += @("--startTimeMs", $StartTimeMs)
    }

    if ($EndTimeMs) {
        $nodeArgs += @("--endTimeMs", $EndTimeMs)
    }

    if ($IsDryRun -ne "false") {
        $nodeArgs += @("--isDryRun", $IsDryRun)
    }

    if ($Output) {
        $nodeArgs += @("--output", $Output)
    }

    if ($UseDistributionLists -ne "false") {
        $nodeArgs += @("--useDistributionLists", $UseDistributionLists)
    }

    if ($UseDistributionListsEmails) {
        $nodeArgs += @("--useDistributionListsEmails", $UseDistributionListsEmails)
    }

    # Check if Node.js script exists
    if (-not (Test-Path "teamsHistoricalRunner.js")) {
        Write-Error "Node.js script 'teamsHistoricalRunner.js' not found in current directory"
        exit 1
    }

    Write-Host "Executing Node.js script with provided arguments..." -ForegroundColor Yellow
    Write-Host "Command: node teamsHistoricalBatch.js $($nodeArgs -join ' ')" -ForegroundColor Cyan

    # Execute the Node.js script with arguments
    & node teamsHistoricalRunner.js @nodeArgs

    $exitCode = $LASTEXITCODE

    if ($exitCode -eq 0) {
        Write-Host "Teams Historical Local Processing completed successfully" -ForegroundColor Green
    } else {
        Write-Error "Teams Historical Local Processing failed with exit code: $exitCode"
        exit $exitCode
    }

} catch {
    Write-Error "An error occurred: $($_.Exception.Message)"
    Write-Error "Stack Trace: $($_.ScriptStackTrace)"
    exit 1
} finally {
    # Clean up environment variables for security
    Remove-Item Env:\CLIENT_ID -ErrorAction SilentlyContinue
    Remove-Item Env:\CLIENT_SECRET -ErrorAction SilentlyContinue
    Write-Host "Environment variables cleaned up" -ForegroundColor Yellow
}

# SIG # Begin signature block
# MIIoXQYJKoZIhvcNAQcCoIIoTjCCKEoCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBl2dqv8r915WEi
# mUdgu9gTjwLnuvkZq2eqcWNmmSTDjKCCDZMwggawMIIEmKADAgECAhAIrUCyYNKc
# TJ9ezam9k67ZMA0GCSqGSIb3DQEBDAUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQK
# EwxEaWdpQ2VydCBJbmMxGTAXBgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNV
# BAMTGERpZ2lDZXJ0IFRydXN0ZWQgUm9vdCBHNDAeFw0yMTA0MjkwMDAwMDBaFw0z
# NjA0MjgyMzU5NTlaMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAw
# ggIKAoICAQDVtC9C0CiteLdd1TlZG7GIQvUzjOs9gZdwxbvEhSYwn6SOaNhc9es0
# JAfhS0/TeEP0F9ce2vnS1WcaUk8OoVf8iJnBkcyBAz5NcCRks43iCH00fUyAVxJr
# Q5qZ8sU7H/Lvy0daE6ZMswEgJfMQ04uy+wjwiuCdCcBlp/qYgEk1hz1RGeiQIXhF
# LqGfLOEYwhrMxe6TSXBCMo/7xuoc82VokaJNTIIRSFJo3hC9FFdd6BgTZcV/sk+F
# LEikVoQ11vkunKoAFdE3/hoGlMJ8yOobMubKwvSnowMOdKWvObarYBLj6Na59zHh
# 3K3kGKDYwSNHR7OhD26jq22YBoMbt2pnLdK9RBqSEIGPsDsJ18ebMlrC/2pgVItJ
# wZPt4bRc4G/rJvmM1bL5OBDm6s6R9b7T+2+TYTRcvJNFKIM2KmYoX7BzzosmJQay
# g9Rc9hUZTO1i4F4z8ujo7AqnsAMrkbI2eb73rQgedaZlzLvjSFDzd5Ea/ttQokbI
# YViY9XwCFjyDKK05huzUtw1T0PhH5nUwjewwk3YUpltLXXRhTT8SkXbev1jLchAp
# QfDVxW0mdmgRQRNYmtwmKwH0iU1Z23jPgUo+QEdfyYFQc4UQIyFZYIpkVMHMIRro
# OBl8ZhzNeDhFMJlP/2NPTLuqDQhTQXxYPUez+rbsjDIJAsxsPAxWEQIDAQABo4IB
# WTCCAVUwEgYDVR0TAQH/BAgwBgEB/wIBADAdBgNVHQ4EFgQUaDfg67Y7+F8Rhvv+
# YXsIiGX0TkIwHwYDVR0jBBgwFoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0P
# AQH/BAQDAgGGMBMGA1UdJQQMMAoGCCsGAQUFBwMDMHcGCCsGAQUFBwEBBGswaTAk
# BggrBgEFBQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAC
# hjVodHRwOi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9v
# dEc0LmNydDBDBgNVHR8EPDA6MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5j
# b20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNybDAcBgNVHSAEFTATMAcGBWeBDAED
# MAgGBmeBDAEEATANBgkqhkiG9w0BAQwFAAOCAgEAOiNEPY0Idu6PvDqZ01bgAhql
# +Eg08yy25nRm95RysQDKr2wwJxMSnpBEn0v9nqN8JtU3vDpdSG2V1T9J9Ce7FoFF
# UP2cvbaF4HZ+N3HLIvdaqpDP9ZNq4+sg0dVQeYiaiorBtr2hSBh+3NiAGhEZGM1h
# mYFW9snjdufE5BtfQ/g+lP92OT2e1JnPSt0o618moZVYSNUa/tcnP/2Q0XaG3Ryw
# YFzzDaju4ImhvTnhOE7abrs2nfvlIVNaw8rpavGiPttDuDPITzgUkpn13c5Ubdld
# AhQfQDN8A+KVssIhdXNSy0bYxDQcoqVLjc1vdjcshT8azibpGL6QB7BDf5WIIIJw
# 8MzK7/0pNVwfiThV9zeKiwmhywvpMRr/LhlcOXHhvpynCgbWJme3kuZOX956rEnP
# LqR0kq3bPKSchh/jwVYbKyP/j7XqiHtwa+aguv06P0WmxOgWkVKLQcBIhEuWTatE
# QOON8BUozu3xGFYHKi8QxAwIZDwzj64ojDzLj4gLDb879M4ee47vtevLt/B3E+bn
# KD+sEq6lLyJsQfmCXBVmzGwOysWGw/YmMwwHS6DTBwJqakAwSEs0qFEgu60bhQji
# WQ1tygVQK+pKHJ6l/aCnHwZ05/LWUpD9r4VIIflXO7ScA+2GRfS0YW6/aOImYIbq
# yK+p/pQd52MbOoZWeE4wggbbMIIEw6ADAgECAhAI2uCQ/VmhAozDBeMbELERMA0G
# CSqGSIb3DQEBCwUAMGkxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwg
# SW5jLjFBMD8GA1UEAxM4RGlnaUNlcnQgVHJ1c3RlZCBHNCBDb2RlIFNpZ25pbmcg
# UlNBNDA5NiBTSEEzODQgMjAyMSBDQTEwHhcNMjQwOTI2MDAwMDAwWhcNMjYxMDIy
# MjM1OTU5WjBjMQswCQYDVQQGEwJVUzERMA8GA1UECBMIQ29sb3JhZG8xETAPBgNV
# BAcTCExvbmdtb250MRYwFAYDVQQKEw1GYWlyd29yZHMgSW5jMRYwFAYDVQQDEw1G
# YWlyd29yZHMgSW5jMIIBojANBgkqhkiG9w0BAQEFAAOCAY8AMIIBigKCAYEAyoIb
# zIfnep0GueEr1LvlZKYwQYannbBmwg8oTGCs3Gsy9hHGAkZM7CtM6TH9+7SXf5Ey
# dsLTufftGQVupLr7cG7y+1NrMJDRes7Eu7B90OFWtJCgtGHwIxdxA7DrG58bb+0M
# PjTmKbKPVyatOp2fFX+41Ub2GAmOVwk8iPDrSCE/Hk0CzJqQOkrpGpRvXPgJm6Cq
# rBgq6tF42TG/8n6MeXz0N7Ie/2pMbHkslXvC8WPD8I0ALqeR17WLJV40OFXaJVo3
# 4YFBUqzbwgwBoEKA7M/CtAeecn8ky3xLlRmYTCjGtduZXx92wvl2Xm4lqN5yRwDI
# xlLZfKhMoQZS6Q4CM1Mw2gVz8Kx5kG/OXgO+ZugfOuo2vou0egDgFKKML2zbJ9rl
# BNj26ghRyZjJHYuPsVpVm1fMNemjNwBvmXJi6drpmlR+IPXz7Xkxak4RhIg4GYyi
# fMIriR8b2SRaMc/UnJIHmqnb32LpA6/fQT1YAqTZM/FcsLge39tDeQsUk1YzAgMB
# AAGjggIDMIIB/zAfBgNVHSMEGDAWgBRoN+Drtjv4XxGG+/5hewiIZfROQjAdBgNV
# HQ4EFgQUWK7z/I/+tyeLpoC4hi717n2ZszgwPgYDVR0gBDcwNTAzBgZngQwBBAEw
# KTAnBggrBgEFBQcCARYbaHR0cDovL3d3dy5kaWdpY2VydC5jb20vQ1BTMA4GA1Ud
# DwEB/wQEAwIHgDATBgNVHSUEDDAKBggrBgEFBQcDAzCBtQYDVR0fBIGtMIGqMFOg
# UaBPhk1odHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRD
# b2RlU2lnbmluZ1JTQTQwOTZTSEEzODQyMDIxQ0ExLmNybDBToFGgT4ZNaHR0cDov
# L2NybDQuZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0Q29kZVNpZ25pbmdS
# U0E0MDk2U0hBMzg0MjAyMUNBMS5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMCQGCCsG
# AQUFBzABhhhodHRwOi8vb2NzcC5kaWdpY2VydC5jb20wXAYIKwYBBQUHMAKGUGh0
# dHA6Ly9jYWNlcnRzLmRpZ2ljZXJ0LmNvbS9EaWdpQ2VydFRydXN0ZWRHNENvZGVT
# aWduaW5nUlNBNDA5NlNIQTM4NDIwMjFDQTEuY3J0MAkGA1UdEwQCMAAwDQYJKoZI
# hvcNAQELBQADggIBADWkaPXF4F0um1D2pwcFVJZZfR3riK6ApeV0kOtizPsAxoKm
# 39hd/I1fNgP49S9HiSh8Esx86nMt6tJN0AO0j8FpQZ6IYlkvyIJUg8cyFuSGUo4T
# /nAi8JyX0ZcO0t8FvmkruhAJ5FguS4vUzgD5FWcvxvqF+uFsRppZdnkeSAHsJ/h4
# BvxN623ZsKZy51s0maRLpUw0EPewxCz6PykMYdj8s+myCcosyXVYbHYKugPtMlrN
# PfqMgzrKzJchReY9F3T2r1cf05feQqsT0OcGHdnX8veUk6AT169lfjOYepZnBGEW
# DEME0jhd3XWXOwYkDvoppLkkDTHyaHOg0VXJKZmWYneJpkn4ZhS+Sko4Euu236ha
# JSuq1Lbdt7Yu0Hqja1McwoOKD2gF3uoC4S9KZEU0apIlZFY9EFd5XW6XRDd7wfD8
# S3RzRJxT5gAWBysWCHP6IsWg31sb8jmt6TlZ1ZOzHZ6dA4RXHPkWXp6CI1ef+q0R
# ubiE77JF7WGL2oVDjxEJ0KbEFB+lnGAzxByYtXN7tPACmYUhf5QkvIwMiA//Y/ij
# WSYON+Ndsc2Lsw0YJR4VzSlHfvbnJmP/QlZ1pY6G2FYC0Vagi/jr65XrwV8AigPf
# pNvh4Lkp+kxOybRaUuIQsGWoMHirty/FjjQlBizBOW0GujBcTJqHMGLYB2a8MYIa
# IDCCGhwCAQEwfTBpMQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIElu
# Yy4xQTA/BgNVBAMTOERpZ2lDZXJ0IFRydXN0ZWQgRzQgQ29kZSBTaWduaW5nIFJT
# QTQwOTYgU0hBMzg0IDIwMjEgQ0ExAhAI2uCQ/VmhAozDBeMbELERMA0GCWCGSAFl
# AwQCAQUAoHwwEAYKKwYBBAGCNwIBDDECMAAwGQYJKoZIhvcNAQkDMQwGCisGAQQB
# gjcCAQQwHAYKKwYBBAGCNwIBCzEOMAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkE
# MSIEINNna0h7cmjOk6YpKppSSVSji3WhqQD4P9INZXaecqwJMA0GCSqGSIb3DQEB
# AQUABIIBgCoQHrjHxjPpEsJlTJSDxtxpDMrCPuIPQ7xTKtnC83aY628fc089YMHE
# DmyPpdUC08Px9LafcwD1rShLGOFQBuC4xcusfgUKa5Y871XPOJ8tE88LKX/aIckb
# 7xrMBNyOUruyHUh6u9bKz0T5n3aIe8fgFsGtFIUADqRhX5s9rv9scw6WCf8DTUSg
# 4e0C7Tsm4codNdzAT2XDozDsBCeF7WXnBJKqB0TsMLrxKsPULMLXJbPvK9UjBPBQ
# 3V+sj0K1U8yhEv48Axa6xOVBrlPNi4XwuF8npHWgH6+SiwA299uU9sheN2SbnIcB
# EYmqzkSB1TO+Z/rApqjkDsHb3cJnZN2tRm1dDkt1L4xf0Uo3gDgsCWGeUlbKR+Bm
# 4K5zn9K+heJ1SlO8bCJZbzwGQu6o1U5NUjnqJV5H3gWVKUsjEzWpg/6puSSGIiCo
# 7A5/Rdtp/r1cMFdF0kb11PpZHf0vpq029hKmmIRyKqmu0Sas5T609Jfg1SR6EosC
# RWnCBlwCV6GCF3YwghdyBgorBgEEAYI3AwMBMYIXYjCCF14GCSqGSIb3DQEHAqCC
# F08wghdLAgEDMQ8wDQYJYIZIAWUDBAIBBQAwdwYLKoZIhvcNAQkQAQSgaARmMGQC
# AQEGCWCGSAGG/WwHATAxMA0GCWCGSAFlAwQCAQUABCDLiMa7dbSpycHMIlAAqpgj
# wRlVs8g+8BjWo3FGJqyHAAIQH8lspnUbvHr002k32MeosxgPMjAyNTA4MjgwODIy
# NDJaoIITOjCCBu0wggTVoAMCAQICEAqA7xhLjfEFgtHEdqeVdGgwDQYJKoZIhvcN
# AQELBQAwaTELMAkGA1UEBhMCVVMxFzAVBgNVBAoTDkRpZ2lDZXJ0LCBJbmMuMUEw
# PwYDVQQDEzhEaWdpQ2VydCBUcnVzdGVkIEc0IFRpbWVTdGFtcGluZyBSU0E0MDk2
# IFNIQTI1NiAyMDI1IENBMTAeFw0yNTA2MDQwMDAwMDBaFw0zNjA5MDMyMzU5NTla
# MGMxCzAJBgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjE7MDkGA1UE
# AxMyRGlnaUNlcnQgU0hBMjU2IFJTQTQwOTYgVGltZXN0YW1wIFJlc3BvbmRlciAy
# MDI1IDEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQDQRqwtEsae0Oqu
# YFazK1e6b1H/hnAKAd/KN8wZQjBjMqiZ3xTWcfsLwOvRxUwXcGx8AUjni6bz52fG
# Tfr6PHRNv6T7zsf1Y/E3IU8kgNkeECqVQ+3bzWYesFtkepErvUSbf+EIYLkrLKd6
# qJnuzK8Vcn0DvbDMemQFoxQ2Dsw4vEjoT1FpS54dNApZfKY61HAldytxNM89PZXU
# P/5wWWURK+IfxiOg8W9lKMqzdIo7VA1R0V3Zp3DjjANwqAf4lEkTlCDQ0/fKJLKL
# kzGBTpx6EYevvOi7XOc4zyh1uSqgr6UnbksIcFJqLbkIXIPbcNmA98Oskkkrvt6l
# PAw/p4oDSRZreiwB7x9ykrjS6GS3NR39iTTFS+ENTqW8m6THuOmHHjQNC3zbJ6nJ
# 6SXiLSvw4Smz8U07hqF+8CTXaETkVWz0dVVZw7knh1WZXOLHgDvundrAtuvz0D3T
# +dYaNcwafsVCGZKUhQPL1naFKBy1p6llN3QgshRta6Eq4B40h5avMcpi54wm0i2e
# PZD5pPIssoszQyF4//3DoK2O65Uck5Wggn8O2klETsJ7u8xEehGifgJYi+6I03Uu
# T1j7FnrqVrOzaQoVJOeeStPeldYRNMmSF3voIgMFtNGh86w3ISHNm0IaadCKCkUe
# 2LnwJKa8TIlwCUNVwppwn4D3/Pt5pwIDAQABo4IBlTCCAZEwDAYDVR0TAQH/BAIw
# ADAdBgNVHQ4EFgQU5Dv88jHt/f3X85FxYxlQQ89hjOgwHwYDVR0jBBgwFoAU729T
# SunkBnx6yuKQVvYv1Ensy04wDgYDVR0PAQH/BAQDAgeAMBYGA1UdJQEB/wQMMAoG
# CCsGAQUFBwMIMIGVBggrBgEFBQcBAQSBiDCBhTAkBggrBgEFBQcwAYYYaHR0cDov
# L29jc3AuZGlnaWNlcnQuY29tMF0GCCsGAQUFBzAChlFodHRwOi8vY2FjZXJ0cy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkRzRUaW1lU3RhbXBpbmdSU0E0MDk2
# U0hBMjU2MjAyNUNBMS5jcnQwXwYDVR0fBFgwVjBUoFKgUIZOaHR0cDovL2NybDMu
# ZGlnaWNlcnQuY29tL0RpZ2lDZXJ0VHJ1c3RlZEc0VGltZVN0YW1waW5nUlNBNDA5
# NlNIQTI1NjIwMjVDQTEuY3JsMCAGA1UdIAQZMBcwCAYGZ4EMAQQCMAsGCWCGSAGG
# /WwHATANBgkqhkiG9w0BAQsFAAOCAgEAZSqt8RwnBLmuYEHs0QhEnmNAciH45PYi
# T9s1i6UKtW+FERp8FgXRGQ/YAavXzWjZhY+hIfP2JkQ38U+wtJPBVBajYfrbIYG+
# Dui4I4PCvHpQuPqFgqp1PzC/ZRX4pvP/ciZmUnthfAEP1HShTrY+2DE5qjzvZs7J
# IIgt0GCFD9ktx0LxxtRQ7vllKluHWiKk6FxRPyUPxAAYH2Vy1lNM4kzekd8oEARz
# FAWgeW3az2xejEWLNN4eKGxDJ8WDl/FQUSntbjZ80FU3i54tpx5F/0Kr15zW/mJA
# xZMVBrTE2oi0fcI8VMbtoRAmaaslNXdCG1+lqvP4FbrQ6IwSBXkZagHLhFU9HCrG
# /syTRLLhAezu/3Lr00GrJzPQFnCEH1Y58678IgmfORBPC1JKkYaEt2OdDh4GmO0/
# 5cHelAK2/gTlQJINqDr6JfwyYHXSd+V08X1JUPvB4ILfJdmL+66Gp3CSBXG6IwXM
# ZUXBhtCyIaehr0XkBoDIGMUG1dUtwq1qmcwbdUfcSYCn+OwncVUXf53VJUNOaMWM
# ts0VlRYxe5nK+At+DI96HAlXHAL5SlfYxJ7La54i71McVWRP66bW+yERNpbJCjyC
# YG2j+bdpxo/1Cy4uPcU3AWVPGrbn5PhDBf3Froguzzhk++ami+r3Qrx5bIbY3TVz
# giFI7Gq3zWcwgga0MIIEnKADAgECAhANx6xXBf8hmS5AQyIMOkmGMA0GCSqGSIb3
# DQEBCwUAMGIxCzAJBgNVBAYTAlVTMRUwEwYDVQQKEwxEaWdpQ2VydCBJbmMxGTAX
# BgNVBAsTEHd3dy5kaWdpY2VydC5jb20xITAfBgNVBAMTGERpZ2lDZXJ0IFRydXN0
# ZWQgUm9vdCBHNDAeFw0yNTA1MDcwMDAwMDBaFw0zODAxMTQyMzU5NTlaMGkxCzAJ
# BgNVBAYTAlVTMRcwFQYDVQQKEw5EaWdpQ2VydCwgSW5jLjFBMD8GA1UEAxM4RGln
# aUNlcnQgVHJ1c3RlZCBHNCBUaW1lU3RhbXBpbmcgUlNBNDA5NiBTSEEyNTYgMjAy
# NSBDQTEwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC0eDHTCphBcr48
# RsAcrHXbo0ZodLRRF51NrY0NlLWZloMsVO1DahGPNRcybEKq+RuwOnPhof6pvF4u
# GjwjqNjfEvUi6wuim5bap+0lgloM2zX4kftn5B1IpYzTqpyFQ/4Bt0mAxAHeHYNn
# QxqXmRinvuNgxVBdJkf77S2uPoCj7GH8BLuxBG5AvftBdsOECS1UkxBvMgEdgkFi
# DNYiOTx4OtiFcMSkqTtF2hfQz3zQSku2Ws3IfDReb6e3mmdglTcaarps0wjUjsZv
# kgFkriK9tUKJm/s80FiocSk1VYLZlDwFt+cVFBURJg6zMUjZa/zbCclF83bRVFLe
# GkuAhHiGPMvSGmhgaTzVyhYn4p0+8y9oHRaQT/aofEnS5xLrfxnGpTXiUOeSLsJy
# goLPp66bkDX1ZlAeSpQl92QOMeRxykvq6gbylsXQskBBBnGy3tW/AMOMCZIVNSaz
# 7BX8VtYGqLt9MmeOreGPRdtBx3yGOP+rx3rKWDEJlIqLXvJWnY0v5ydPpOjL6s36
# czwzsucuoKs7Yk/ehb//Wx+5kMqIMRvUBDx6z1ev+7psNOdgJMoiwOrUG2ZdSoQb
# U2rMkpLiQ6bGRinZbI4OLu9BMIFm1UUl9VnePs6BaaeEWvjJSjNm2qA+sdFUeEY0
# qVjPKOWug/G6X5uAiynM7Bu2ayBjUwIDAQABo4IBXTCCAVkwEgYDVR0TAQH/BAgw
# BgEB/wIBADAdBgNVHQ4EFgQU729TSunkBnx6yuKQVvYv1Ensy04wHwYDVR0jBBgw
# FoAU7NfjgtJxXWRM3y5nP+e6mK4cD08wDgYDVR0PAQH/BAQDAgGGMBMGA1UdJQQM
# MAoGCCsGAQUFBwMIMHcGCCsGAQUFBwEBBGswaTAkBggrBgEFBQcwAYYYaHR0cDov
# L29jc3AuZGlnaWNlcnQuY29tMEEGCCsGAQUFBzAChjVodHRwOi8vY2FjZXJ0cy5k
# aWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVkUm9vdEc0LmNydDBDBgNVHR8EPDA6
# MDigNqA0hjJodHRwOi8vY3JsMy5kaWdpY2VydC5jb20vRGlnaUNlcnRUcnVzdGVk
# Um9vdEc0LmNybDAgBgNVHSAEGTAXMAgGBmeBDAEEAjALBglghkgBhv1sBwEwDQYJ
# KoZIhvcNAQELBQADggIBABfO+xaAHP4HPRF2cTC9vgvItTSmf83Qh8WIGjB/T8Ob
# XAZz8OjuhUxjaaFdleMM0lBryPTQM2qEJPe36zwbSI/mS83afsl3YTj+IQhQE7jU
# /kXjjytJgnn0hvrV6hqWGd3rLAUt6vJy9lMDPjTLxLgXf9r5nWMQwr8Myb9rEVKC
# hHyfpzee5kH0F8HABBgr0UdqirZ7bowe9Vj2AIMD8liyrukZ2iA/wdG2th9y1IsA
# 0QF8dTXqvcnTmpfeQh35k5zOCPmSNq1UH410ANVko43+Cdmu4y81hjajV/gxdEkM
# x1NKU4uHQcKfZxAvBAKqMVuqte69M9J6A47OvgRaPs+2ykgcGV00TYr2Lr3ty9qI
# ijanrUR3anzEwlvzZiiyfTPjLbnFRsjsYg39OlV8cipDoq7+qNNjqFzeGxcytL5T
# TLL4ZaoBdqbhOhZ3ZRDUphPvSRmMThi0vw9vODRzW6AxnJll38F0cuJG7uEBYTpt
# MSbhdhGQDpOXgpIUsWTjd6xpR6oaQf/DJbg3s6KCLPAlZ66RzIg9sC+NJpud/v4+
# 7RWsWCiKi9EOLLHfMR2ZyJ/+xhCx9yHbxtl5TPau1j/1MIDpMPx0LckTetiSuEtQ
# vLsNz3Qbp7wGWqbIiOWCnb5WqxL3/BAPvIXKUjPSxyZsq8WhbaM2tszWkPZPubdc
# MIIFjTCCBHWgAwIBAgIQDpsYjvnQLefv21DiCEAYWjANBgkqhkiG9w0BAQwFADBl
# MQswCQYDVQQGEwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3
# d3cuZGlnaWNlcnQuY29tMSQwIgYDVQQDExtEaWdpQ2VydCBBc3N1cmVkIElEIFJv
# b3QgQ0EwHhcNMjIwODAxMDAwMDAwWhcNMzExMTA5MjM1OTU5WjBiMQswCQYDVQQG
# EwJVUzEVMBMGA1UEChMMRGlnaUNlcnQgSW5jMRkwFwYDVQQLExB3d3cuZGlnaWNl
# cnQuY29tMSEwHwYDVQQDExhEaWdpQ2VydCBUcnVzdGVkIFJvb3QgRzQwggIiMA0G
# CSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC/5pBzaN675F1KPDAiMGkz7MKnJS7J
# IT3yithZwuEppz1Yq3aaza57G4QNxDAf8xukOBbrVsaXbR2rsnnyyhHS5F/WBTxS
# D1Ifxp4VpX6+n6lXFllVcq9ok3DCsrp1mWpzMpTREEQQLt+C8weE5nQ7bXHiLQwb
# 7iDVySAdYyktzuxeTsiT+CFhmzTrBcZe7FsavOvJz82sNEBfsXpm7nfISKhmV1ef
# VFiODCu3T6cw2Vbuyntd463JT17lNecxy9qTXtyOj4DatpGYQJB5w3jHtrHEtWoY
# OAMQjdjUN6QuBX2I9YI+EJFwq1WCQTLX2wRzKm6RAXwhTNS8rhsDdV14Ztk6MUSa
# M0C/CNdaSaTC5qmgZ92kJ7yhTzm1EVgX9yRcRo9k98FpiHaYdj1ZXUJ2h4mXaXpI
# 8OCiEhtmmnTK3kse5w5jrubU75KSOp493ADkRSWJtppEGSt+wJS00mFt6zPZxd9L
# BADMfRyVw4/3IbKyEbe7f/LVjHAsQWCqsWMYRJUadmJ+9oCw++hkpjPRiQfhvbfm
# Q6QYuKZ3AeEPlAwhHbJUKSWJbOUOUlFHdL4mrLZBdd56rF+NP8m800ERElvlEFDr
# McXKchYiCd98THU/Y+whX8QgUWtvsauGi0/C1kVfnSD8oR7FwI+isX4KJpn15Gkv
# mB0t9dmpsh3lGwIDAQABo4IBOjCCATYwDwYDVR0TAQH/BAUwAwEB/zAdBgNVHQ4E
# FgQU7NfjgtJxXWRM3y5nP+e6mK4cD08wHwYDVR0jBBgwFoAUReuir/SSy4IxLVGL
# p6chnfNtyA8wDgYDVR0PAQH/BAQDAgGGMHkGCCsGAQUFBwEBBG0wazAkBggrBgEF
# BQcwAYYYaHR0cDovL29jc3AuZGlnaWNlcnQuY29tMEMGCCsGAQUFBzAChjdodHRw
# Oi8vY2FjZXJ0cy5kaWdpY2VydC5jb20vRGlnaUNlcnRBc3N1cmVkSURSb290Q0Eu
# Y3J0MEUGA1UdHwQ+MDwwOqA4oDaGNGh0dHA6Ly9jcmwzLmRpZ2ljZXJ0LmNvbS9E
# aWdpQ2VydEFzc3VyZWRJRFJvb3RDQS5jcmwwEQYDVR0gBAowCDAGBgRVHSAAMA0G
# CSqGSIb3DQEBDAUAA4IBAQBwoL9DXFXnOF+go3QbPbYW1/e/Vwe9mqyhhyzshV6p
# Grsi+IcaaVQi7aSId229GhT0E0p6Ly23OO/0/4C5+KH38nLeJLxSA8hO0Cre+i1W
# z/n096wwepqLsl7Uz9FDRJtDIeuWcqFItJnLnU+nBgMTdydE1Od/6Fmo8L8vC6bp
# 8jQ87PcDx4eo0kxAGTVGamlUsLihVo7spNU96LHc/RzY9HdaXFSMb++hUD38dglo
# hJ9vytsgjTVgHAIDyyCwrFigDkBjxZgiwbJZ9VVrzyerbHbObyMt9H5xaiNrIv8S
# uFQtJ37YOtnwtoeW/VvRXKwYw02fc7cBqZ9Xql4o4rmUMYIDfDCCA3gCAQEwfTBp
# MQswCQYDVQQGEwJVUzEXMBUGA1UEChMORGlnaUNlcnQsIEluYy4xQTA/BgNVBAMT
# OERpZ2lDZXJ0IFRydXN0ZWQgRzQgVGltZVN0YW1waW5nIFJTQTQwOTYgU0hBMjU2
# IDIwMjUgQ0ExAhAKgO8YS43xBYLRxHanlXRoMA0GCWCGSAFlAwQCAQUAoIHRMBoG
# CSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAcBgkqhkiG9w0BCQUxDxcNMjUwODI4
# MDgyMjQyWjArBgsqhkiG9w0BCRACDDEcMBowGDAWBBTdYjCshgotMGvaOLFoeVIw
# B/tBfjAvBgkqhkiG9w0BCQQxIgQg0EnYCi+hYi4viS/W1a8e4LsHcozaxKzuhcnq
# rSvOA50wNwYLKoZIhvcNAQkQAi8xKDAmMCQwIgQgSqA/oizXXITFXJOPgo5na5yu
# yrM/420mmqM08UYRCjMwDQYJKoZIhvcNAQEBBQAEggIACkATOEBnNntkjE31HIru
# ICNmUSWx3BtaLY4R1id2yS0VDTdVSxLxVVrjHZ9iFXNMnk25XrtFQ520CSL9HN2A
# YoJ07/kjEZKt7lMzaxR5aExC+eDGuo4Pea1mCCb0i49B+0vSr7fa1XmOaqUO6GCb
# CVo5C04yh26QkK/GbhYtu9KU9Cz+fPWcC4z0NcBpDZno2UEyfZNCV1N20HElJiWq
# PTGCteLyAGjIvyKI6LYcHruwdHIhdCil/4WyXswrL/82OMSx/IKa5L3Z2CGdH0V9
# lnxWrDSGi4Yrid6HTyJZNQJs7tWYJ9usIfz6Sy8PWh5wTBCInWp5M5KBHNM9tljr
# jkQgHSrMZ4H56san6HbyVpCIeKQef1Ba/aa0jPa0intk8ex9aoagx0AIIEhXvi7h
# l5k9BreH/vBnc+iIyzlr/32Xy6Pf3L6lp/jb/xDEhdzxj9stns+5VyzxxvHwl5cb
# Kmy2fWzhGVBXH5UyS2GCvgGuA9ba2RViLGoglK/GRnz5eqKCcu0e2NJzjY+iDHvK
# XkMiBz3yI+sxkB5FHoIoay+mjgUEGm/PINdGY1DLi5gGxMFdTfErsLyl6jhSEclb
# UGMnDd+CZ56EzmsIrAj+cG7btOyMtIrwdzqqSfKTcCDRTYA7TVTPJOjsMxq+2O2J
# b3PQ6cozSdj8xD/mshDn0Js=
# SIG # End signature block
