<#
.SYNOPSIS
  Upload the newest producer output file to SharePoint Online, log the transaction, then delete the file.

.DESCRIPTION
  - Non-interactive / scheduled-task friendly
  - Hardcoded configuration (no runtime parameters)
  - Dev/Prod toggle only:
      Dev  -> Client Secret auth (hardcoded)
      Prod -> Local Certificate auth (LocalMachine\My)
  - Finds newest file matching: <Prefix>*.<Extension>
  - Uploads to: SiteUrl -> DocumentLibraryName -> TargetFolderPath
  - Writes a local log file
  - Deletes the uploaded local file ONLY after successful upload

.PREREQS
  - Microsoft.Graph PowerShell module installed
  - App registration has Graph Application permission: Sites.Selected (admin consent)
  - App is granted site-level Write access for the target SPO site (RSC)

.NOTES
  Site grant example:
    Set-SPOSite -Identity "https://tenant.sharepoint.com/sites/YourSite" `
                -AppId "<AppId>" `
                -DisplayName "Teams Historical Uploader" `
                -Permissions Write
#>

# =========================
# 0) HARD SWITCH (ONLY)
# =========================
$Environment = 'Dev'   # 'Dev' or 'Prod'

# =========================
# 1) HARD-CODED CONFIG
# =========================

# --- Producer output location + pattern ---
$SourceFolderPath = "C:\ScheduledTasks\teamsHistoricalRunner\local-output\NEE\teamsHistoricalSource"
$FilePrefix       = "6733b8f2ab3b1dc8e08d4113-teamsHistoricalSource"
$FileExtension    = "jsonl"

# --- SPO target ---
$SiteUrl             = "https://neeqa.sharepoint.com/sites/QATestBench"
$DocumentLibraryName = "Documents"
$TargetFolderPath    = "Teams Historical Runner"   # "" => library root

# --- App-only auth settings (Sites.Selected app) ---
$TenantId = $null
$ClientId = $null

# Dev auth: hardcoded secret (DEV ONLY)
$DevClientSecretPlain = $null  # Set ONLY if Environment='Dev'

# Prod auth: certificate thumbprint in LocalMachine\My
$ProdCertThumbprint = $null  # Must exist in Cert:\LocalMachine\My

# --- Logging output (server-friendly; no Desktop assumptions) ---
$LogRoot = "C:\ScheduledTasks\teamsHistoricalUploader\logs"

# Optional: suppress Az survey noise if Az modules exist on the system (harmless)
$env:AzSurveyEnabled = 'false'

# =========================
# 2) HELPERS
# =========================

$script:LogFile = $null
$script:TranscriptFile = $null

function Initialize-Logging {
    # Primary log location
    $primaryRoot = $LogRoot
    $fallbackRoot = Join-Path $env:TEMP "NEE_TeamsHistoricalUploader\Logs"

    $ts = (Get-Date).ToString("yyyyMMdd_HHmmss")

    # Try primary path first
    try {
        if (-not (Test-Path -Path $primaryRoot -PathType Container)) {
            New-Item -Path $primaryRoot -ItemType Directory -Force | Out-Null
        }
        $script:LogFile = Join-Path $primaryRoot "TeamsHistoricalUploader_$ts.log"
    }
    catch {
        # Fall back if ProgramData path is blocked
        if (-not (Test-Path -Path $fallbackRoot -PathType Container)) {
            New-Item -Path $fallbackRoot -ItemType Directory -Force | Out-Null
        }
        $script:LogFile = Join-Path $fallbackRoot "TeamsHistoricalUploader_$ts.log"
    }

    # Transcript file (same folder as log)
    $script:TranscriptFile = [System.IO.Path]::ChangeExtension($script:LogFile, ".transcript.txt")

    # Start transcript (captures all output/errors that might not go through Write-Log)
    try {
        Start-Transcript -Path $script:TranscriptFile -Append -ErrorAction Stop | Out-Null
    }
    catch {
        # Transcript failure shouldn't kill the job; log it later via Write-Log if possible
    }
}

function Write-Log {
    param(
        [Parameter(Mandatory)][string]$Message,
        [ValidateSet('INFO','WARN','ERROR')][string]$Level = 'INFO'
    )

    $ts = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
    $line = "[$ts][$Level] $Message"

    # If logging wasn't initialized yet, attempt emergency init in TEMP
    if ([string]::IsNullOrWhiteSpace($script:LogFile)) {
        $emergencyRoot = Join-Path $env:TEMP "NEE_TeamsHistoricalUploader\Logs"
        if (-not (Test-Path $emergencyRoot)) { New-Item -Path $emergencyRoot -ItemType Directory -Force | Out-Null }
        $script:LogFile = Join-Path $emergencyRoot "TeamsHistoricalUploader_EMERGENCY.log"
    }

    # Write to log; if it fails, fall back to TEMP emergency log
    try {
        Add-Content -Path $script:LogFile -Value $line -Encoding UTF8
    }
    catch {
        $emergencyRoot = Join-Path $env:TEMP "NEE_TeamsHistoricalUploader\Logs"
        if (-not (Test-Path $emergencyRoot)) { New-Item -Path $emergencyRoot -ItemType Directory -Force | Out-Null }
        $emergencyFile = Join-Path $emergencyRoot "TeamsHistoricalUploader_EMERGENCY.log"
        Add-Content -Path $emergencyFile -Value $line -Encoding UTF8
    }
}

function Ensure-Modules {
    if (-not (Get-Module -ListAvailable -Name "Microsoft.Graph.Authentication")) {
        throw "Missing module: Microsoft.Graph. Install with: Install-Module Microsoft.Graph -Scope AllUsers"
    }
}

function Connect-ToGraphAppOnly {
    Write-Log "Connecting to Microsoft Graph (App-Only). Environment=$Environment" "INFO"
    try { Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null } catch {}

    if ($Environment -eq 'Dev') {
        if ([string]::IsNullOrWhiteSpace($DevClientSecretPlain)) {
            throw "DevClientSecretPlain is not set. Configure it for Dev testing, or set Environment='Prod'."
        }

        $sec  = ConvertTo-SecureString -String $DevClientSecretPlain -AsPlainText -Force
        $cred = [System.Management.Automation.PSCredential]::new($ClientId, $sec)

        Connect-MgGraph -TenantId $TenantId -ClientSecretCredential $cred -NoWelcome -ErrorAction Stop | Out-Null
        Write-Log "Connected to Graph using CLIENT SECRET (Dev)." "INFO"
        return
    }

    # Prod: local certificate in LocalMachine\My
    if ([string]::IsNullOrWhiteSpace($ProdCertThumbprint)) {
        throw "ProdCertThumbprint is not set."
    }

    $certPath = "Cert:\LocalMachine\My\$ProdCertThumbprint"
    $cert = Get-Item -Path $certPath -ErrorAction Stop

    if (-not $cert.HasPrivateKey) {
        throw "Certificate '$ProdCertThumbprint' was found but has no private key. App-only auth requires a private key."
    }

    Connect-MgGraph -TenantId $TenantId -ClientId $ClientId -Certificate $cert -NoWelcome -ErrorAction Stop | Out-Null
    Write-Log "Connected to Graph using LOCAL CERTIFICATE (Prod). Thumbprint=$ProdCertThumbprint" "INFO"
}

function Parse-SiteUrl {
    param([Parameter(Mandatory)][string]$Url)
    try { $u = [System.Uri]::new($Url) } catch { throw "Invalid SiteUrl: '$Url'" }

    $spHost = $u.Host
    $path = $u.AbsolutePath.TrimEnd('/')

    if ([string]::IsNullOrWhiteSpace($spHost) -or [string]::IsNullOrWhiteSpace($path)) {
        throw "Could not parse host/path from SiteUrl: '$Url'"
    }

    [pscustomobject]@{ Hostname = $spHost; Path = $path }
}

function Resolve-GraphSite {
    param(
        [Parameter(Mandatory)][string]$Hostname,
        [Parameter(Mandatory)][string]$Path
    )
    # Correct Graph format: /sites/{hostname}:/{server-relative-path}
    $uri = "https://graph.microsoft.com/v1.0/sites/${Hostname}:$Path"
    Write-Log "Resolving SPO site via Graph: $uri" "INFO"

    try {
        Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop
    }
    catch {
        throw "Failed to resolve SPO site. Verify Sites.Selected site grant + SiteUrl. Error: $($_.Exception.Message)"
    }
}

function Resolve-DriveId {
    param(
        [Parameter(Mandatory)][string]$SiteId,
        [Parameter(Mandatory)][string]$DriveName
    )

    $uri = "https://graph.microsoft.com/v1.0/sites/$SiteId/drives"
    Write-Log "Listing drives: $uri" "INFO"

    $drives = (Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop).value
    if (-not $drives) { throw "No drives returned for SiteId=$SiteId" }

    $drive = $drives | Where-Object { $_.name -eq $DriveName } | Select-Object -First 1
    if (-not $drive) {
        $avail = ($drives | Select-Object -ExpandProperty name) -join ", "
        throw "Drive '$DriveName' not found. Available: $avail"
    }

    Write-Log "Resolved library '$DriveName' -> DriveId=$($drive.id)" "INFO"
    $drive.id
}

function Get-LatestFile {
    param(
        [Parameter(Mandatory)][string]$FolderPath,
        [Parameter(Mandatory)][string]$Prefix,
        [Parameter(Mandatory)][string]$Extension
    )

    if (-not (Test-Path -Path $FolderPath -PathType Container)) {
        throw "Source folder not found: '$FolderPath'"
    }

    $pattern = "$Prefix*.$Extension"
    Write-Log "Searching for newest file: Folder='$FolderPath' Pattern='$pattern'" "INFO"

    $files = Get-ChildItem -Path $FolderPath -File -Filter $pattern -ErrorAction Stop
    if (-not $files -or $files.Count -eq 0) { return $null }

    $files | Sort-Object -Property LastWriteTimeUtc -Descending | Select-Object -First 1
}

function Upload-FileToDrive {
    param(
        [Parameter(Mandatory)][string]$DriveId,
        [Parameter(Mandatory)][string]$TargetFolder,
        [Parameter(Mandatory)][string]$LocalFilePath
    )

    if (-not (Test-Path -Path $LocalFilePath -PathType Leaf)) {
        throw "Local file does not exist: '$LocalFilePath'"
    }

    $fileName = Split-Path -Path $LocalFilePath -Leaf
    $folder   = ($TargetFolder ?? "").Trim("/")
    $remotePath = if ($folder) { "$folder/$fileName" } else { $fileName }

    $uri = "https://graph.microsoft.com/v1.0/drives/$DriveId/root:/${remotePath}:/content"
    Write-Log "Uploading via Graph PUT: $uri" "INFO"

    $bytes = [System.IO.File]::ReadAllBytes($LocalFilePath)

    try {
        Invoke-MgGraphRequest -Method PUT -Uri $uri -Body $bytes -ContentType "application/octet-stream" -ErrorAction Stop
    }
    catch {
        throw "Upload failed. Error: $($_.Exception.Message)"
    }
}

# =========================
# MAIN
# =========================

# Make failures fail fast and predictable
$ErrorActionPreference = 'Stop'

try {
    Initialize-Logging

    Write-Log "=== START TeamsHistoricalUploader ===" "INFO"
    Write-Log "Environment=$Environment" "INFO"
    Write-Log "SourceFolderPath=$SourceFolderPath | Prefix=$FilePrefix | Extension=$FileExtension" "INFO"
    Write-Log "Target SiteUrl=$SiteUrl | Library=$DocumentLibraryName | Folder='$TargetFolderPath'" "INFO"
    Write-Log "LogFile=$script:LogFile" "INFO"
    if ($script:TranscriptFile) { Write-Log "TranscriptFile=$script:TranscriptFile" "INFO" }

    Ensure-Modules
    Write-Log "Modules verified." "INFO"

    Connect-ToGraphAppOnly
    Write-Log "Graph connection established." "INFO"

    # Resolve site + drive
    $parsed = Parse-SiteUrl -Url $SiteUrl
    Write-Log "Parsed SiteUrl: Hostname=$($parsed.Hostname) Path=$($parsed.Path)" "INFO"

    $site = Resolve-GraphSite -Hostname $parsed.Hostname -Path $parsed.Path
    if (-not $site -or -not $site.id) { throw "Site resolution returned no site id." }

    Write-Log "Resolved site: Name='$($site.displayName)' Id='$($site.id)'" "INFO"

    $driveId = Resolve-DriveId -SiteId $site.id -DriveName $DocumentLibraryName
    Write-Log "Resolved DriveId=$driveId" "INFO"

    # Find newest file
    $latest = Get-LatestFile -FolderPath $SourceFolderPath -Prefix $FilePrefix -Extension $FileExtension
    if (-not $latest) {
        Write-Log "No matching files found. Nothing to upload." "WARN"
        Write-Log "=== END (no-op) ===" "INFO"
        exit 0
    }

    Write-Log "Latest file selected: '$($latest.FullName)' (LastWriteTimeUtc=$($latest.LastWriteTimeUtc))" "INFO"

    # Upload
    $result = Upload-FileToDrive -DriveId $driveId -TargetFolder $TargetFolderPath -LocalFilePath $latest.FullName
    Write-Log "Upload succeeded. DriveItemId=$($result.id)" "INFO"
    if ($result.webUrl) { Write-Log "SPO Item Url=$($result.webUrl)" "INFO" }

    # Delete local file AFTER successful upload
    Remove-Item -Path $latest.FullName -Force -ErrorAction Stop
    Write-Log "Deleted local file after upload: '$($latest.FullName)'" "INFO"

    Write-Log "=== END (success) ===" "INFO"
    exit 0
}
catch {
    Write-Log "FAILURE: $($_.Exception.Message)" "ERROR"
    Write-Log "=== END (failed) ===" "ERROR"
    exit 1
}
finally {
    try {
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        Write-Log "Disconnected from Graph." "INFO"
    } catch {}

    try {
        if ($script:TranscriptFile) {
            Stop-Transcript | Out-Null
            Write-Log "Transcript stopped." "INFO"
        }
    } catch {}
}
