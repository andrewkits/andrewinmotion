# CHANGELOG – App SP Archive and Upload (SPO)

All notable changes to this script will be documented in this file.

## [1.0.0] – 2025-11-28

### Added
- Initial implementation of `App-SP-Archive-And-Upload.ps1`.
- Standardized script environment using PSScriptData layout:
  - `Input\`, `Output\`, and `Logs\` subfolders.
- Centralized logging via `Write-Log` with timestamped log files.
- Non-interactive, app-only execution model driven by configuration:
  - `LocalFolderPath`
  - `SiteUrl`
  - `DocumentLibraryName`
  - `TargetFolderPath`
  - `IncludeRootFolder`
- App configuration via `$AppConfigs` for:
  - `MainTask` (Graph workload app)
  - `KeyVaultAccess` (Key Vault reader app)
- Authentication helper pipeline:
  - `Get-AppAuthCredential`
  - Secret-based auth via `Get-AppSecretCredentialCore`
  - Certificate-based auth via `Get-AppCertificateCredentialCore`
  - Dev secret helper `Get-DevClientSecret` (Dev only).
- Key Vault access helper:
  - `Ensure-KeyVaultAzContext` for establishing Az context with `KeyVaultAccess` SP.
- Graph connection helper:
  - `Connect-ToGraph` (app-only mode) with `Microsoft.Graph` context management.
- SPO / Graph helpers:
  - `Parse-SiteUrl` – parse SharePoint site URL into hostname/path.
  - `Get-GraphSiteByUrl` – resolve site via `GET /sites/{hostname}:/{path}`.
  - `Get-GraphSiteDrives` – list document libraries via `GET /sites/{site-id}/drives`.
  - `Get-GraphDriveByName` – resolve document library (drive) by display name.
- ZIP creation helper:
  - `New-ZipFromFolder` – create ZIP archive from a folder, optionally including the root folder.
- Upload helper:
  - `Upload-FileToDrive` – upload ZIP file to SPO via `PUT /drives/{drive-id}/root:/path/file.zip:/content`.
- Robust error handling and exit behavior:
  - On failure, logs error, sets `$global:LASTEXITCODE = 1`, and exits with code 1.
  - On success, exits with code 0.

### Notes
- This version has been validated to:
  - Successfully compress a configured local folder to a ZIP archive.
  - Resolve an SPO site by URL using Microsoft Graph with `Sites.Selected` permissions.
  - Resolve a target document library by name.
  - Upload the generated ZIP into the specified library/folder path.
