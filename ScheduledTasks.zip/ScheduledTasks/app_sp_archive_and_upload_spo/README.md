# App SP Archive and Upload (SharePoint Online)

## Overview

`App-SP-Archive-And-Upload.ps1` is a non-interactive PowerShell script that:

- Compresses a configured local folder into a ZIP archive.
- Uses an Azure AD / Entra ID application (service principal) to authenticate to Microsoft Graph using **app-only** permissions.
- Uploads the ZIP file into a specific document library and folder on a SharePoint Online (SPO) site.
- Is designed to work with **Sites.Selected** permissions and per-site grants (RSC model).

This script is intended to run programmatically (Task Scheduler, Azure Automation, DevOps pipeline, etc.) and **does not prompt for input**. All operational values are defined in a script-level configuration region.

---

## Key Features

- Standardized script environment and logging (PSScriptData-based layout).
- App-only authentication using a dedicated **MainTask** service principal.
- Support for secret-based or certificate-based authentication (configurable).
- Production-safe dev secret handling (disabled when `Environment = 'Prod'`).
- Automatic ZIP naming and output folder management.
- Graph-based SPO operations that are compatible with **Sites.Selected**:
  - Resolve site by URL via `GET /sites/{hostname}:/{site-path}`
  - Enumerate drives via `GET /sites/{site-id}/drives`
  - Upload ZIP via `PUT /drives/{drive-id}/root:/path/file.zip:/content`
- Clean exit codes for automation tooling:
  - `0` on success
  - `1` on failure (without dumping an ugly stack trace to console)

---

## Prerequisites

### PowerShell

- Windows PowerShell 5.1 or PowerShell 7.x

### Modules

The following modules must be installed and available on the host where the script runs:

- `Microsoft.Graph.Authentication`
- `Microsoft.Graph` (for `Invoke-MgGraphRequest` and `Get-MgContext`)
- `Az.Accounts`
- `Az.KeyVault`

Example install (run in an elevated PowerShell session):

```powershell
Install-Module Microsoft.Graph -Scope AllUsers
Install-Module Az.Accounts -Scope AllUsers
Install-Module Az.KeyVault -Scope AllUsers
```

### Azure AD / Entra ID Application (Service Principal)

You need at least one app registration configured as follows:

1. **MainTask service principal**
   - Used to call Microsoft Graph and perform the archive upload.
   - Must have the **Application** permission:
     - `Sites.Selected`
   - Must be granted consent by an admin.
   - Must have site-level permissions granted via RSC (see below).

2. **KeyVaultAccess service principal**
   - Used to authenticate into Azure when reading certificate or secret material from Key Vault.
   - Uses **certificate-based** auth, resolved from the local certificate store.
   - Must have access to the Key Vault(s) that hold certificate/secret data for `MainTask`.

### SharePoint Online – Sites.Selected Grant

The `Sites.Selected` permission by itself does **not** grant access to any site. You must explicitly grant the app access to each SharePoint site you want it to see.

Example:
```powershell
# Example only: adjust URL, AppId, DisplayName, and Permissions as required
Set-SPOSite -Identity "https://contoso.sharepoint.com/sites/YourSite" `
            -AppId "<MainTask-App-Id>" `
            -DisplayName "App SP Archive Uploader" `
            -Permissions Write
```

The script will only be able to resolve and upload to sites where the `MainTask` application has been given at least **Write** permissions.

---

## Script Environment & Logging

### Folder Layout

On first run, the script creates a standard per-script folder structure under your Desktop:

```text
%USERPROFILE%\Desktop\PSScriptData\App-SP-Archive-And-Upload\
  ├─ Input\
  ├─ Output\
  └─ Logs\
```

> You can override the base folder location by passing `-BaseFolder` when calling the script.

### Log Files

Each run creates a log file under `Logs\`:

```text
ScriptLog_App-SP-Archive-And-Upload_YYYYMMDD_HHMMSS.txt
```

Logging is handled by the `Write-Log` helper and includes:

- Timestamp
- Log level (`INFO`, `WARN`, `ERROR`, `DEBUG`)
- Message text

By default, logs go to file only. You can also mirror them to the console by using the `-VerboseLogsToConsole` switch.

### ZIP Output

ZIP archives are written to the `Output\` folder using this pattern:

```text
<FolderName>_<Timestamp>.zip
```

Where:

- `<FolderName>` is the leaf name of the configured `LocalFolderPath`.
- `<Timestamp>` is the same `YYYYMMDD_HHMMSS` used for the log file.

---

## Script Configuration

Operational configuration is defined directly in the **Script Configuration (hardcoded)** region.

### Core Configuration Variables

Within the script you will see:

```powershell
# Local folder to zip (must exist and be a folder)
$LocalFolderPath = "C:\Path\To\SourceFolder"

# SharePoint site URL where the archive will be uploaded
$SiteUrl = "https://tenant.sharepoint.com/sites/YourSite"

# Document library (drive) display name on that site (e.g. "Documents")
$DocumentLibraryName = "Documents"

# Folder path under the library where the zip will be stored.
# Example: "Backups/Configs". Use "" to upload to the root of the library.
$TargetFolderPath = "Backups/Configs"

# If $true, the root folder itself is zipped; if $false, only its contents.
$IncludeRootFolder = $true
```

You **must** update these to reflect your environment:

- `LocalFolderPath` – absolute path to the folder on disk whose contents you want zipped.
- `SiteUrl` – full SPO site URL (must be a site where the `MainTask` app has Sites.Selected Write access).
- `DocumentLibraryName` – display name of the document library (usually `"Documents"` for the default library).
- `TargetFolderPath` – relative library folder path where the ZIP should be created. Use `""` to place the file at the root of the library.
- `IncludeRootFolder` – determines whether the ZIP contains the folder itself (true) or only its contents (false).

### Core Parameters

These are script parameters that you can override when running the script, but they all have sensible defaults:

```powershell
[ValidateSet('Auto','HardCoded','KeyVault')]
[string]$AuthMode = 'Auto',

[ValidateSet('Auto','Secret','Certificate')]
[string]$AuthTypeDefault = 'Auto',

[ValidateSet('Dev','Prod')]
[string]$Environment = 'Prod',

[ValidateSet('AppOnly')]
[string]$GraphAuthMode = 'AppOnly',

[string]$ScriptNameOverride,
[string]$BaseFolder,
[switch]$VerboseLogsToConsole
```

- **AuthMode**
  - `Auto` – prefer Key Vault if configured, fall back to dev hard-coded secret (Dev only).
  - `HardCoded` – force use of hard-coded dev secrets via `Get-DevClientSecret`.
  - `KeyVault` – force use of Key Vault for secret retrieval.
- **AuthTypeDefault**
  - `Auto` – use per-app `DefaultAuthType` if set, otherwise fall back to `Secret`.
  - `Secret` – always use secret-based auth for apps configured with secrets.
  - `Certificate` – always use certificate-based auth for apps configured with certificates.
- **Environment**
  - `Dev` – enables hard-coded dev secrets.
  - `Prod` – hard-coded dev secrets are disabled; Key Vault / certificate-based auth only.
- **GraphAuthMode**
  - For this script, only `AppOnly` is allowed and enforced.
- **ScriptNameOverride**
  - Optional friendly name used for the PSScriptData subfolder & log names.
- **BaseFolder**
  - Optional override for the root of the PSScriptData-like structure.
- **VerboseLogsToConsole**
  - When set, all `Write-Log` messages are mirrored to the console as well as the log file.

---

## Authentication Model

The script uses a central `$AppConfigs` structure which defines settings for:

- `MainTask` – the service principal that calls Microsoft Graph to:
  - Resolve the target SPO site.
  - Resolve document libraries (drives).
  - Upload the ZIP archive.
- `KeyVaultAccess` – the service principal used to log into Azure when retrieving secrets or certificate material from Key Vault.

### MainTask Configuration

In the `$AppConfigs.MainTask` object you configure:

- `TenantId` – tenant where the app is registered.
- `ClientId` – app registration ID.
- `DefaultAuthType` – `'Secret'` or `'Certificate'`.
- `Secret.*` – Key Vault secret settings (if you use secret-based auth).
- `Certificate.*` – certificate settings (local store and/or Key Vault certificate).

### KeyVaultAccess Configuration

- Uses the local certificate store only (thumbprint-based).
- Used solely for establishing an `Az` context to talk to Key Vault.
- Configured in `$AppConfigs.KeyVaultAccess` with its own TenantId, ClientId, and certificate thumbprint.

### Dev Secrets Policy

The `Get-DevClientSecret` helper allows you to inject **hard-coded dev secrets** for testing:

- Only available when `Environment = 'Dev'`.
- Throws an error if called while `Environment = 'Prod'`.
- Intended strictly for local development and should **never** be used for production.

For details, see the comments in `Get-DevClientSecret` inside the script.

---

## How It Works (High-Level Flow)

1. **Initialize Script Environment**
   - Sets up the PSScriptData folder structure.
   - Creates a timestamped log file and exposes `baseFolder`, `outputPath`, etc.

2. **Connect to Microsoft Graph (App-Only)**
   - Calls `Connect-ToGraph` with `AuthMode = 'AppOnly'` and `App = 'MainTask'`.
   - Internally uses `Get-AppAuthCredential` to obtain secret or certificate credentials.

3. **Validate and Resolve Local Folder**
   - Ensures `LocalFolderPath` exists and is a folder.
   - Normalizes the path with `Resolve-Path`.

4. **Resolve SPO Site via Graph**
   - Parses `SiteUrl` into hostname and path.
   - Calls `GET /sites/{hostname}:/{site-path}` via `Get-GraphSiteByUrl`.
   - This call will fail with 403/404 if the `MainTask` app doesn’t have Sites.Selected access.

5. **Resolve Document Library (Drive)**
   - Calls `GET /sites/{site-id}/drives`.
   - Locates the drive whose `name` equals `DocumentLibraryName`.

6. **Create ZIP Archive**
   - Builds a ZIP file name using `<FolderName>_<Timestamp>.zip` in `Output\`.
   - Uses `Compress-Archive` via `New-ZipFromFolder` to create the archive.
   - Respects `IncludeRootFolder`.

7. **Upload ZIP to SPO**
   - Uses `PUT /drives/{drive-id}/root:/<TargetFolderPath>/<ZipName>:/content` via `Upload-FileToDrive`.
   - Returns the created drive item ID in the log.

8. **Cleanup**
   - Disconnects from Microsoft Graph.
   - Writes a final log entry indicating completion.

---

## Usage Examples

### Basic Run (Prod, app-only)

```powershell
# In a Prod-like scenario, dev secrets are disabled and you expect
# certificate or Key Vault-based auth to be correctly configured.
.\App-SP-Archive-And-Upload.ps1 -Environment Prod -GraphAuthMode AppOnly
```

### Dev Run with Console Logging

```powershell
# Dev scenario: allow dev secrets and echo logs to console
.\App-SP-Archive-And-Upload.ps1 -Environment Dev -GraphAuthMode AppOnly -VerboseLogsToConsole
```

### Custom Base Folder and Script Name Override

```powershell
.\App-SP-Archive-And-Upload.ps1 `
    -Environment Prod `
    -GraphAuthMode AppOnly `
    -BaseFolder "D:\ScriptData" `
    -ScriptNameOverride "App-SP-Archive-And-Upload-Sandbox"
```

After a successful run, check:

- `Logs\` for the log file.
- `Output\` for the created ZIP file.
- Your target SPO document library (`$SiteUrl` + `$DocumentLibraryName` + `$TargetFolderPath`) for the uploaded ZIP item.

---

## Error Handling & Exit Codes

- All operational errors are logged via `Write-Log` with level `ERROR`.
- A top-level `try`/`catch` sets:
  - `$global:LASTEXITCODE = 1`
  - `Exit 1` on failure
- On success, the script returns normally with `LASTEXITCODE = 0`.

This behavior makes the script safe for use under **Task Scheduler**, **Azure DevOps**, and other orchestrators that rely on exit codes to detect failures.

---

## Related Scripts

This script is part of a broader SharePoint / Graph automation toolkit and shares a common structure with:

- **SPO SP Permission Grantor**
- **SPO SP Permission Tester**

All of them use the same core concepts:

- Centralized app configuration via `$AppConfigs`.
- Standardized PSScriptData folder and logging.
- App-only Graph connections via `Connect-ToGraph`.
- Environment-aware dev/production behaviors.

Keeping these patterns consistent reduces cognitive load and makes future maintenance and enhancements significantly easier.
