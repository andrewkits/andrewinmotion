<#
.SYNOPSIS
  Zips a local folder and uploads the archive to a SharePoint Online site
  using an app-only (service principal) with Sites.Selected.

.DESCRIPTION
  This script:
    - Initializes a standard script environment (PSScriptData\<ScriptName>\…)
    - Uses app-only authentication (service principal) via $AppConfigs.MainTask
    - Compresses a configured local folder into a .zip under Output\
    - Resolves a SPO site from its URL via Microsoft Graph
    - Resolves a document library (drive) by name
    - Uploads the .zip file into the configured library/folder path

  PREREQUISITES
    - Configure $script:AppConfigs.MainTask (TenantId, ClientId, cert/Key Vault).
    - The app registration MUST have:
        Microsoft Graph application permission: Sites.Selected (with admin consent)
    - The app must be granted SITE-LEVEL access via RSC/Sites.Selected, e.g.:
        Set-SPOSite -Identity https://tenant.sharepoint.com/sites/YourSite `
                    -AppId <AppId> `
                    -DisplayName "App SP Archive Uploader" `
                    -Permissions Write

  EXECUTION
    - Fully non-interactive by default (AppOnly).
    - All operational inputs are in the "Script Configuration (hardcoded)" region.
#>

#region Core Settings

[CmdletBinding()]
param (
    # Global default for secret-based auth mode (scripts can override per-call)
    [ValidateSet('Auto','HardCoded','KeyVault')]
    [string]$AuthMode = 'Auto',

    # Global default for auth type (script-level preference)
    # 'Auto' = let per-app DefaultAuthType decide, falling back to 'Secret'
    [ValidateSet('Auto','Secret','Certificate')]
    [string]$AuthTypeDefault = 'Auto',

    # Execution environment:
    # - Dev  = hardcoded dev secrets allowed
    # - Prod = dev secrets disabled, only KeyVault/cert-based auth permitted
    [ValidateSet('Dev','Prod')]
    [string]$Environment = 'Prod',

    # This script uses APP-ONLY auth to test the SP (no interactive fallback)
    [ValidateSet('AppOnly')]
    [string]$GraphAuthMode = 'AppOnly',

    # Optional script-wide overrides for environment initialization
    [string]$ScriptNameOverride,
    [string]$BaseFolder,

    # Show log messages in console as well as log file
    [switch]$VerboseLogsToConsole
)

Clear-Host

# Central script-level settings object (optional)
$script:CoreSettings = [PSCustomObject]@{
    AuthMode           = $AuthMode
    AuthTypeDefault    = $AuthTypeDefault
    ScriptNameOverride = $ScriptNameOverride
    BaseFolder         = $BaseFolder
}

# Make environment available globally to all helper functions
$script:Environment = $Environment

# Only echo Write-Log messages to console when explicitly requested
$script:EnableConsoleLog = $VerboseLogsToConsole.IsPresent

function Get-CoreSetting {

    # See README.md section "Core Settings & Configuration Resolution".

    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$Name,

        [Parameter()]
        [object]$Default = $null
    )

    if ($script:CoreSettings -and
        $script:CoreSettings.PSObject.Properties.Name -contains $Name) {

        $val = $script:CoreSettings.$Name
        if ($null -ne $val -and $val -ne '') {
            return $val
        }
    }

    return $Default
}

#endregion Core Settings

#region Logging + Script Environment

function Write-Log {

    # See README.md section "Logging & Output Paths" for usage and behavior.

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$Message,

        [Parameter()]
        [ValidateSet('INFO','WARN','ERROR','DEBUG')]
        [string]$Level = 'INFO'
    )

    $timestampStr = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $entry        = "[$timestampStr][$Level] $Message"

    if ($script:EnableConsoleLog) {
        switch ($Level) {
            'INFO'  { Write-Host $entry }
            'WARN'  { Write-Host $entry -ForegroundColor Yellow }
            'ERROR' { Write-Host $entry -ForegroundColor Red }
            'DEBUG' { Write-Host $entry -ForegroundColor Cyan }
        }
    }

    if ($Global:logFile) {
        Add-Content -Path $Global:logFile -Value $entry
    }
}

function Initialize-ScriptEnvironment {

    # See README.md section "Logging & Output Paths" for environment bootstrap details.

    [CmdletBinding()]
    param ()

    # Resolve base folder
    $scriptBaseFolder = Get-CoreSetting -Name 'BaseFolder' -Default $null
    if (-not $scriptBaseFolder) {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $scriptBaseFolder = Join-Path -Path $desktop -ChildPath 'PSScriptData'
    }

    # Determine script name
    $scriptNameOverride = Get-CoreSetting -Name 'ScriptNameOverride' -Default $null
    if ($scriptNameOverride) {
        $scriptName = $scriptNameOverride
    }
    else {
        # Canonical script name for folder/log naming
        $scriptName = 'App-SP-Archive-And-Upload'
    }

    $scriptFolder = Join-Path -Path $scriptBaseFolder -ChildPath $scriptName

    $Global:baseFolder = $scriptFolder
    $Global:inputPath  = Join-Path -Path $scriptFolder -ChildPath 'Input'
    $Global:outputPath = Join-Path -Path $scriptFolder -ChildPath 'Output'
    $Global:logPath    = Join-Path -Path $scriptFolder -ChildPath 'Logs'

    $paths = @($Global:baseFolder, $Global:inputPath, $Global:outputPath, $Global:logPath)
    foreach ($p in $paths) {
        if (-not (Test-Path -Path $p)) {
            New-Item -Path $p -ItemType Directory -Force | Out-Null
        }
    }

    $Global:timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $Global:logFile   = Join-Path -Path $Global:logPath -ChildPath ("ScriptLog_{0}_{1}.txt" -f $scriptName, $Global:timestamp)

    Write-Log "Initialized script environment for $scriptName." 'INFO'
}

#endregion Logging + Script Environment

#region Dev Client Secret Helper (HARD-CODED, TESTING ONLY)

function Get-DevClientSecret {

    # Dev-only helper for hard-coded client secrets.
    # See README.md section "Dev Secrets Policy & Get-DevClientSecret".

    [CmdletBinding()]
    param (
        [ValidateSet('MainTask')]
        [string]$App = 'MainTask',

        [ValidateSet('Secure','Plain')]
        [string]$Format = 'Secure'
    )

    if ($script:Environment -and $script:Environment -eq 'Prod') {
        throw "Get-DevClientSecret: Dev secrets are disabled when Environment = 'Prod'. Use Key Vault or certificate-based auth instead."
    }

    # CONFIGURATION BLOCK (DEV ONLY)
    # Example (DEV ONLY):
    # $devSecrets.MainTask       = 'p@ste-main-task-secret-here'
    $devSecrets = @{
        MainTask       = $null   # SP used for the main workload (Graph)
    }
    # END CONFIGURATION BLOCK

    if (-not $devSecrets.Contains($App)) {
        throw "Get-DevClientSecret: Unknown App value '$App'. Valid values: MainTask."
    }

    $clientSecretPlainText = $devSecrets[$App]

    if (-not $clientSecretPlainText) {
        throw "Get-DevClientSecret: No dev secret configured for App '$App'. Edit the configuration block INSIDE this function for temporary dev/test only."
    }

    switch ($Format) {
        'Plain' {
            return $clientSecretPlainText
        }
        'Secure' {
            return (ConvertTo-SecureString -String $clientSecretPlainText -AsPlainText -Force)
        }
    }
}

#endregion Dev Client Secret Helper

#region SecureString Helpers

function ConvertFrom-SecureStringToPlainText {

    # See README.md section "SecureString Helpers & Secret Handling".

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [System.Security.SecureString]$SecureString
    )

    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString)
    try {
        return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr)
    }
    finally {
        if ($ptr -ne [IntPtr]::Zero) {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr)
        }
    }
}

#endregion SecureString Helpers

#region Key Vault / Az Context Helper

function Ensure-KeyVaultAzContext {

    [CmdletBinding()]
    param ()

    if (-not (Get-Module -ListAvailable -Name Az.Accounts)) {
        $msg = "Ensure-KeyVaultAzContext: Required module 'Az.Accounts' is not available. Install it via Install-Module Az.Accounts."
        Write-Log $msg 'ERROR'
        throw $msg
    }

    if (-not (Get-Module -ListAvailable -Name Az.KeyVault)) {
        $msg = "Ensure-KeyVaultAzContext: Required module 'Az.KeyVault' is not available. Install it via Install-Module Az.KeyVault."
        Write-Log $msg 'ERROR'
        throw $msg
    }

    try {
        Clear-AzContext -Scope Process -Force -ErrorAction SilentlyContinue
        Write-Log "Ensure-KeyVaultAzContext: Cleared existing Az context for this process (if any)." 'INFO'
    }
    catch {
        Write-Log "Ensure-KeyVaultAzContext: Clear-AzContext failed or is unavailable. Proceeding anyway." 'WARN'
    }

    Write-Log "Ensure-KeyVaultAzContext: Establishing Az context via KeyVaultAccess service principal." 'INFO'

    if (-not $script:AppConfigs -or -not $script:AppConfigs.Contains('KeyVaultAccess')) {
        $msg = "Ensure-KeyVaultAzContext: No KeyVaultAccess app configuration found in AppConfigs."
        Write-Log $msg 'ERROR'
        throw $msg
    }

    try {
        $kvAuth = Get-AppAuthCredential -App 'KeyVaultAccess' -Mode 'Auto'
    }
    catch {
        $msg = "Ensure-KeyVaultAzContext: Get-AppAuthCredential for KeyVaultAccess failed. Error: $($_.Exception.Message)"
        Write-Log $msg 'ERROR'
        throw $msg
    }

    if ($kvAuth.PSObject.Properties.Name -contains 'Certificate' -and $kvAuth.Certificate) {
        $thumbprint = $kvAuth.Certificate.Thumbprint

        try {
            Connect-AzAccount -ServicePrincipal `
                -Tenant        $kvAuth.TenantId `
                -ApplicationId $kvAuth.ClientId `
                -CertificateThumbprint $thumbprint `
                -ErrorAction   Stop | Out-Null

            $ctx = Get-AzContext -ErrorAction Stop
            Write-Log "Ensure-KeyVaultAzContext: Established Az context using KeyVaultAccess SP '$($kvAuth.ClientId)' in tenant '$($kvAuth.TenantId)' with certificate thumbprint '$thumbprint'." 'INFO'
        }
        catch {
            $msg = "Ensure-KeyVaultAzContext: Failed to establish Az context using KeyVaultAccess certificate. Error: $($_.Exception.Message)"
            Write-Log $msg 'ERROR'
            throw $msg
        }
    }
    else {
        $msg = "Ensure-KeyVaultAzContext: KeyVaultAccess credentials did not include a usable Certificate."
        Write-Log $msg 'ERROR'
        throw $msg
    }
}

#endregion Key Vault / Az Context Helper

#region App Auth Configuration + Credential Helper

# Central app configuration table for this script
$script:AppConfigs = [ordered]@{
    # Main workload SP (Graph caller)
    MainTask = [PSCustomObject]@{
        TenantId        = "aa8a36a6-3a57-4334-ae63-229dce0f8b57"   # TODO: confirm
        ClientId        = "333a5769-28b3-4ba7-b011-b6ff8872758c"   # TODO: confirm
        DefaultAuthType = 'Certificate'   # 'Secret' or 'Certificate'

        # Secret-based config (SECRET OBJECT in Key Vault)
        Secret = [PSCustomObject]@{
            KeyVaultName       = $null   # optional
            KeyVaultSecretName = $null   # optional
        }

        # Certificate-based config
        Certificate = [PSCustomObject]@{
            # Option 1: Local cert store
            LocalStoreThumbprint     = $null
            LocalStoreStoreName      = 'My'
            LocalStoreStoreLocation  = 'CurrentUser'

            # Option 2: Azure Key Vault CERTIFICATE / PFX
            KeyVaultName             = "KQAKeyVault001"              # vault containing the certificate object
            KeyVaultCertName         = "SPO-SITE-MANAGEMENT-CERT"    # certificate object name
            # KeyVaultPfxSecretIdentifier = $null                     # optional - PFX secret URI
        }
    }

    # Service principal that logs into Azure / reads Key Vault
    KeyVaultAccess = [PSCustomObject]@{
        TenantId        = "aa8a36a6-3a57-4334-ae63-229dce0f8b57"
        ClientId        = "333a5769-28b3-4ba7-b011-b6ff8872758c"
        DefaultAuthType = 'Certificate'   # 'Certificate ONLY'

        Certificate = [PSCustomObject]@{
            LocalStoreThumbprint     = "70a9f1878278237ed7c0a48b84e6cb555c2d96dc"
            LocalStoreStoreName      = 'My'
            LocalStoreStoreLocation  = 'CurrentUser'
        }
    }
}

function Get-AppSecretCredentialCore {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('MainTask','KeyVaultAccess')]
        [string]$App,

        [Parameter(Mandatory)]
        [ValidateSet('Auto','HardCoded','KeyVault')]
        [string]$Mode,

        [Parameter(Mandatory)]
        [object]$Config,

        [Parameter(Mandatory)]
        [string]$EnvMode
    )

    if (-not ($Config.PSObject.Properties.Name -contains 'Secret') -or -not $Config.Secret) {
        throw "Get-AppSecretCredentialCore: App '$App' has no Secret configuration but Secret auth was requested."
    }

    $s = $Config.Secret
    $effectiveSecret = $null
    $secretSource    = $null

    switch ($Mode) {
        'HardCoded' {
            if (-not (Get-Command -Name 'Get-DevClientSecret' -ErrorAction SilentlyContinue)) {
                throw "Get-AppSecretCredentialCore (HardCoded/$App): Get-DevClientSecret is not available."
            }

            try {
                $effectiveSecret = Get-DevClientSecret -App $App -Format Secure
                $secretSource    = 'DevSecret'
            }
            catch {
                $msg = "Get-AppSecretCredentialCore (HardCoded/$App): Failed to retrieve dev secret. Error: $($_.Exception.Message)"
                Write-Log $msg 'ERROR'
                throw $msg
            }
        }

        'KeyVault' {
            if (-not ($s.KeyVaultName -or $s.KeyVaultSecretIdentifier -or $s.KeyVaultSecretName)) {
                throw "Get-AppSecretCredentialCore (KeyVault/$App): No Key Vault secret settings found."
            }

            Write-Log "Get-AppSecretCredentialCore (KeyVault/$App): Using Key Vault secret configuration." 'INFO'
            Ensure-KeyVaultAzContext

            try {
                if ($s.KeyVaultSecretIdentifier) {
                    $kvSecret = Get-AzKeyVaultSecret -SecretId $s.KeyVaultSecretIdentifier -ErrorAction Stop
                }
                else {
                    $kvSecret = Get-AzKeyVaultSecret -VaultName $s.KeyVaultName -Name $s.KeyVaultSecretName -ErrorAction Stop
                }

                $effectiveSecret = $kvSecret.SecretValue
                $secretSource    = if ($s.KeyVaultSecretIdentifier) { 'KeyVaultSecretId' } else { $s.KeyVaultName }
            }
            catch {
                $msg = "Get-AppSecretCredentialCore (KeyVault/$App): Failed to retrieve secret from Key Vault. Error: $($_.Exception.Message)"
                Write-Log $msg 'ERROR'
                throw $msg
            }
        }

        'Auto' {
            if ($s.KeyVaultName -or $s.KeyVaultSecretIdentifier -or $s.KeyVaultSecretName) {
                Write-Log "Get-AppSecretCredentialCore (Auto/$App): Key Vault secret config detected, trying Key Vault first." 'INFO'
                Ensure-KeyVaultAzContext

                try {
                    if ($s.KeyVaultSecretIdentifier) {
                        $kvSecret = Get-AzKeyVaultSecret -SecretId $s.KeyVaultSecretIdentifier -ErrorAction Stop
                    }
                    else {
                        $kvSecret = Get-AzKeyVaultSecret -VaultName $s.KeyVaultName -Name $s.KeyVaultSecretName -ErrorAction Stop
                    }

                    $effectiveSecret = $kvSecret.SecretValue
                    $secretSource    = if ($s.KeyVaultSecretIdentifier) { 'KeyVaultSecretId' } else { $s.KeyVaultName }
                }
                catch {
                    Write-Log "Get-AppSecretCredentialCore (Auto/$App): Key Vault secret retrieval failed. Error: $($_.Exception.Message)" 'WARN'
                }
            }

            if (-not $effectiveSecret) {
                if (-not (Get-Command -Name 'Get-DevClientSecret' -ErrorAction SilentlyContinue)) {
                    throw "Get-AppSecretCredentialCore (Auto/$App): Get-DevClientSecret is not available and Key Vault retrieval failed."
                }

                try {
                    $effectiveSecret = Get-DevClientSecret -App $App -Format Secure
                    $secretSource    = 'DevSecret'
                }
                catch {
                    $msg = "Get-AppSecretCredentialCore (Auto/$App): Failed to retrieve dev secret after Key Vault fallback. Error: $($_.Exception.Message)"
                    Write-Log $msg 'ERROR'
                    throw $msg
                }
            }
        }

        default {
            throw "Get-AppSecretCredentialCore: Unsupported Mode '$Mode' for Secret auth."
        }
    }

    return [pscustomobject]@{
        ClientSecret = $effectiveSecret
        Source       = $secretSource
    }
}

function Get-AppCertificateCredentialCore {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [ValidateSet('MainTask','KeyVaultAccess')]
        [string]$App,

        [Parameter(Mandatory)]
        [object]$Config,

        [Parameter(Mandatory)]
        [string]$EnvMode
    )

    if (-not ($Config.PSObject.Properties.Name -contains 'Certificate') -or -not $Config.Certificate) {
        throw "Get-AppCertificateCredentialCore: App '$App' has no Certificate configuration."
    }

    $c             = $Config.Certificate
    $effectiveCert = $null
    $certSource    = $null

    # 1) Local store
    if ($c.LocalStoreThumbprint) {
        $storeLocation = if ($c.LocalStoreStoreLocation) { $c.LocalStoreStoreLocation } else { 'LocalMachine' }
        $storeName     = if ($c.LocalStoreStoreName)     { $c.LocalStoreStoreName }     else { 'My' }

        Write-Log "Get-AppCertificateCredentialCore (Certificate/$App): Attempting local cert store ($storeLocation\$storeName) by thumbprint..." 'INFO'

        try {
            $store = [System.Security.Cryptography.X509Certificates.X509Store]::new($storeName, $storeLocation)
            $store.Open([System.Security.Cryptography.X509Certificates.OpenFlags]::ReadOnly)

            $match = $store.Certificates.Find(
                [System.Security.Cryptography.X509Certificates.X509FindType]::FindByThumbprint,
                $c.LocalStoreThumbprint,
                $false
            )

            if ($match.Count -gt 0) {
                $effectiveCert = $match[0]
                $certSource    = "LocalStore:$storeLocation\$storeName"
                Write-Log "Get-AppCertificateCredentialCore (Certificate/$App): Found certificate in local store with thumbprint '$($c.LocalStoreThumbprint)'." 'INFO'
            }
            else {
                Write-Log "Get-AppCertificateCredentialCore (Certificate/$App): No certificate found in local store with thumbprint '$($c.LocalStoreThumbprint)'." 'WARN'
            }

            $store.Close()
        }
        catch {
            Write-Log "Get-AppCertificateCredentialCore (Certificate/$App): Error while searching local certificate store. Error: $($_.Exception.Message)" 'ERROR'
        }
    }

    # 2) Key Vault-backed certificate – allowed for MainTask only
    if (-not $effectiveCert -and $App -ne 'KeyVaultAccess' -and ($c.KeyVaultName -or $c.KeyVaultCertName -or $c.KeyVaultPfxSecretIdentifier)) {

        Write-Log "Get-AppCertificateCredentialCore (Certificate/$App): Attempting to retrieve certificate material from Key Vault." 'INFO'
        Ensure-KeyVaultAzContext

        try {
            if ($c.KeyVaultPfxSecretIdentifier) {
                $kvSecret = Get-AzKeyVaultSecret -SecretId $c.KeyVaultPfxSecretIdentifier -ErrorAction Stop
            }
            elseif ($c.KeyVaultName -and $c.KeyVaultCertName) {
                $kvCert = Get-AzKeyVaultCertificate -VaultName $c.KeyVaultName -Name $c.KeyVaultCertName -ErrorAction Stop

                if (-not $kvCert.SecretId) {
                    throw "Key Vault certificate '$($c.KeyVaultCertName)' in vault '$($c.KeyVaultName)' does not expose SecretId; cannot retrieve PFX."
                }

                $kvSecret = Get-AzKeyVaultSecret -SecretId $kvCert.SecretId -ErrorAction Stop
            }
            else {
                throw "Get-AppCertificateCredentialCore (Certificate/$App): Incomplete Key Vault certificate configuration."
            }

            $pfxBase64 = ConvertFrom-SecureStringToPlainText -SecureString $kvSecret.SecretValue
            $pfxBytes  = [Convert]::FromBase64String($pfxBase64)

            $x509 = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2(
                $pfxBytes,
                $null,
                [System.Security.Cryptography.X509Certificates.X509KeyStorageFlags]::Exportable
            )

            $effectiveCert = $x509
            $certSource    = if ($c.KeyVaultPfxSecretIdentifier) { 'KeyVaultPfxSecretId' } else { "KeyVaultCert:$($c.KeyVaultName)/$($c.KeyVaultCertName)" }

            Write-Log "Get-AppCertificateCredentialCore (Certificate/$App): Successfully imported certificate material from Key Vault." 'INFO'
        }
        catch {
            $msg = "Get-AppCertificateCredentialCore (Certificate/$App): Failed to retrieve certificate material from Key Vault. Error: $($_.Exception.Message)"
            Write-Log $msg 'ERROR'
            throw $msg
        }
    }

    if (-not $effectiveCert) {
        throw "Get-AppCertificateCredentialCore: Failed to resolve a usable certificate for App '$App'."
    }

    return [pscustomobject]@{
        Certificate = $effectiveCert
        Source      = $certSource
    }
}

function Get-AppAuthCredential {

    [CmdletBinding()]
    param (
        [ValidateSet('MainTask','KeyVaultAccess')]
        [string]$App,

        [ValidateSet('Auto','HardCoded','KeyVault')]
        [string]$Mode = 'Auto',

        [ValidateSet('Auto','Secret','Certificate')]
        [string]$AuthType = 'Auto'
    )

    if (-not $script:AppConfigs -or -not $script:AppConfigs.Contains($App)) {
        throw "Get-AppAuthCredential: App '$App' not found in AppConfigs."
    }

    $cfg = $script:AppConfigs[$App]

    # Script-level defaults
    $scriptMode      = $null
    $scriptAuthType  = $null
    if ($script:CoreSettings) {
        if ($script:CoreSettings.PSObject.Properties.Name -contains 'AuthMode') {
            $scriptMode = $script:CoreSettings.AuthMode
        }
        if ($script:CoreSettings.PSObject.Properties.Name -contains 'AuthTypeDefault') {
            $scriptAuthType = $script:CoreSettings.AuthTypeDefault
        }
    }

    # Per-app default auth type
    $appDefaultAuthType = $null
    if ($cfg.PSObject.Properties.Name -contains 'DefaultAuthType') {
        $appDefaultAuthType = $cfg.DefaultAuthType
    }

    # Determine effective auth type
    if ($AuthType -ne 'Auto') {
        $effectiveAuthType = $AuthType
    }
    elseif ($appDefaultAuthType -and $appDefaultAuthType -ne 'Auto') {
        $effectiveAuthType = $appDefaultAuthType
    }
    elseif ($scriptAuthType -and $scriptAuthType -ne 'Auto') {
        $effectiveAuthType = $scriptAuthType
    }
    else {
        $effectiveAuthType = 'Secret'
    }

    # Determine effective mode
    $effectiveMode = $Mode
    if ($Mode -eq 'Auto') {
        if ($scriptMode -and $scriptMode -ne 'Auto') {
            $effectiveMode = $scriptMode
        }
        else {
            $effectiveMode = 'Auto'
        }
    }

    # Determine environment
    $envMode = if ($script:Environment) { $script:Environment } else { 'Prod' }

    # Special rules for KeyVaultAccess
    if ($App -eq 'KeyVaultAccess') {
        # KV reader MUST always use certificate-based auth (local store only).
        $effectiveAuthType = 'Certificate'
    }

    Write-Log "Get-AppAuthCredential effective AuthType resolved to '$effectiveAuthType' for App '$App'." 'DEBUG'
    Write-Log "Get-AppAuthCredential effective Mode resolved to '$effectiveMode' for App '$App'." 'DEBUG'

    if (-not $cfg.TenantId -or -not $cfg.ClientId) {
        throw "Get-AppAuthCredential: App '$App' configuration must include TenantId and ClientId."
    }

    $tenantId = $cfg.TenantId
    $clientId = $cfg.ClientId

    switch ($effectiveAuthType) {
        'Secret' {
            $secretObj = Get-AppSecretCredentialCore -App $App -Mode $effectiveMode -Config $cfg -EnvMode $envMode

            return [pscustomobject]@{
                TenantId     = $tenantId
                ClientId     = $clientId
                ClientSecret = $secretObj.ClientSecret
                Source       = $secretObj.Source
            }
        }

        'Certificate' {
            $certObj = Get-AppCertificateCredentialCore -App $App -Config $cfg -EnvMode $envMode

            return [pscustomobject]@{
                TenantId    = $tenantId
                ClientId    = $clientId
                Certificate = $certObj.Certificate
                Source      = $certObj.Source
            }
        }

        default {
            throw "Get-AppAuthCredential: Unsupported effectiveAuthType '$effectiveAuthType' for App '$App'."
        }
    }
}

#endregion App Auth Configuration + Credential Helper

#region Graph Connection Helper

function Connect-ToGraph {
    [CmdletBinding()]
    param (
        # This script *only* supports app-only (service principal) auth.
        [ValidateSet('AppOnly')]
        [string]$AuthMode = 'AppOnly',

        [ValidateSet('MainTask','KeyVaultAccess')]
        [string]$App = 'MainTask',

        [switch]$NoWelcome
    )

    Write-Log "Connect-ToGraph invoked with AuthMode='$AuthMode', App='$App'." 'DEBUG'

    try {
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        Write-Log "Connect-ToGraph: Cleared existing Microsoft Graph connection (if any)." 'DEBUG'
    }
    catch { }

    if ($AuthMode -ne 'AppOnly') {
        throw "Connect-ToGraph: Only 'AppOnly' authentication is supported in this script. Requested: '$AuthMode'."
    }

    $connectParams = @{
        ErrorAction = 'Stop'
    }
    if ($NoWelcome) { $connectParams['NoWelcome'] = $true }

    try {
        Write-Log "Connect-ToGraph: Connecting to Microsoft Graph using APP-ONLY (service principal) for App '$App'." 'INFO'
        $cred = Get-AppAuthCredential -App $App -Mode 'Auto'

        if ($cred.ClientSecret) {
            Write-Log "Connect-ToGraph (AppOnly): Using SECRET-based auth for App '$App'. Source: $($cred.Source)" 'INFO'

            $clientSecretCredential = [System.Management.Automation.PSCredential]::new(
                $cred.ClientId,
                $cred.ClientSecret
            )

            Connect-MgGraph @connectParams `
                -TenantId               $cred.TenantId `
                -ClientSecretCredential $clientSecretCredential | Out-Null
        }
        elseif ($cred.Certificate) {
            Write-Log "Connect-ToGraph (AppOnly): Using CERTIFICATE-based auth for App '$App'. Source: $($cred.Source)" 'INFO'

            Connect-MgGraph @connectParams `
                -TenantId   $cred.TenantId `
                -ClientId   $cred.ClientId `
                -Certificate $cred.Certificate | Out-Null
        }
        else {
            $msg = "Connect-ToGraph (AppOnly): Get-AppAuthCredential returned neither ClientSecret nor Certificate for App '$App'."
            Write-Log $msg 'ERROR'
            throw $msg
        }
    }
    catch {
        $msg = "Connect-ToGraph: Failed to connect to Microsoft Graph using APP-ONLY mode. Error: $($_.Exception.Message)"
        Write-Log $msg 'ERROR'
        throw $msg
    }

    $ctx = Get-MgContext
    Write-Log ("Connect-ToGraph: Connected to tenant '{0}' as '{1}'." -f $ctx.TenantId, $ctx.Account) 'INFO'
}

#endregion Graph Connection Helper

#region SPO Helpers (Site + Drives)

function Parse-SiteUrl {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$Url
    )

    try {
        $uri = [System.Uri]::new($Url)
    }
    catch {
        throw "Parse-SiteUrl: '$Url' is not a valid URL. Expecting something like https://contoso.sharepoint.com/sites/YourSite"
    }

    if (-not $uri.Host -or -not $uri.AbsolutePath) {
        throw "Parse-SiteUrl: Could not parse hostname/path from '$Url'."
    }

    [PSCustomObject]@{
        Hostname = $uri.Host
        Path     = $uri.AbsolutePath
    }
}

function Get-GraphSiteByUrl {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$Hostname,
        [Parameter(Mandatory)]
        [string]$Path
    )

    $uri = "https://graph.microsoft.com/v1.0/sites/${Hostname}:$Path"
    Write-Log "Get-GraphSiteByUrl: Querying $uri" 'INFO'

    try {
        $site = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop
        return $site
    }
    catch {
        $msg = "Get-GraphSiteByUrl failed for '$Hostname$Path'. $($_.Exception.Message)"
        Write-Log $msg 'ERROR'
        throw $msg
    }
}

function Get-GraphSiteDrives {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$SiteId
    )

    $uri = "https://graph.microsoft.com/v1.0/sites/$SiteId/drives"
    Write-Log "Get-GraphSiteDrives: Querying $uri" 'INFO'

    try {
        $drives = Invoke-MgGraphRequest -Method GET -Uri $uri -ErrorAction Stop
        return $drives.value
    }
    catch {
        $msg = "Get-GraphSiteDrives failed for SiteId '$SiteId'. $($_.Exception.Message)"
        Write-Log $msg 'ERROR'
        throw $msg
    }
}

function Get-GraphDriveByName {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)][string]$SiteId,
        [Parameter(Mandatory)][string]$DriveName
    )

    $drives = Get-GraphSiteDrives -SiteId $SiteId

    if (-not $drives -or $drives.Count -eq 0) {
        throw "Get-GraphDriveByName: No drives returned for site '$SiteId'."
    }

    $drive = $drives | Where-Object { $_.name -eq $DriveName } | Select-Object -First 1

    if (-not $drive) {
        $available = $drives.name -join ', '
        throw "Get-GraphDriveByName: Drive '$DriveName' not found. Available drives: $available"
    }

    Write-Log "Get-GraphDriveByName: Resolved drive '$DriveName' to Id '$($drive.id)'." 'INFO'
    return $drive
}

#endregion SPO Helpers (Site + Drives)

#region Helpers: File Selection + Cleanup

function Get-MostRecentMatchingFile {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$FolderPath,

        [Parameter(Mandatory)]
        [string]$Prefix,

        [Parameter(Mandatory)]
        [string]$Extension
    )

    if (-not (Test-Path -Path $FolderPath -PathType Container)) {
        throw "Get-MostRecentMatchingFile: FolderPath '$FolderPath' does not exist or is not a directory."
    }

    $pattern = "$Prefix*.$Extension"

    Write-Log "Get-MostRecentMatchingFile: Searching '$FolderPath' for pattern '$pattern'." "INFO"

    $files = Get-ChildItem -Path $FolderPath -File -Filter $pattern -ErrorAction Stop

    if (-not $files -or $files.Count -eq 0) {
        Write-Log "Get-MostRecentMatchingFile: No files found matching '$pattern' in '$FolderPath'." "WARN"
        return $null
    }

    # Use LastWriteTimeUtc to avoid local timezone weirdness
    $latest = $files | Sort-Object -Property LastWriteTimeUtc -Descending | Select-Object -First 1

    Write-Log ("Get-MostRecentMatchingFile: Latest file is '{0}' (LastWriteTimeUtc: {1})." -f $latest.Name, $latest.LastWriteTimeUtc) "INFO"
    return $latest
}

function Move-OldFilesToLocalArchive {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory)]
        [string]$FolderPath,

        [Parameter(Mandatory)]
        [string]$ArchiveFolderPath,

        [Parameter(Mandatory)]
        [string]$Prefix,

        [Parameter(Mandatory)]
        [string]$Extension,

        [Parameter(Mandatory)]
        [string]$LatestFileFullName
    )

    $pattern = "$Prefix*.$Extension"

    if (-not (Test-Path -Path $ArchiveFolderPath -PathType Container)) {
        Write-Log "Move-OldFilesToLocalArchive: Creating archive folder '$ArchiveFolderPath'." "INFO"
        New-Item -Path $ArchiveFolderPath -ItemType Directory -Force | Out-Null
    }

    $files = Get-ChildItem -Path $FolderPath -File -Filter $pattern -ErrorAction Stop

    if (-not $files -or $files.Count -eq 0) {
        Write-Log "Move-OldFilesToLocalArchive: No files found to clean up." "INFO"
        return
    }

    $oldFiles = $files | Where-Object { $_.FullName -ne $LatestFileFullName }

    if (-not $oldFiles -or $oldFiles.Count -eq 0) {
        Write-Log "Move-OldFilesToLocalArchive: No old files to move. Only the latest exists." "INFO"
        return
    }

    foreach ($f in $oldFiles) {
        $dest = Join-Path -Path $ArchiveFolderPath -ChildPath $f.Name

        # Avoid overwrite collisions by suffixing if needed
        if (Test-Path -Path $dest) {
            $base = [System.IO.Path]::GetFileNameWithoutExtension($f.Name)
            $ext  = [System.IO.Path]::GetExtension($f.Name)
            $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $dest = Join-Path -Path $ArchiveFolderPath -ChildPath ("{0}_moved_{1}{2}" -f $base, $stamp, $ext)
        }

        Write-Log ("Move-OldFilesToLocalArchive: Moving '{0}' -> '{1}'" -f $f.FullName, $dest) "INFO"
        Move-Item -Path $f.FullName -Destination $dest -Force -ErrorAction Stop
    }

    Write-Log ("Move-OldFilesToLocalArchive: Moved {0} old file(s) to '{1}'." -f $oldFiles.Count, $ArchiveFolderPath) "INFO"
}

#endregion Helpers: File Selection + Cleanup

#region Script Configuration (hardcoded)

# Folder where the PRIMARY script drops the output file(s)
$SourceFolderPath = "C:\ScheduledTasks\teamsHistoricalRunner\local-output\KITS\teamsHistoricalSource"

# Filename pattern parts
$FilePrefix    = "8fa12c9e47bd30f1e6a9427b-teamsHistoricalSource"
$FileExtension = "jsonl"

# Cleanup folder (created under parent of SourceFolderPath)
# Example: if SourceFolderPath = C:\Jobs\TeamsExport\Output
# ArchivePath becomes         = C:\Jobs\TeamsExport\Archive
$LocalArchiveFolderName = "Archive"

# --- SharePoint Online target ---
$SiteUrl              = "https://kaizenitsolutionsqa.sharepoint.com/sites/AreaTest-One"
$DocumentLibraryName  = "Documents"
$TargetFolderPath     = "Teams Chat Exports"

#endregion Script Configuration (hardcoded)

# --- Identify latest file ---
$latestFile = Get-MostRecentMatchingFile -FolderPath $SourceFolderPath -Prefix $FilePrefix -Extension $FileExtension

if (-not $latestFile) {
    # No new output yet. For automation, treat this as a non-fatal condition.
    Write-Log "Main: No matching files found. Nothing to upload." "WARN"
    return
}

# --- Upload latest file (no archiving) ---
$uploadResult = Upload-FileToDrive -DriveId $driveId -TargetPath $TargetFolderPath -LocalFilePath $latestFile.FullName

Write-Log ("Main: Uploaded latest file '{0}' to SPO successfully (Item Id: {1})." -f $latestFile.Name, $uploadResult.id) "INFO"

# --- Cleanup: move all but latest into local archive folder under parent ---
$parent = Split-Path -Path $SourceFolderPath -Parent
$archivePath = Join-Path -Path $parent -ChildPath $LocalArchiveFolderName

Move-OldFilesToLocalArchive `
    -FolderPath $SourceFolderPath `
    -ArchiveFolderPath $archivePath `
    -Prefix $FilePrefix `
    -Extension $FileExtension `
    -LatestFileFullName $latestFile.FullName


#region Main: Archive & Upload

try {
    Initialize-ScriptEnvironment

    Write-Log "Script starting: App SP Archive and Upload (Sites.Selected app-only, non-interactive)." "INFO"

    # Connect to Graph app-only using MainTask
    Write-Log "Global: Connecting to Graph with AuthMode='$GraphAuthMode' for App-SP-Archive-And-Upload." 'INFO'
    Connect-ToGraph -AuthMode $GraphAuthMode -App 'MainTask' -NoWelcome | Out-Null

    # Validate local folder
    if (-not (Test-Path -Path $LocalFolderPath -PathType Container)) {
        throw "LocalFolderPath '$LocalFolderPath' does not exist or is not a folder."
    }

    $LocalFolderPath = (Resolve-Path -Path $LocalFolderPath).Path
    Write-Log "Main: Using LocalFolderPath = $LocalFolderPath" "INFO"

    if ([string]::IsNullOrWhiteSpace($SiteUrl)) {
        throw "SiteUrl is not configured. Set SiteUrl in the Script Configuration region."
    }

    # Resolve site from URL via Graph
    Write-Log "Main: Target SPO site URL: $SiteUrl" 'INFO'
    $parsed      = Parse-SiteUrl -Url $SiteUrl
    $resolvedSite = Get-GraphSiteByUrl -Hostname $parsed.Hostname -Path $parsed.Path

    if (-not $resolvedSite -or -not $resolvedSite.id) {
        throw "Could not resolve site from URL '$SiteUrl'. Check the URL and service principal permissions."
    }

    Write-Log "Main: Resolved site. Id: $($resolvedSite.id) Name: $($resolvedSite.displayName) Url: $($resolvedSite.webUrl)" 'INFO'

    # Resolve document library (drive) by name
    $drive = Get-GraphDriveByName -SiteId $resolvedSite.id -DriveName $DocumentLibraryName
    $driveId   = $drive.id
    $driveName = $drive.name
    Write-Log "Main: Using document library '$driveName' (Drive Id: $driveId)." 'INFO'

    # Build zip path in Output folder
    $folderName = Split-Path -Path $LocalFolderPath.TrimEnd('\','/') -Leaf
    $zipName    = "{0}_{1}.zip" -f $folderName, $timestamp
    $zipPath    = Join-Path -Path $outputPath -ChildPath $zipName

    # Create zip
    $createdZip = New-ZipFromFolder -SourceFolder $LocalFolderPath -DestinationZipPath $zipPath -IncludeRoot:([bool]$IncludeRootFolder)

    # Upload zip file
    $uploadResult = Upload-FileToDrive -DriveId $driveId -TargetPath $TargetFolderPath -LocalFilePath $createdZip

    Write-Log "Main: Zip '$createdZip' successfully uploaded to SPO (Item Id: $($uploadResult.id))." "INFO"
}
catch {
    $msg = "Unhandled error in App SP Archive and Upload: $($_.Exception.Message)"
    Write-Log $msg 'ERROR'

    # Signal failure WITHOUT dumping a full stack trace to console
    $global:LASTEXITCODE = 1

    # Optionally: actually exit the script here (recommended for automation)
    Exit 1
}
finally {
    try {
        Disconnect-MgGraph -ErrorAction SilentlyContinue | Out-Null
        Write-Log "Disconnected from Microsoft Graph." 'INFO'
        Write-Log "Finished executing script: App-SP-Archive-And-Upload" 'INFO'
    }
    catch { }
}

#endregion Main: Archive & Upload
